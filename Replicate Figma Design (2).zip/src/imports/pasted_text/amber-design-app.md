Create a complete interactive mobile app prototype in Arabic with RTL layout for a platform called “Amber Design”.

The app has two user types at the beginning:
1. User
2. Designer

This flow ONLY IS USER CHOSES THE FASHION FIELD 

==================================================
FIRST USER FLOW: ENTERING AS A DESIGNER
==================================================

Screen 5: Designer Sign Up
Fields:
- Full name
- Email
- Phone number
- Password
- Confirm password

Button:
- "التالي"

Interaction:
- Clicking Next navigates to Designer Field Selection screen

Screen 6: Designer Field Selection
Title:
"اختر مجال التصميم"

Options:
- تصميم داخلي
- تصميم خارجي
- تصميم أزياء

For this prototype, continue only with:
"تصميم أزياء"

Interaction:
- Clicking Fashion Design navigates to the Fashion Designer Profile Setup screen

Screen 7: Fashion Designer Profile Setup
Fields:
- Profile picture
- Designer name
- City
- Short bio
- Years of experience
- Fashion categories
- Optional social links

Button:
- "إنشاء الحساب"

Interaction:
- Clicking Create Account navigates to the Fashion Designer Home screen

==================================================
MAIN FASHION DESIGNER APP
==================================================

The main app has 6 main sections:

1. الرئيسية
2. منتجاتي
3. تصفح الطلبات
4. إدارة الطلبات
5. المحادثات
6. الملف الشخصي

Use a bottom navigation bar with these main destinations:
- الرئيسية
- منتجاتي
- الطلبات
- المحادثات
- الملف الشخصي

The "الطلبات" item can open the Request Management area, while Browse Requests can be accessible from the Home screen and Request Management screen.

==================================================
1. HOME SCREEN – الرئيسية
==================================================

Purpose:
Give the fashion designer a quick summary of pending work.

Display:

A. Pending Private Requests Card
Title:
"الطلبات الخاصة غير المعالجة"

Show:
- Number of private custom requests that the designer has not accepted or rejected yet

Interaction:
- Clicking this card navigates to Browse Requests
- Open the "الطلبات الخاصة" tab automatically

B. Pending Product Purchases Card
Title:
"مشتريات المنتجات غير المعالجة"

Show:
- Number of product purchase orders that have not started shipping or processing yet

Interaction:
- Clicking this card navigates to Request Management
- Open the "طلبات الشراء" tab automatically
- Filter status to "قيد الانتظار"

C. Rating Section
Show:
- Overall star rating only
- Example: 4.7 stars
- Do not show written reviews directly on the Home screen

Interaction:
- Clicking the rating section navigates to the Customer Reviews screen

D. Latest Activity
Show a few recent items, such as:
- New private request
- New product purchase
- New message
- New review

Each item should navigate to its related screen.

==================================================
2. MY PRODUCTS – منتجاتي
==================================================

Purpose:
Manage ready-made fashion products available for sale.

Display:
- Product grid or cards
- Product image
- Product name
- Price
- Availability status

Each product card should have:
- View details
- Edit
- Delete

Interactions:
- Clicking a product card navigates to Product Details
- Clicking Edit navigates to Edit Product
- Clicking Delete opens a confirmation modal

Main button:
"إضافة منتج"

Interaction:
- Clicking Add Product navigates to Add Product screen

ADD PRODUCT SCREEN:

The designer must be able to upload MULTIPLE images, not only one image.

Fields:
- Product name
- Multiple product images
- Description
- Price
- Category
- Quantity or availability

Create an optional product information section where the designer chooses which attributes apply to the product.

Optional attributes:
- Sizes
- Lengths
- Colors
- Fabric type
- Custom measurements
- Stock quantity

Important:
Not every product should be forced to include all attributes.

Use toggles, chips, or checkboxes such as:
- إضافة المقاسات
- إضافة الأطوال
- إضافة الألوان
- إضافة نوع القماش
- إضافة الكمية

When an option is enabled, show its related input fields.

Example:
- When "إضافة المقاسات" is enabled, show sizes such as XS, S, M, L, XL or custom sizes
- When "إضافة الألوان" is enabled, allow the designer to add multiple colors
- When "إضافة الأطوال" is enabled, allow custom length values

Button:
"حفظ المنتج"

Interaction:
- Clicking Save Product navigates back to My Products
- The new product appears in the product list

PRODUCT DETAILS SCREEN:
Show:
- Image gallery
- Product name
- Price
- Description
- Selected attributes only
- Available sizes if added
- Available colors if added
- Length information if added
- Availability status

Buttons:
- Edit product
- Delete product

==================================================
3. BROWSE REQUESTS – تصفح الطلبات
==================================================

Purpose:
Allow the fashion designer to browse both public and private customer design requests.

At the top, use two tabs:
- "الطلبات العامة"
- "الطلبات الخاصة"

A. Public Requests
These requests are created by customers and visible to all fashion designers.

B. Private Requests
These requests are sent directly to this specific designer.

Use filter tags such as:
- فساتين
- عبايات
- ملابس سهرة
- زفاف
- تفصيل خاص
- الأحدث
- الميزانية
- المدينة

Each request card shows:
- Reference image
- Request title
- Request type
- Budget range
- City
- Date
- Public or private label
- Short description

Interaction:
- Clicking any request card navigates to Request Details

REQUEST DETAILS SCREEN:

Display all customer-provided information:
- Request title
- Full description
- Multiple attached images
- Measurements
- Sizes
- Preferred colors
- Fabric preferences
- Required completion date
- Budget
- City
- Any special notes

Buttons:
- "قبول الطلب"
- "رفض الطلب"

REJECT FLOW:
- Clicking Reject opens a confirmation modal
- Optional reason field
- Confirm Reject button
- After rejection, request status becomes Rejected
- Navigate back to Browse Requests

ACCEPT FLOW:
- Clicking Accept navigates to Create Offer screen

CREATE OFFER SCREEN:

Fields:
- Proposed price
- Required completion time
- Expected delivery date
- Designer message or notes
- Revision policy if needed

Button:
"إرسال العرض للعميل"

Interaction:
- Clicking Send Offer changes the request status to:
"بانتظار رد العميل"

Then navigate to Request Management under:
- "طلبات التصميم"
- Status: Pending Customer Response

CUSTOMER RESPONSE STATES:
- If customer accepts the offer:
  status becomes "مقبول / قيد التنفيذ"
- If customer rejects the offer:
  status becomes "رفضه العميل"
- If customer has not viewed it:
  status remains "لم تتم المشاهدة"
- If customer viewed it but did not respond:
  status becomes "بانتظار الرد"

==================================================
4. REQUEST MANAGEMENT – إدارة الطلبات
==================================================

Purpose:
Manage both product purchase orders and accepted custom design requests.

At the top, use two main tabs:
- "طلبات الشراء"
- "طلبات التصميم"

--------------------------------
A. PRODUCT PURCHASE ORDERS
--------------------------------

These are orders where customers purchased ready-made products.

Status filter tags:
- قيد الانتظار
- قيد التجهيز
- تم الشحن
- مكتمل
- ملغي
- مرفوض

Each order card shows:
- Order number
- Product image
- Product name
- Customer name
- Quantity
- Total price
- Order date
- Current status

Interaction:
- Clicking the order navigates to Purchase Order Details

PURCHASE ORDER DETAILS:
Show:
- Customer details
- Product details
- Quantity
- Selected size or color
- Delivery address
- Payment status
- Order timeline

Buttons based on current status:
- Start processing
- Mark as ready
- Add shipping information
- Mark as shipped
- Mark as completed
- Contact customer

--------------------------------
B. CUSTOM DESIGN REQUESTS
--------------------------------

These are requests that the designer accepted and sent an offer for.

Status filter tags:
- بانتظار رد العميل
- لم تتم المشاهدة
- مقبول
- قيد التنفيذ
- مكتمل
- رفضه العميل
- ملغي

Each request card shows:
- Request title
- Customer name
- Agreed or proposed price
- Delivery time
- Current status
- Request type
- Date

Interaction:
- Clicking the request navigates to Custom Request Management Details

CUSTOM REQUEST MANAGEMENT DETAILS:
Show:
- Full request information
- Customer attachments
- Designer offer
- Proposed price
- Required time
- Customer response
- Timeline
- Messages shortcut

Available actions depend on status:
- Edit offer before customer acceptance
- Cancel offer
- Start project
- Update project progress
- Mark as completed
- Contact customer

==================================================
5. CHAT – المحادثات
==================================================

Purpose:
Chat only with customers connected to an actual request or product purchase.

Do not use category tabs.

Show one unified conversation list.

A conversation can exist only if:
- The customer sent a private request
- The designer responded to a public request
- The customer accepted an offer
- The customer purchased a product
- Either the customer or designer sent a message related to an order

Conversation list shows:
- Customer image
- Customer name
- Last message
- Time
- Unread count
- Related request or product title

Interaction:
- Clicking a conversation navigates to Chat Details

CHAT DETAILS SCREEN:
Show:
- Customer name
- Related order or request
- Message bubbles
- Send text
- Send images
- Send files
- View order or request button

Interaction:
- Clicking "عرض الطلب" navigates to the related request details
- Clicking "عرض الطلبية" navigates to the related purchase order details

==================================================
6. PROFILE – الملف الشخصي
==================================================

Purpose:
Manage designer account and settings.

Main Profile screen shows:
- Profile picture
- Designer name
- Fashion Designer label
- City
- Rating
- Number of completed requests
- Number of products

Menu options:

A. Edit Profile
Interaction:
- Navigates to Edit Profile screen

EDIT PROFILE SCREEN:
Allow editing:
- Profile picture
- Name
- Phone number
- Email
- City
- Bio
- Experience
- Fashion categories

Button:
"حفظ التغييرات"

Interaction:
- Saves changes and returns to Profile

B. Change Password
Interaction:
- Navigates to Change Password screen

CHANGE PASSWORD SCREEN:
Fields:
- Current password
- New password
- Confirm new password

Button:
"تحديث كلمة المرور"

C. Customer Reviews
Interaction:
- Navigates to Reviews screen

REVIEWS SCREEN:
Show reviews from customers after completed requests or completed purchases.

Display:
- Overall rating
- Star distribution
- Customer name
- Star rating
- Written review
- Related product or request
- Review date

D. Logout
Interaction:
- Opens confirmation modal

Buttons:
- Cancel
- Confirm Logout

After confirming logout:
- Navigate back to Designer Authentication screen

==================================================
GLOBAL NAVIGATION RULES
==================================================

Bottom navigation must stay consistent across all main screens.

Home icon:
- Opens الرئيسية

Products icon:
- Opens منتجاتي

Requests icon:
- Opens إدارة الطلبات

Chat icon:
- Opens المحادثات

Profile icon:
- Opens الملف الشخصي

The Browse Requests page should be accessible from:
- A clear button on the Home screen
- Pending Private Requests card
- A button inside Request Management titled "تصفح الطلبات"

Back arrows should return to the previous screen.

All interactive components must be connected in Prototype mode.

Create complete flows for:
- Sign up as Fashion Designer
- Add a new product
- Browse a request
- Accept a request
- Send price and completion time to customer
- Track customer response
- Manage a product purchase order
- Open a chat
- Edit profile
- Change password
- View reviews
- Logout

Use realistic Arabic content and realistic fashion images.

Do not include Interior or Exterior Designer screens after the designer chooses Fashion Design.