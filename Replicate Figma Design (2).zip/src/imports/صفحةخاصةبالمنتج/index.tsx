import svgPaths from "./svg-u8v6l7t9sh";
import img from "./ee35431d676a875aa5ae7e5f1b26846d02a54bb6.png";
import imgRectangle7 from "./a2450427e2d60469545cd2a9d3593112e3991812.png";
import imgRectangle4 from "./fc459e9d2b2e9d731d9cb730057f8f72c99ab219.png";
import imgRectangle5 from "./e95f5991a56dbfe6802893636c1ce37037098cf1.png";
import imgRectangle6 from "./fa01243dc520597280f40f520c3431927dd748dd.png";
import imgEllipse6 from "./35d8c113854c1eea6524ab15cb180c024290d8a0.png";

function Group6() {
  return (
    <div className="absolute contents left-[-9px] top-[1187px]">
      <div className="absolute h-[466px] left-[-9px] top-[2684px] w-[393px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgRectangle7} />
      </div>
      <div className="absolute h-[466px] left-[-9px] top-[1187px] w-[393px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgRectangle4} />
      </div>
      <div className="absolute h-[466px] left-[-9px] top-[1686px] w-[393px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgRectangle5} />
      </div>
      <div className="absolute h-[466px] left-[-9px] top-[2185px] w-[393px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgRectangle6} />
      </div>
      <p className="[word-break:break-word] absolute font-['Mont_Blanc-Trial:SemiBold',sans-serif] leading-[22px] left-[calc(50%+67.5px)] not-italic text-[14px] text-black top-[1205px] whitespace-nowrap" dir="auto">
        مها ديزاين
      </p>
      <p className="[word-break:break-word] absolute font-['Mont_Blanc-Trial:SemiBold',sans-serif] leading-[22px] left-[calc(50%+62.5px)] not-italic text-[14px] text-black top-[1704px] whitespace-nowrap" dir="auto">
        نوف ديزاين
      </p>
      <p className="[word-break:break-word] absolute font-['Mont_Blanc-Trial:SemiBold',sans-serif] leading-[22px] left-[calc(50%+59.5px)] not-italic text-[14px] text-black top-[2203px] whitespace-nowrap" dir="auto">
        خلود ديزاين
      </p>
      <p className="[word-break:break-word] absolute font-['Mont_Blanc-Trial:SemiBold',sans-serif] leading-[22px] left-[calc(50%+65.5px)] not-italic text-[14px] text-black top-[2704px] whitespace-nowrap" dir="auto">
        أمل ديزاين
      </p>
      <div className="absolute left-[calc(75%+43.75px)] size-[35px] top-[1200px]">
        <img alt="" className="absolute block inset-0 max-w-none size-full" height="35" src={imgEllipse6} width="35" />
      </div>
      <div className="absolute left-[calc(75%+43.75px)] size-[35px] top-[1699px]">
        <img alt="" className="absolute block inset-0 max-w-none size-full" height="35" src={imgEllipse6} width="35" />
      </div>
      <div className="absolute left-[calc(75%+43.75px)] size-[35px] top-[2198px]">
        <img alt="" className="absolute block inset-0 max-w-none size-full" height="35" src={imgEllipse6} width="35" />
      </div>
      <div className="absolute left-[calc(75%+43.75px)] size-[35px] top-[2697px]">
        <img alt="" className="absolute block inset-0 max-w-none size-full" height="35" src={imgEllipse6} width="35" />
      </div>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-[calc(25%+56.25px)] top-[43px]">
      <p className="[word-break:break-word] absolute font-['Abel:Regular',sans-serif] h-[39px] leading-[40px] left-[calc(25%+56.25px)] not-italic text-[16px] text-black top-[43px] w-[82px]" dir="auto">
        Amber design
      </p>
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents left-[17px] top-[43px]">
      <div className="absolute inset-[6.03%_78.93%_91.02%_14.67%]" data-name="Icon/Fill/24/message">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
          <g id="Icon/Fill/24/message">
            <g id="base" />
            <path clipRule="evenodd" d={svgPaths.p1e607580} fill="var(--fill-0, black)" fillRule="evenodd" id="Shape" />
          </g>
        </svg>
      </div>
      <div className="absolute inset-[6.03%_89.07%_91.02%_4.53%]" data-name="Icon/Fill/24/notify Copy">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
          <g id="Icon/24/search">
            <g id="base" />
            <path d={svgPaths.p16c64300} fill="var(--fill-0, #11243D)" id="Combined Shape" />
          </g>
        </svg>
      </div>
      <Group />
      <div className="absolute inset-[5.29%_5.07%_90.53%_85.87%]" data-name="User/Photo/48" />
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents left-[17px] top-[43px]">
      <Group4 />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute h-[11.333px] left-[6px] top-[9px] w-[62px]">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 62 11.3333">
        <g id="Group 9">
          <g id="Battery">
            <rect fill="var(--fill-0, black)" height="10.3333" id="Border" opacity="0.35" rx="2.16667" stroke="var(--stroke-0, black)" width="21" x="0.5" y="0.5" />
            <path d={svgPaths.p9ed9280} fill="var(--fill-0, black)" id="Cap" opacity="0.4" />
            <rect fill="var(--fill-0, black)" height="7.33333" id="Capacity" rx="1.33333" width="18" x="2" y="2" />
          </g>
          <path d={svgPaths.pd071100} fill="var(--fill-0, black)" id="Wifi" />
          <path d={svgPaths.pe790b00} fill="var(--fill-0, black)" id="Cellular Connection" />
        </g>
      </svg>
    </div>
  );
}

function Group2() {
  return (
    <div className="-translate-x-1/2 absolute contents left-1/2 top-[9px]">
      <Group1 />
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['SF_Pro_Text:Semibold',sans-serif] leading-[0] left-[calc(75%+60.75px)] not-italic text-[14px] text-black text-center top-[calc(50%-395.5px)] tracking-[-0.28px] w-[54px]">
        <span className="leading-[normal]">9:4</span>
        <span className="leading-[normal]">1</span>
      </p>
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute contents left-[6px] top-[9px]">
      <Group5 />
      <div className="absolute flex inset-[5.9%_-0.31%_91.12%_93.87%] items-center justify-center" style={{ containerType: "size" }}>
        <div className="flex-none h-[hypot(0.733691cqw,-99.2663cqh)] rotate-[-179.58deg] w-[hypot(-99.2663cqw,-0.733691cqh)]">
          <div className="relative size-full" data-name="Icon/Fill/24/chevron">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
              <g id="Icon/24/chevron">
                <g id="base" opacity="0.392787" />
                <path clipRule="evenodd" d={svgPaths.p32d1c920} fill="var(--fill-0, #11243D)" fillRule="evenodd" id="Path" />
              </g>
            </svg>
          </div>
        </div>
      </div>
      <Group2 />
    </div>
  );
}

function Tabbar() {
  return (
    <div className="absolute contents inset-0" data-name="Tabbar/1">
      <div className="absolute backdrop-blur-[13.591px] drop-shadow-[0px_-4px_4px_rgba(0,0,0,0.02)] inset-0" data-name="Rectangle" />
      <div className="absolute inset-[61.36%_0_0_0]" data-name="iPhone X/Home Indicator/Home Indicator - On Light">
        <div className="-translate-x-1/2 absolute bg-black bottom-[9px] h-[5px] left-[calc(50%+0.5px)] rounded-[100px] w-[134px]" />
      </div>
    </div>
  );
}

function Notify() {
  return (
    <div className="absolute contents inset-[88.68%_31.47%_5.41%_55.73%]" data-name="Notify">
      <div className="absolute inset-[88.68%_31.47%_5.41%_55.73%]" data-name="bound" />
      <div className="absolute inset-[89.54%_33.33%_6.27%_57.6%]" data-name="Icon/Outline/34/explore">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 34">
          <g id="Icon/Outline/34/explore">
            <g id="base" />
            <path d={svgPaths.p85dac00} fill="var(--fill-0, black)" id="Combined Shape" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute contents left-[calc(50%+21.5px)] top-[721px]">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Medium','Noto_Sans_Arabic:Medium',sans-serif] font-medium leading-[normal] left-[calc(50%+45.5px)] not-italic text-[#261732] text-[8px] text-center top-[758px] tracking-[-0.2px] whitespace-nowrap" dir="auto">
        اكسبلور
      </p>
      <Notify />
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute contents left-[calc(25%+30.25px)] top-[728px]">
      <div className="absolute inset-[89.54%_57.87%_6.27%_33.07%]" data-name="Icon/Fill/34/notify">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 34">
          <g id="Icon/Outline/34/notify">
            <g id="base" />
            <path clipRule="evenodd" d={svgPaths.p1189d440} fill="var(--fill-0, black)" fillRule="evenodd" id="Shape" />
          </g>
        </svg>
      </div>
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Medium','Noto_Sans_Arabic:Medium',sans-serif] font-medium leading-[normal] left-[calc(25%+47.25px)] not-italic text-[#261732] text-[8px] text-center top-[758px] tracking-[-0.2px] whitespace-nowrap" dir="auto">
        الإشعارات
      </p>
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents left-[calc(75%+29.75px)] top-[728px]">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Medium','Noto_Sans_Arabic:Medium',sans-serif] font-medium leading-[normal] left-[calc(75%+45.75px)] not-italic text-[#261732] text-[8px] text-center top-[758px] tracking-[-0.2px] whitespace-nowrap" dir="auto">
        الرئيسية
      </p>
      <div className="absolute inset-[89.54%_8%_6.27%_82.93%]" data-name="Icon/Fill/34/home">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 34">
          <g id="Icon/Fill/34/home">
            <g id="base" />
            <path d={svgPaths.p15216880} fill="var(--fill-0, black)" id="Combined Shape" opacity="0.8" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents inset-[93.23%_84.8%_5.54%_9.33%]">
      <p className="[word-break:break-word] absolute font-['Inter:Medium','Noto_Sans_Arabic:Medium',sans-serif] font-medium inset-[93.23%_84.8%_5.54%_9.33%] leading-[normal] not-italic text-[#261732] text-[8px] text-center tracking-[-0.2px] whitespace-nowrap" dir="auto">
        حسابي
      </p>
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute contents inset-[93.23%_84.8%_5.54%_9.33%]">
      <Group3 />
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute contents left-0 top-[721px]">
      <div className="absolute bg-[rgba(0,0,0,0)] h-[88px] left-0 top-[725px] w-[375px]" data-name="Tabbar/1">
        <Tabbar />
      </div>
      <Group10 />
      <Group8 />
      <Group7 />
      <Group9 />
      <div className="absolute bg-black h-[5px] left-[calc(25%+26.25px)] rounded-[2.5px] top-[799px] w-[134px]" />
    </div>
  );
}

export default function Component() {
  return (
    <div className="relative size-full" data-name="صفحة خاصة بالمنتج">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={img} />
      <div className="absolute bg-[rgba(217,217,217,0.2)] h-[53px] left-[42px] rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.25)] top-[414px] w-[295px]" />
      <div className="absolute bg-[rgba(217,217,217,0.2)] h-[53px] left-[40px] rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.25)] top-[337px] w-[295px]" />
      <div className="absolute bg-[rgba(217,217,217,0.2)] h-[56px] left-0 rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.25)] top-[33px] w-[376px]" />
      <p className="[word-break:break-word] absolute font-['Noto_Sans_Bengali:Light','Noto_Sans_Arabic:Light',sans-serif] font-light leading-[22px] left-[calc(25%+45.25px)] text-[15px] text-black top-[426px] w-[105px]" dir="auto" style={{ fontVariationSettings: '"wdth" 100' }}>
        مصممين الديكور
      </p>
      <Group6 />
      <Group12 />
      <Group11 />
      <p className="[word-break:break-word] absolute font-['Noto_Sans_Bengali:Thin','Noto_Sans_Arabic:Light',sans-serif] font-thin leading-[22px] left-[calc(25%+50.25px)] text-[15px] text-black top-[353px] w-[94px]" dir="auto" style={{ fontVariationSettings: '"wdth" 100' }}>
        مصممين الأزياء
      </p>
      <div className="absolute left-[36px] overflow-clip size-[20px] top-[738px]" data-name="User">
        <div className="absolute inset-[12.5%_16.67%]" data-name="Icon">
          <div className="absolute inset-[-6.67%_-7.5%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.3333 17">
              <path d={svgPaths.p205a9bf0} id="Icon" stroke="var(--stroke-0, #1E1E1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}