import { useState } from "react";
import {
  Search, Bell, MessageSquare, Eye, EyeOff, Upload, CheckCircle,
  ArrowRight, Home, User, ChevronRight, ClipboardList,
  Briefcase, Settings, LogOut, X, ChevronDown, Phone, Mail, HelpCircle,
  MapPin, Star, Award, Package, Plus, ShoppingBag, Send,
} from "lucide-react";
import bgAbstract from "@/imports/image.png";
import amberLogo from "@/imports/IMG_0442.png";
import imgAvatar from "@/imports/صفحةخاصةبالمنتج/35d8c113854c1eea6524ab15cb180c024290d8a0.png";

// ── Dress image pool from Unsplash ───────────────────────────────────────────
const D = {
  evening: "https://images.unsplash.com/photo-1603122630570-7fd434d470d0?w=400&h=560&fit=crop&auto=format",
  wedding: "https://images.unsplash.com/photo-1622277430358-f4d134452e2e?w=400&h=560&fit=crop&auto=format",
  party:   "https://images.unsplash.com/photo-1606489236892-ed5989dd023a?w=400&h=560&fit=crop&auto=format",
  unique:  "https://images.unsplash.com/photo-1733324961705-97bd6cd7f4ba?w=400&h=560&fit=crop&auto=format",
  white:   "https://images.unsplash.com/photo-1571924848943-25c2c95bbb4b?w=400&h=560&fit=crop&auto=format",
  bridal:  "https://images.unsplash.com/photo-1549416878-b9ca95e26903?w=400&h=560&fit=crop&auto=format",
  runway:  "https://images.unsplash.com/photo-1733322991133-2de13aa12c57?w=400&h=560&fit=crop&auto=format",
  blue:    "https://images.unsplash.com/photo-1622079401116-8317808352d9?w=400&h=560&fit=crop&auto=format",
  red:     "https://images.unsplash.com/photo-1571924849183-a68a3879348d?w=400&h=560&fit=crop&auto=format",
  black:   "https://images.unsplash.com/photo-1568251188392-ae32f898cb3b?w=400&h=560&fit=crop&auto=format",
};

// ── Data ─────────────────────────────────────────────────────────────────────

type Screen = "splash" | "roleSelect" | "designerAuth" | "designerSignUp" | "designerField" | "designerProfileSetup"
  | "onboarding" | "login" | "home"
  | "designRequest" | "reviewOrder" | "payment" | "paymentSuccess"
  | "myOrders" | "orderTracking" | "profile"
  | "settings" | "editProfile" | "helpSupport" | "designerPortfolio"
  | "userChats" | "userChatDetails"
  // ── Interior/Exterior Designer App ──
  | "dHome" | "dBrowseRequests" | "dRequestDetails" | "dCreateOffer"
  | "dManageRequests" | "dManageDetails"
  | "dChats" | "dChatDetails"
  | "dProfile" | "dEditProfile" | "dChangePassword" | "dReviews" | "dPortfolioEditor"
  | "fProfileSetup" | "fHome" | "fProducts" | "fAddProduct" | "fProductDetails"
  | "fBrowseRequests" | "fRequestDetails" | "fCreateOffer"
  | "fManageRequests" | "fManageDetails"
  | "fChats" | "fChatDetails"
  | "fProfile" | "fEditProfile" | "fChangePassword" | "fReviews" | "fPortfolioEditor";
type Role = "user" | "designer" | null;

interface Order {
  id: string; service: string; designer: string;
  status: "قيد التنفيذ" | "مكتمل" | "قيد المراجعة" | "تم التقديم";
  date: string; price: string; img: string;
}

const ALL_ORDERS: Order[] = [
  { id: "#12345", service: "فستان سهرة",  designer: "مها ديزاين",   status: "قيد التنفيذ",   date: "١٣ يوليو ٢٠٢٥", price: "٤٨٠ ر.س", img: D.evening },
  { id: "#12344", service: "فستان زواج",  designer: "نوف ديزاين",   status: "مكتمل",          date: "١٠ يوليو ٢٠٢٥", price: "٨٥٠ ر.س", img: D.bridal  },
  { id: "#12340", service: "فستان حفل",   designer: "خلود ديزاين",  status: "قيد المراجعة",   date: "٥ يوليو ٢٠٢٥",  price: "٣٢٠ ر.س", img: D.party   },
  { id: "#12335", service: "فستان غريب",  designer: "أمل ديزاين",   status: "تم التقديم",     date: "١ يوليو ٢٠٢٥",  price: "٦٠٠ ر.س", img: D.unique  },
];

const DRESS_CATS = [
  { label: "سهرة",   img: D.evening },
  { label: "زواج",   img: D.bridal  },
  { label: "حفل",    img: D.party   },
  { label: "غريب",   img: D.unique  },
  { label: "كاجوال", img: D.white   },
  { label: "سواريه", img: D.runway  },
  { label: "أحمر",   img: D.red     },
  { label: "أسود",   img: D.black   },
];

// Individual designer avatars from Unsplash
const AVA = {
  maha:   "https://images.unsplash.com/photo-1638433429483-a188db3d3b53?w=120&h=120&fit=crop&auto=format",
  nouf:   "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&h=120&fit=crop&auto=format",
  kholod: "https://images.unsplash.com/photo-1613447895817-e617a4093f50?w=120&h=120&fit=crop&auto=format",
  amal:   "https://images.unsplash.com/photo-1536766768598-e09213fdcf22?w=120&h=120&fit=crop&auto=format",
  sara:   "https://images.unsplash.com/photo-1611451444023-7fe9d86fe1d0?w=120&h=120&fit=crop&auto=format",
  reem:   "https://images.unsplash.com/photo-1718230800381-1b7ee3bfb2bd?w=120&h=120&fit=crop&auto=format",
};

interface Designer {
  name: string; specialty: string; rating: number; orders: number;
  img: string; avatar: string; location: string; reviews: number;
  portfolio: string[];
}

const FEATURED: Designer[] = [
  {
    name: "مها ديزاين", specialty: "فساتين سهرة", rating: 4.9, orders: 128, reviews: 84,
    location: "الرياض، المملكة العربية السعودية",
    img: D.evening, avatar: AVA.maha,
    portfolio: [D.evening, D.black, D.red, D.blue, D.party, D.white, D.runway, D.unique],
  },
  {
    name: "نوف ديزاين", specialty: "فساتين زواج", rating: 4.8, orders: 96, reviews: 61,
    location: "جدة، المملكة العربية السعودية",
    img: D.bridal, avatar: AVA.nouf,
    portfolio: [D.bridal, D.wedding, D.white, D.unique, D.evening, D.blue, D.party, D.black],
  },
  {
    name: "خلود ديزاين", specialty: "فساتين حفلات", rating: 4.7, orders: 84, reviews: 52,
    location: "الدمام، المملكة العربية السعودية",
    img: D.party, avatar: AVA.kholod,
    portfolio: [D.party, D.evening, D.runway, D.red, D.blue, D.bridal, D.black, D.white],
  },
  {
    name: "أمل ديزاين", specialty: "فساتين مبتكرة", rating: 4.7, orders: 72, reviews: 47,
    location: "أبها، المملكة العربية السعودية",
    img: D.unique, avatar: AVA.amal,
    portfolio: [D.unique, D.runway, D.black, D.red, D.evening, D.party, D.white, D.bridal],
  },
  {
    name: "سارة ديزاين", specialty: "فساتين كاجوال", rating: 4.6, orders: 61, reviews: 39,
    location: "مكة المكرمة، المملكة العربية السعودية",
    img: D.white, avatar: AVA.sara,
    portfolio: [D.white, D.blue, D.party, D.unique, D.black, D.evening, D.runway, D.wedding],
  },
  {
    name: "ريم ديزاين", specialty: "فساتين سواريه", rating: 4.6, orders: 55, reviews: 34,
    location: "المدينة المنورة، المملكة العربية السعودية",
    img: D.runway, avatar: AVA.reem,
    portfolio: [D.runway, D.evening, D.blue, D.bridal, D.red, D.unique, D.party, D.white],
  },
];

const SEARCH_ITEMS = [
  "مها ديزاين", "نوف ديزاين", "خلود ديزاين", "أمل ديزاين", "سارة ديزاين", "ريم ديزاين",
  "فستان سهرة", "فستان زواج", "فستان حفل", "فستان غريب",
  "فستان كاجوال", "فستان سواريه", "فساتين سهرة", "فساتين زواج",
];

const SPEC_OPTIONS: Record<string, string[]> = {
  "المقاس":  ["XS", "S", "M", "L", "XL", "حسب الطلب"],
  "اللون":   ["أبيض", "أسود", "أحمر", "ذهبي", "بيج", "حسب الطلب"],
  "القماش":  ["حرير", "ساتان", "دانتيل", "شيفون", "حسب الطلب"],
  "الطول":   ["طويل", "متوسط", "قصير"],
};
const INTERIOR_SPEC_OPTIONS: Record<string, string[]> = {
  "نوع المشروع":  ["غرفة نوم", "غرفة معيشة", "مطبخ", "مكتب", "حمام", "فيلا كاملة", "شقة كاملة"],
  "الأسلوب":     ["عصري", "كلاسيكي", "بوهيمي", "مينيمالستي", "فاخر", "عربي أصيل"],
  "الميزانية":   ["أقل من ١٠٠٠٠", "١٠٠٠٠–٣٠٠٠٠", "٣٠٠٠٠–٦٠٠٠٠", "أكثر من ٦٠٠٠٠"],
  "المساحة":     ["أقل من ٢٠م²", "٢٠–٥٠م²", "٥٠–١٠٠م²", "أكثر من ١٠٠م²"],
};

const STATUS_COLOR: Record<string, string> = {
  "قيد التنفيذ":  "bg-blue-100/70 text-blue-800",
  "مكتمل":        "bg-green-100/70 text-green-800",
  "قيد المراجعة": "bg-yellow-100/70 text-yellow-800",
  "تم التقديم":   "bg-gray-100/70 text-gray-700",
};

// ── Shared primitives ─────────────────────────────────────────────────────────

function ScreenBg({ children, overlay = "bg-[#f0e8df]/55" }: { children: React.ReactNode; overlay?: string }) {
  return (
    <div className="relative h-full overflow-hidden">
      <img src={bgAbstract} alt="" aria-hidden
        className="absolute inset-0 w-full h-full object-cover pointer-events-none select-none" />
      <div className={`absolute inset-0 ${overlay}`} />
      <div className="relative z-10 h-full flex flex-col">{children}</div>
    </div>
  );
}

function Pill({ children, onClick, className = "", dark = false }: {
  children: React.ReactNode; onClick?: () => void; className?: string; dark?: boolean;
}) {
  return (
    <button onClick={onClick}
      className={`rounded-[50px] backdrop-blur-sm transition-all ${dark
        ? "bg-[#261732]/80 shadow-[0px_4px_8px_rgba(38,23,50,0.35)]"
        : "bg-[rgba(217,217,217,0.28)] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.18)]"
      } ${className}`}>
      {children}
    </button>
  );
}

function Logo({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const s = { sm: "w-28 h-28", md: "w-40 h-40", lg: "w-56 h-56" };
  return (
    <img src={amberLogo} alt="Amber Design" className={`${s[size]} object-contain`} style={{ mixBlendMode: "multiply" }} />
  );
}

const AR = { fontFamily: "'Noto Sans Arabic', sans-serif" };

const TRANS: Record<string, Record<"ar"|"en", string>> = {
  "الرئيسية":          { ar:"الرئيسية",          en:"Home" },
  "البحث":             { ar:"البحث",              en:"Search" },
  "طلب تصميم":         { ar:"طلب تصميم",          en:"Request Design" },
  "طلباتي":            { ar:"طلباتي",             en:"My Orders" },
  "حسابي":             { ar:"حسابي",              en:"Profile" },
  "أبرز المصممين":     { ar:"أبرز المصممين",      en:"Top Designers" },
  "تصميم ديكور":       { ar:"تصميم ديكور",        en:"Decor Design" },
  "أبرز مصممي الديكور":{ ar:"أبرز مصممي الديكور", en:"Top Decor Designers" },
  "أنواع الفساتين":    { ar:"أنواع الفساتين",     en:"Dress Types" },
  "عرض الكل":          { ar:"عرض الكل",           en:"View All" },
  "طلب":               { ar:"طلب",               en:"Request" },
  "الإعدادات":         { ar:"الإعدادات",          en:"Settings" },
  "الإشعارات":         { ar:"الإشعارات",          en:"Notifications" },
  "المحادثات":         { ar:"المحادثات",          en:"Chats" },
  "ملفي الشخصي":       { ar:"ملفي الشخصي",        en:"My Profile" },
  "تسجيل الخروج":      { ar:"تسجيل الخروج",       en:"Logout" },
  "اكتبي للبحث...":    { ar:"اكتبي للبحث...",     en:"Search..." },
};
function tr(key: string, lang: "ar"|"en"): string {
  return TRANS[key]?.[lang] ?? key;
}

// ── Language toggle ───────────────────────────────────────────────────────────
function LangToggle({ lang, setLang }: { lang: "ar" | "en"; setLang: (l: "ar" | "en") => void }) {
  return (
    <button onClick={() => setLang(lang === "ar" ? "en" : "ar")}
      className="flex items-center gap-0.5 bg-[rgba(217,217,217,0.35)] backdrop-blur-sm rounded-full px-2.5 py-1 border border-[#261732]/10 hover:bg-[rgba(217,217,217,0.55)] transition-colors">
      <span className={`text-[10px] font-bold transition-colors ${lang === "en" ? "text-[#261732]" : "text-[#261732]/35"}`}>EN</span>
      <span className="text-[9px] text-[#261732]/25 mx-0.5">|</span>
      <span className={`text-[10px] font-bold transition-colors ${lang === "ar" ? "text-[#261732]" : "text-[#261732]/35"}`} style={{ fontFamily: "'Noto Sans Arabic', sans-serif" }}>ع</span>
    </button>
  );
}



// ── App Root ──────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen]               = useState<Screen>("splash");
  const [lang, setLang]                   = useState<"ar"|"en">("ar");
  const [role, setRole]                   = useState<Role>(null);
  const [onboardIdx, setOnboardIdx]       = useState(0);
  const [showPass, setShowPass]           = useState(false);
  const [email, setEmail]                 = useState("");
  const [password, setPassword]           = useState("");
  const [designType, setDesignType]       = useState("");
  const [requestMode, setRequestMode]     = useState<"choose"|"fashion"|"decor">("choose");
  const [description, setDescription]     = useState("");
  const [specs, setSpecs]                 = useState<Record<string, string>>({});
  const [paymentMethod, setPaymentMethod] = useState("credit");
  const [userOrders, setUserOrders]       = useState<Order[]>(ALL_ORDERS);
  const [activeTab, setActiveTab]         = useState("home");
  const [sidebarOpen, setSidebarOpen]     = useState(false);
  const [userChatId, setUserChatId]       = useState(0);
  const [searchQuery, setSearchQuery]       = useState("");
  const [searchFocused, setSearchFocused]   = useState(false);
  const [selectedOrder, setSelectedOrder]   = useState<Order | null>(null);
  const [selectedDesigner, setSelectedDesigner]   = useState<Designer | null>(null);
  const [designerField, setDesignerField]         = useState("");
  const [dTab, setDTab]                           = useState<"home"|"browse"|"manage"|"chat"|"profile">("home");
  const [dBrowseTab, setDBrowseTab]               = useState<"public"|"private">("public");
  const [dSelectedRequest, setDSelectedRequest]   = useState<IDRequest | null>(null);
  const [dSelectedChat, setDSelectedChat]         = useState<IDChat | null>(null);
  const [dManageTab, setDManageTab]               = useState("pending");
  const [fTab, setFTab]                           = useState<FTab>("home");
  const [fBrowseTab, setFBrowseTab]               = useState<"public"|"private">("public");
  const [fManageTab, setFManageTab]               = useState<"orders"|"requests">("orders");
  const [fManageStatusTab, setFManageStatusTab]   = useState("الكل");
  const [fSelectedProduct, setFSelectedProduct]   = useState<FProduct | null>(null);
  const [fSelectedRequest, setFSelectedRequest]   = useState<FRequest | null>(null);
  const [fSelectedOrder, setFSelectedOrder]       = useState<FOrder | null>(null);
  const [fSelectedChat, setFSelectedChat]         = useState<FChat | null>(null);

  const go = (s: Screen) => { setScreen(s); setSidebarOpen(false); };
  const gof = (t: FTab) => { setFTab(t); const m: Record<FTab, Screen> = { home:"fHome", products:"fProducts", browse:"fBrowseRequests", manage:"fManageRequests", chats:"fChats", profile:"fProfile" }; go(m[t]); };
  const toggleSpec = (cat: string, val: string) =>
    setSpecs(p => ({ ...p, [cat]: p[cat] === val ? "" : val }));
  const goDesigner = (d: Designer) => { setSelectedDesigner(d); go("designerPortfolio"); };

  return (
    <div className="min-h-screen bg-[#e4d8ce] flex items-center justify-center p-4"
      style={{ fontFamily: "'Inter', 'Noto Sans Arabic', sans-serif" }}>
      <div className="relative w-[390px] h-[844px] rounded-[44px] shadow-2xl overflow-hidden border-[3px] border-[#261732]/70 flex flex-col bg-[#f0e8df]">

        {/* status bar */}
        <div className="flex-shrink-0 h-11 flex items-center justify-between px-8 text-[11px] font-semibold text-[#261732] z-30">
          <span style={{ fontFamily: "'Abel', sans-serif", letterSpacing: "0.04em" }}>9:41</span>
          <div className="flex items-center gap-1"><span className="text-[10px]">●●●</span><span>WiFi</span><span>▮</span></div>
        </div>

        <div className="flex-1 overflow-hidden relative">
          {screen === "splash"          && <SplashScreen onNext={() => go("roleSelect")} lang={lang} setLang={setLang} />}
          {screen === "roleSelect"      && <RoleSelectScreen onBack={() => go("splash")} onSelectUser={() => { setRole("user"); go("onboarding"); }} onSelectDesigner={() => { setRole("designer"); go("designerAuth"); }} lang={lang} setLang={setLang} />}
          {screen === "designerAuth"       && <DesignerAuthScreen onBack={() => go("roleSelect")} onSignIn={() => go("designerSignUp")} onLogin={() => go(designerField === "fashion" ? "fHome" : "dHome")} />}
          {screen === "designerSignUp"     && <DesignerSignUpScreen onBack={() => go("designerAuth")} onNext={() => go("designerField")} />}
          {screen === "designerField"      && <DesignerFieldScreen onBack={() => go("designerSignUp")} onDone={(f) => { setDesignerField(f); go(f === "fashion" ? "fProfileSetup" : "designerProfileSetup"); }} />}
          {screen === "designerProfileSetup" && <DesignerProfileSetupScreen field={designerField} onBack={() => go("designerField")} onDone={() => go("dHome")} />}
          {screen === "dHome"              && <DHome onTab={(t) => { setDTab(t); go(t === "home" ? "dHome" : t === "browse" ? "dBrowseRequests" : t === "manage" ? "dManageRequests" : t === "chat" ? "dChats" : "dProfile"); }} activeTab={dTab} onPendingCard={() => { setDBrowseTab("private"); go("dBrowseRequests"); }} onRating={() => go("dReviews")} onPortfolio={() => go("dPortfolioEditor")} />}
          {screen === "dBrowseRequests"   && <DBrowseRequests activeTab={dBrowseTab} setActiveTab={setDBrowseTab} onTab={(t) => { setDTab(t); go(t === "home" ? "dHome" : t === "browse" ? "dBrowseRequests" : t === "manage" ? "dManageRequests" : t === "chat" ? "dChats" : "dProfile"); }} dTab={dTab} onRequest={(r) => { setDSelectedRequest(r); go("dRequestDetails"); }} />}
          {screen === "dRequestDetails"   && <DRequestDetails request={dSelectedRequest} onBack={() => go("dBrowseRequests")} onAccept={() => go("dCreateOffer")} onReject={() => go("dBrowseRequests")} />}
          {screen === "dCreateOffer"      && <DCreateOffer request={dSelectedRequest} onBack={() => go("dRequestDetails")} onSend={() => { setDManageTab("waiting"); go("dManageRequests"); }} />}
          {screen === "dManageRequests"   && <DManageRequests activeTab={dManageTab} setActiveTab={setDManageTab} onTab={(t) => { setDTab(t); go(t === "home" ? "dHome" : t === "browse" ? "dBrowseRequests" : t === "manage" ? "dManageRequests" : t === "chat" ? "dChats" : "dProfile"); }} dTab={dTab} onRequest={(r) => { setDSelectedRequest(r); go("dManageDetails"); }} />}
          {screen === "dManageDetails"    && <DManageDetails request={dSelectedRequest} onBack={() => go("dManageRequests")} onChat={() => go("dChatDetails")} />}
          {screen === "dChats"            && <DChats onTab={(t) => { setDTab(t); go(t === "home" ? "dHome" : t === "browse" ? "dBrowseRequests" : t === "manage" ? "dManageRequests" : t === "chat" ? "dChats" : "dProfile"); }} dTab={dTab} onChat={(c) => { setDSelectedChat(c); go("dChatDetails"); }} />}
          {screen === "dChatDetails"      && <DChatDetails chat={dSelectedChat} onBack={() => go("dChats")} onViewRequest={() => go("dManageDetails")} />}
          {screen === "dProfile"          && <DProfile field={designerField} onTab={(t) => { setDTab(t); go(t === "home" ? "dHome" : t === "browse" ? "dBrowseRequests" : t === "manage" ? "dManageRequests" : t === "chat" ? "dChats" : "dProfile"); }} dTab={dTab} onEdit={() => go("dEditProfile")} onPassword={() => go("dChangePassword")} onReviews={() => go("dReviews")} onLogout={() => go("designerAuth")} />}
          {screen === "dEditProfile"      && <DEditProfile onBack={() => go("dProfile")} />}
          {screen === "dChangePassword"   && <DChangePassword onBack={() => go("dProfile")} />}
          {screen === "dReviews"          && <DReviews onBack={() => go("dProfile")} />}
          {screen === "dPortfolioEditor"  && <DPortfolioEditor onBack={() => go("dHome")} />}
          {screen === "fProfileSetup"    && <FProfileSetup onBack={() => go("designerField")} onDone={() => { setFTab("home"); go("fHome"); }} />}
          {screen === "fHome"            && <FHome fTab={fTab} onTab={gof} onPending={() => { setFBrowseTab("private"); gof("browse"); }} onOrders={() => { setFManageTab("orders"); setFManageStatusTab("قيد الانتظار"); gof("manage"); }} onRating={() => go("fReviews")} onPortfolio={() => go("fPortfolioEditor")} />}
          {screen === "fProducts"        && <FProducts fTab={fTab} onTab={gof} onProduct={(p) => { setFSelectedProduct(p); go("fProductDetails"); }} onAdd={() => go("fAddProduct")} />}
          {screen === "fAddProduct"      && <FAddProduct onBack={() => go("fProducts")} onSave={() => go("fProducts")} />}
          {screen === "fProductDetails"  && <FProductDetails product={fSelectedProduct} onBack={() => go("fProducts")} />}
          {screen === "fBrowseRequests"  && <FBrowseRequests fTab={fTab} onTab={gof} activeTab={fBrowseTab} setActiveTab={setFBrowseTab} onRequest={(r) => { setFSelectedRequest(r); go("fRequestDetails"); }} />}
          {screen === "fRequestDetails"  && <FRequestDetails request={fSelectedRequest} onBack={() => go("fBrowseRequests")} onAccept={() => go("fCreateOffer")} onReject={() => go("fBrowseRequests")} />}
          {screen === "fCreateOffer"     && <FCreateOffer request={fSelectedRequest} onBack={() => go("fRequestDetails")} onSend={() => { setFManageTab("requests"); setFManageStatusTab("بانتظار رد العميل"); gof("manage"); }} />}
          {screen === "fManageRequests"  && <FManageRequests fTab={fTab} onTab={gof} mainTab={fManageTab} setMainTab={setFManageTab} statusTab={fManageStatusTab} setStatusTab={setFManageStatusTab} onOrder={(o) => { setFSelectedOrder(o); go("fManageDetails"); }} onRequest={(r) => { setFSelectedRequest(r); go("fManageDetails"); }} />}
          {screen === "fManageDetails"   && <FManageDetails order={fManageTab === "orders" ? fSelectedOrder : null} request={fManageTab === "requests" ? fSelectedRequest : null} onBack={() => go("fManageRequests")} onChat={() => go("fChatDetails")} />}
          {screen === "fChats"           && <FChats fTab={fTab} onTab={gof} onChat={(c) => { setFSelectedChat(c); go("fChatDetails"); }} />}
          {screen === "fChatDetails"     && <FChatDetails chat={fSelectedChat} onBack={() => go("fChats")} onViewRequest={() => go("fManageDetails")} />}
          {screen === "fProfile"         && <FProfile fTab={fTab} onTab={gof} onEdit={() => go("fEditProfile")} onPassword={() => go("fChangePassword")} onReviews={() => go("fReviews")} onLogout={() => go("designerAuth")} />}
          {screen === "fEditProfile"     && <FEditProfile onBack={() => go("fProfile")} />}
          {screen === "fChangePassword"  && <FChangePassword onBack={() => go("fProfile")} />}
          {screen === "fReviews"         && <FReviews onBack={() => go("fProfile")} />}
          {screen === "fPortfolioEditor" && <FPortfolioEditor onBack={() => go("fHome")} />}
          {screen === "onboarding"      && <OnboardingScreen role={role} idx={onboardIdx} setIdx={setOnboardIdx} onDone={() => go("login")} />}
          {screen === "login"           && <LoginScreen role={role} email={email} setEmail={setEmail} password={password} setPassword={setPassword} showPass={showPass} setShowPass={setShowPass} onLogin={() => go("home")} onSignUp={() => { setRole(null); setOnboardIdx(0); go("roleSelect"); }} onBack={() => go("roleSelect")} lang={lang} setLang={setLang} />}
          {screen === "home"             && <HomeScreen role={role} activeTab={activeTab} setActiveTab={setActiveTab} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} searchQuery={searchQuery} setSearchQuery={setSearchQuery} searchFocused={searchFocused} setSearchFocused={setSearchFocused} onRequest={(type, mode) => { if (type) setDesignType(type); setRequestMode(mode ?? "choose"); go("designRequest"); }} onProfile={() => go("profile")} onOrders={() => go("myOrders")} onChats={() => go("userChats")} onSettings={() => go("settings")} onLogout={() => { setRole(null); setOnboardIdx(0); go("roleSelect"); }} onDesigner={goDesigner} lang={lang} />}
          {screen === "designRequest"    && <DesignRequestScreen role={role} mode={requestMode} designType={designType} setDesignType={setDesignType} description={description} setDescription={setDescription} specs={specs} toggleSpec={toggleSpec} onBack={() => go("home")} onNext={() => go("reviewOrder")} />}
          {screen === "reviewOrder"      && <ReviewOrderScreen service={designType || "فستان سهرة"} specs={specs} description={description} mode={requestMode} onBack={() => go("designRequest")} onContinue={() => go("payment")} />}
          {screen === "payment"          && <PaymentScreen method={paymentMethod} setMethod={setPaymentMethod} onBack={() => go("reviewOrder")} onPay={() => {
            const isDecor = requestMode === "decor" || ["غرفة","مطبخ","مكتب","فيلا","شقة","حمام","خارجي"].some(k => designType.includes(k));
            const newOrder: Order = {
              id: `#${Math.floor(10000 + Math.random() * 90000)}`,
              service: designType || "تصميم جديد",
              designer: isDecor ? "ليلى الزهراني" : "مها ديزاين",
              status: "تم التقديم",
              date: new Date().toLocaleDateString("ar-SA"),
              price: isDecor ? "٨٥٠ ر.س" : "٤٨٠ ر.س",
              img: isDecor ? ID.living : D.evening,
            };
            setUserOrders(prev => [newOrder, ...prev]);
            go("paymentSuccess");
          }} />}
          {screen === "paymentSuccess"   && <PaymentSuccessScreen onView={() => go("myOrders")} />}
          {screen === "myOrders"         && <MyOrdersScreen orders={userOrders} selectedOrder={selectedOrder} setSelectedOrder={setSelectedOrder} onBack={() => go("home")} onTracking={(o) => { setSelectedOrder(o); go("orderTracking"); }} />}
          {screen === "orderTracking"    && <OrderTrackingScreen order={selectedOrder || ALL_ORDERS[0]} onBack={() => go("myOrders")} />}
          {screen === "profile"          && <ProfileScreen role={role} onBack={() => go("home")} onOrders={() => go("myOrders")} onSettings={() => go("settings")} onEditProfile={() => go("editProfile")} onHelp={() => go("helpSupport")} onLogout={() => { setRole(null); setOnboardIdx(0); go("roleSelect"); }} />}
          {screen === "settings"         && <SettingsScreen onBack={() => go("profile")} lang={lang} setLang={setLang} />}
          {screen === "editProfile"      && <EditProfileScreen role={role} onBack={() => go("profile")} />}
          {screen === "helpSupport"      && <HelpSupportScreen onBack={() => go("profile")} />}
          {screen === "designerPortfolio"&& <DesignerPortfolioScreen designer={selectedDesigner || FEATURED[0]} onBack={() => go("home")} onRequest={() => go("designRequest")} />}
          {screen === "userChats"        && <UserChatsScreen onBack={() => go("home")} onChat={(id) => { setUserChatId(id); go("userChatDetails"); }} />}
          {screen === "userChatDetails"  && <UserChatDetailScreen chatId={userChatId} onBack={() => go("userChats")} />}
        </div>
      </div>
    </div>
  );
}

// ── 1. Splash ─────────────────────────────────────────────────────────────────

function SplashScreen({ onNext, lang, setLang }: { onNext: () => void; lang: "ar"|"en"; setLang: (l: "ar"|"en") => void }) {
  return (
    <ScreenBg overlay="bg-[#f0e8df]/45">
      <div className="flex-1 flex flex-col items-center justify-center">
        <Logo size="lg" />
      </div>
      <div className="px-8 pb-14">
        <Pill dark onClick={onNext} className="w-full py-4 flex items-center justify-center">
          <span className="text-[#f0e8df] font-semibold text-sm tracking-wide" style={AR}>التالي</span>
        </Pill>
      </div>
    </ScreenBg>
  );
}

// ── 2. Role Select ────────────────────────────────────────────────────────────

function RoleSelectScreen({ onSelectUser, onSelectDesigner, onBack, lang, setLang }: {
  onSelectUser: () => void; onSelectDesigner: () => void; onBack: () => void; lang: "ar"|"en"; setLang: (l: "ar"|"en") => void;
}) {
  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex-shrink-0 flex items-center justify-between px-4 pt-3 pb-1">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-[rgba(217,217,217,0.3)] transition-colors">
          <ArrowRight size={20} className="text-[#261732]" />
        </button>
        <LangToggle lang={lang} setLang={setLang} />
      </div>
      <div className="flex-1 flex flex-col items-center justify-center px-8 gap-6">
        <Logo size="lg" />
        <div className="text-center mb-2">
          <h2 className="text-[#261732] text-xl font-semibold" style={AR}>من أنت؟</h2>
          <p className="text-[#5a4a5e] text-sm mt-1" style={AR}>اختر نوع حسابك للمتابعة</p>
        </div>

        <button onClick={onSelectUser}
          className="w-full bg-[rgba(217,217,217,0.28)] backdrop-blur-sm rounded-[28px] shadow-[0px_4px_12px_rgba(0,0,0,0.15)] p-5 flex items-center gap-4 hover:bg-[rgba(217,217,217,0.4)] transition-all">
          <ChevronRight size={18} className="text-[#261732]/40 flex-shrink-0" />
          <div className="text-right flex-1" dir="rtl">
            <p className="font-bold text-[#261732] text-base" style={AR}>دخول كمستخدم</p>
            <p className="text-xs text-[#5a4a5e] mt-0.5" style={AR}>تصفحي وطلب فساتين مميزة</p>
          </div>
          <div className="w-14 h-14 rounded-full bg-[rgba(38,23,50,0.08)] flex items-center justify-center flex-shrink-0">
            <User size={26} className="text-[#261732]" />
          </div>
        </button>

        <button onClick={onSelectDesigner}
          className="w-full bg-[rgba(38,23,50,0.08)] backdrop-blur-sm rounded-[28px] shadow-[0px_4px_12px_rgba(0,0,0,0.15)] p-5 flex items-center gap-4 hover:bg-[rgba(38,23,50,0.14)] transition-all border border-[#261732]/10">
          <ChevronRight size={18} className="text-[#261732]/40 flex-shrink-0" />
          <div className="text-right flex-1" dir="rtl">
            <p className="font-bold text-[#261732] text-base" style={AR}>دخول كمصمم</p>
            <p className="text-xs text-[#5a4a5e] mt-0.5" style={AR}>اعرض أعمالك واحصل على طلبات</p>
          </div>
          <div className="w-14 h-14 rounded-full bg-[#261732]/10 flex items-center justify-center flex-shrink-0">
            <Briefcase size={26} className="text-[#261732]" />
          </div>
        </button>
      </div>
      <div className="px-8 pb-10 text-center">
        <p className="text-xs text-[#5a4a5e]/50" style={AR}>Amber design © 2025</p>
      </div>
    </ScreenBg>
  );
}

// ── 2b. Designer Auth (Sign In vs Login) ──────────────────────────────────────

function DesignerAuthScreen({ onBack, onSignIn, onLogin }: {
  onBack: () => void; onSignIn: () => void; onLogin: () => void;
}) {
  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex-shrink-0 flex items-center px-4 pt-2 pb-1">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-[rgba(217,217,217,0.3)] transition-colors">
          <ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} />
        </button>
      </div>
      <div className="flex-1 flex flex-col items-center justify-center px-8 gap-6">
        <div className="text-center" dir="rtl">
          <Logo size="lg" />
          <h2 className="text-[#261732] text-xl font-bold mt-3" style={AR}>مرحباً بك كمصمم</h2>
          <p className="text-[#5a4a5e] text-sm mt-1 leading-relaxed" style={AR}>
            هل تريد إنشاء حساب جديد أو تسجيل الدخول؟
          </p>
        </div>

        <div className="w-full space-y-3">
          <Pill dark onClick={onSignIn} className="w-full py-4 flex items-center justify-center">
            <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>إنشاء حساب جديد</span>
          </Pill>
          <Pill onClick={onLogin} className="w-full py-4 flex items-center justify-center">
            <span className="text-[#261732] font-semibold text-sm" style={AR}>تسجيل الدخول</span>
          </Pill>
        </div>
      </div>
      <div className="px-8 pb-10 text-center">
        <p className="text-xs text-[#5a4a5e]/50" style={AR}>Amber design © 2025</p>
      </div>
    </ScreenBg>
  );
}

// ── 2c. Designer Field Selection ──────────────────────────────────────────────

const DESIGNER_FIELDS = [
  {
    id: "fashion",
    label: "تصميم الأزياء",
    sub: "فساتين، عبايات، ملابس رسمية",
    emoji: "👗",
    img: D.evening,
  },
  {
    id: "interior",
    label: "التصميم الداخلي",
    sub: "ديكور، مساحات داخلية، ألوان",
    emoji: "🛋️",
    img: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=400&h=300&fit=crop&auto=format",
  },
  {
    id: "exterior",
    label: "التصميم الخارجي",
    sub: "واجهات، مناظر طبيعية، هندسة",
    emoji: "🏛️",
    img: "https://images.unsplash.com/photo-1486325212027-8081e485255e?w=400&h=300&fit=crop&auto=format",
  },
];

function DesignerFieldScreen({ onBack, onDone }: {
  onBack: () => void; onDone: (field: string) => void;
}) {
  const [selected, setSelected] = useState("");

  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex-shrink-0 flex items-center px-4 pt-2 pb-1">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-[rgba(217,217,217,0.3)] transition-colors">
          <ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} />
        </button>
      </div>

      <div className="flex-1 flex flex-col px-6 pt-3 pb-6 overflow-y-auto" dir="rtl">
        <div className="mb-6">
          <h2 className="text-[#261732] text-xl font-bold" style={AR}>ما مجالك؟</h2>
          <p className="text-[#5a4a5e] text-sm mt-1" style={AR}>اختر التخصص الذي تعمل فيه</p>
        </div>

        <div className="space-y-4 flex-1">
          {DESIGNER_FIELDS.map((f) => {
            const active = selected === f.id;
            return (
              <button key={f.id} onClick={() => setSelected(f.id)}
                className={`w-full rounded-[24px] overflow-hidden shadow-[0px_4px_12px_rgba(0,0,0,0.12)] flex items-center gap-0 text-right transition-all ${
                  active ? "ring-2 ring-[#261732] ring-offset-1" : ""
                }`}>
                {/* Image strip */}
                <div className="w-24 h-24 flex-shrink-0 overflow-hidden">
                  <img src={f.img} alt={f.label} className="w-full h-full object-cover object-center" />
                </div>
                {/* Text */}
                <div className={`flex-1 p-4 flex items-center justify-between transition-colors ${
                  active ? "bg-[#261732]" : "bg-[rgba(217,217,217,0.28)] backdrop-blur-sm"}`}>
                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                    active ? "border-white" : "border-[#261732]/30"}`}>
                    {active && <div className="w-2.5 h-2.5 rounded-full bg-white" />}
                  </div>
                  <div className="text-right">
                    <p className={`font-bold text-sm leading-tight ${active ? "text-[#f0e8df]" : "text-[#261732]"}`} style={AR}>{f.label}</p>
                    <p className={`text-[11px] mt-0.5 ${active ? "text-[#f0e8df]/70" : "text-[#5a4a5e]"}`} style={AR}>{f.sub}</p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        <div className="mt-6">
          <Pill dark onClick={selected ? () => onDone(selected) : undefined}
            className={`w-full py-4 flex items-center justify-center ${!selected ? "opacity-40" : ""}`}>
            <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>التالي</span>
          </Pill>
        </div>
      </div>
    </ScreenBg>
  );
}

// ── 3. Onboarding ─────────────────────────────────────────────────────────────

const USER_SLIDES = [
  { title: "اكتشف مصممي الأزياء",  desc: "تصفح أفضل مصممي الفساتين من سهرة وزواج وحفلات.",  img: D.evening },
  { title: "اطلب تصميمك",           desc: "حدد نوع فستانك والمواصفات وسيتولى المصمم الباقي.", img: D.bridal  },
  { title: "استلمي وقيّمي",         desc: "استلمي فستانك المميز وشاركي تجربتك مع المجتمع.",  img: D.party   },
];
const DESIGNER_SLIDES = [
  { title: "اعرض محفظتك",   desc: "انشري أعمالك في فساتين السهرة والزواج وأحدث صيحات الموضة.",  img: D.runway  },
  { title: "فساتين الزواج", desc: "تخصصي في فساتين الزفاف وكوني الخيار الأول لكل عروس.",        img: D.bridal  },
  { title: "ابني سمعتك",   desc: "قدّمي تصاميمك الراقية واجمعي التقييمات من عميلاتك.",          img: D.unique  },
];

function OnboardingScreen({ role, idx, setIdx, onDone }: { role: Role; idx: number; setIdx: (i: number) => void; onDone: () => void }) {
  const slides = role === "designer" ? DESIGNER_SLIDES : USER_SLIDES;
  const slide = slides[idx];
  return (
    <ScreenBg overlay="bg-[#f0e8df]/35">
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="relative h-[300px] flex-shrink-0 overflow-hidden">
          <img src={slide.img} alt={slide.title} className="w-full h-full object-cover object-top" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#f0e8df]" />
        </div>
        <div className="px-8 pt-5 flex-1" dir="rtl">
          <h2 className="text-2xl font-bold text-[#261732] leading-snug mb-2" style={AR}>{slide.title}</h2>
          <p className="text-[#5a4a5e] text-sm leading-relaxed" style={AR}>{slide.desc}</p>
        </div>
      </div>
      <div className="px-8 pb-10">
        <div className="flex justify-center gap-2 mb-5">
          {slides.map((_, i) => (
            <button key={i} onClick={() => setIdx(i)}
              className={`h-1.5 rounded-full transition-all ${i === idx ? "w-6 bg-[#261732]" : "w-2 bg-[#261732]/20"}`} />
          ))}
        </div>
        <div className="flex gap-3">
          {idx > 0 && (
            <Pill onClick={() => setIdx(idx - 1)} className="py-4 px-5 flex items-center justify-center flex-shrink-0">
              <ArrowRight size={16} className="text-[#261732]" />
            </Pill>
          )}
          <Pill dark onClick={() => idx < 2 ? setIdx(idx + 1) : onDone()} className="flex-1 py-4 flex items-center justify-center">
            <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>{idx < 2 ? "التالي" : "ابدأ الآن"}</span>
          </Pill>
        </div>
      </div>
    </ScreenBg>
  );
}

// ── 4. Login ──────────────────────────────────────────────────────────────────

function LoginScreen({ role, email, setEmail, password, setPassword, showPass, setShowPass, onLogin, onSignUp, onBack, lang, setLang }: {
  role: Role; email: string; setEmail: (v: string) => void;
  password: string; setPassword: (v: string) => void;
  showPass: boolean; setShowPass: (v: boolean) => void; onLogin: () => void; onSignUp: () => void; onBack: () => void; lang: "ar"|"en"; setLang: (l: "ar"|"en") => void;
}) {
  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex-shrink-0 flex items-center justify-between px-4 pt-2 pb-1">
        <LangToggle lang={lang} setLang={setLang} />
        <button onClick={onBack} className="p-2 rounded-full hover:bg-[rgba(217,217,217,0.3)] transition-colors">
          <ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} />
        </button>
      </div>
      <div className="flex-1 flex flex-col px-8 pt-4 pb-8" dir="rtl">
        <div className="mb-8">
          <Logo size="md" />
          <h1 className="text-2xl font-bold text-[#261732] mt-4" style={AR}>مرحباً بعودتك</h1>
          <p className="text-[#5a4a5e] text-sm mt-0.5" style={AR}>{role === "designer" ? "تسجيل دخول المصمم" : "تسجيل دخول المستخدم"}</p>
        </div>
        <div className="space-y-4 flex-1">
          <div>
            <label className="text-xs text-[#5a4a5e] mb-1.5 block" style={AR}>البريد الإلكتروني</label>
            <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)]">
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="example@mail.com" dir="ltr"
                className="w-full bg-transparent px-5 py-3.5 text-sm text-[#261732] placeholder-[#5a4a5e]/50 focus:outline-none" />
            </div>
          </div>
          <div>
            <label className="text-xs text-[#5a4a5e] mb-1.5 block" style={AR}>كلمة المرور</label>
            <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] flex items-center">
              <input type={showPass ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••"
                className="flex-1 bg-transparent px-5 py-3.5 text-sm text-[#261732] placeholder-[#5a4a5e]/50 focus:outline-none" />
              <button onClick={() => setShowPass(!showPass)} className="pr-5 text-[#5a4a5e]">
                {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            <div className="mt-1.5 text-left">
              <button className="text-xs text-[#5a4a5e]" style={AR}>نسيت كلمة المرور؟</button>
            </div>
          </div>
          <Pill dark onClick={onLogin} className="w-full py-4 flex items-center justify-center">
            <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>تسجيل الدخول</span>
          </Pill>
          <div className="flex items-center gap-3">
            <div className="flex-1 h-px bg-[#261732]/10" />
            <span className="text-xs text-[#5a4a5e]">أو</span>
            <div className="flex-1 h-px bg-[#261732]/10" />
          </div>
          <Pill onClick={onSignUp} className="w-full py-4 flex items-center justify-center">
            <span className="text-[#261732] text-sm" style={AR}>إنشاء حساب جديد</span>
          </Pill>
        </div>
      </div>
    </ScreenBg>
  );
}

// ── 5. Home ───────────────────────────────────────────────────────────────────

const NOTIFS = [
  { icon: "★", text: "نوف الأحمدي قبلت طلبك", sub: "فستان سهرة ذهبي", time: "منذ ٥ د", color: "bg-yellow-50" },
  { icon: "📦", text: "طلبك رقم #٢٣٤١ قيد التجهيز", sub: "تحديث حالة الطلب", time: "منذ ٣٠ د", color: "bg-orange-50" },
  { icon: "💬", text: "رسالة جديدة من ماها الحربي", sub: "هل يمكن تغيير الموعد؟", time: "منذ ١ س", color: "bg-blue-50" },
  { icon: "🎉", text: "تم إكمال تصميمك!", sub: "فستان الزفاف الملكي جاهز", time: "أمس", color: "bg-green-50" },
  { icon: "⭐", text: "قيّمي مصممتك", sub: "شاركي تجربتك مع سارة الشمري", time: "٢ يوم", color: "bg-purple-50" },
];

function HomeScreen({ role, activeTab, setActiveTab, sidebarOpen, setSidebarOpen,
  searchQuery, setSearchQuery, searchFocused, setSearchFocused,
  onRequest, onProfile, onOrders, onChats, onSettings, onLogout, onDesigner, lang }: {
  role: Role; activeTab: string; setActiveTab: (t: string) => void;
  sidebarOpen: boolean; setSidebarOpen: (v: boolean) => void;
  searchQuery: string; setSearchQuery: (v: string) => void;
  searchFocused: boolean; setSearchFocused: (v: boolean) => void;
  onRequest: (type?: string, mode?: "choose"|"fashion"|"decor") => void; onProfile: () => void; onOrders: () => void;
  onChats: () => void; onSettings: () => void; onLogout: () => void; onDesigner: (d: Designer) => void; lang: "ar"|"en";
}) {
  const [notifOpen, setNotifOpen] = useState(false);
  const q = searchQuery.trim();
  const suggestions = SEARCH_ITEMS.filter(s => q && s.includes(q));
  const filteredDesigners = q ? FEATURED.filter(d => d.name.includes(q) || d.specialty.includes(q)) : FEATURED;
  const filteredCats = q ? DRESS_CATS.filter(c => c.label.includes(q)) : DRESS_CATS;
  const isSearching = !!q;

  return (
    <div className="h-full flex flex-col relative overflow-hidden">
      <ScreenBg overlay="bg-[#f0e8df]/50">
        {/* Header */}
        <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/8">
          <button onClick={() => setSidebarOpen(true)} className="p-1.5">
            <div className="flex flex-col gap-1.5">
              {[0,1,2].map(i => <span key={i} className="block w-5 h-0.5 bg-[#261732]" />)}
            </div>
          </button>
          <h1 className="text-[#261732] text-lg tracking-widest" style={{ fontFamily: "'Abel', sans-serif" }}>Amber design</h1>
          <button onClick={() => setNotifOpen(true)} className="relative p-1.5">
            <Bell size={20} className="text-[#261732]" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-[#8b5a6b] rounded-full animate-pulse" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto" dir="rtl">
          {/* Search */}
          <div className="px-5 pt-4 pb-2 relative z-20">
            <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] flex items-center px-4 gap-2">
              <Search size={15} className="text-[#5a4a5e]/60 flex-shrink-0" />
              <input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setSearchFocused(true)}
                onBlur={() => setTimeout(() => setSearchFocused(false), 150)}
                placeholder="ابحثي عن مصممة أو نوع فستان..."
                className="flex-1 bg-transparent py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/50 focus:outline-none"
                style={AR}
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery("")}><X size={14} className="text-[#5a4a5e]/50" /></button>
              )}
            </div>
            {searchFocused && suggestions.length > 0 && (
              <div className="absolute top-full right-5 left-5 mt-1 bg-[#f0e8df]/96 backdrop-blur-md rounded-2xl shadow-xl border border-[#261732]/8 overflow-hidden z-30">
                {suggestions.slice(0, 6).map((s, i) => (
                  <button key={i} onClick={() => { setSearchQuery(s); setSearchFocused(false); }}
                    className="w-full px-4 py-2.5 text-right text-sm text-[#261732] hover:bg-[rgba(217,217,217,0.4)] border-b border-[#261732]/5 last:border-0 flex items-center justify-end gap-2"
                    style={AR}>
                    <span>{s}</span>
                    <Search size={11} className="text-[#5a4a5e]/40 flex-shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {isSearching ? (
            /* ── Search results ── */
            <div className="px-5 pt-3 pb-6">
              <p className="text-xs text-[#5a4a5e] mb-4" style={AR}>نتائج البحث عن "{q}"</p>
              {filteredCats.length > 0 && (
                <div className="mb-5">
                  <p className="text-sm font-semibold text-[#261732] mb-3" style={AR}>الفساتين</p>
                  <div className="flex gap-3 overflow-x-auto pb-2">
                    {filteredCats.map((c, i) => (
                      <button key={i} onClick={onRequest} className="flex-shrink-0 flex flex-col items-center gap-1.5">
                        <div className="w-[68px] h-[88px] rounded-2xl overflow-hidden shadow-md border border-white/30">
                          <img src={c.img} alt={c.label} className="w-full h-full object-cover object-top" />
                        </div>
                        <span className="text-[10px] text-[#261732] font-medium" style={AR}>{c.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {filteredDesigners.length > 0 && (
                <div>
                  <p className="text-sm font-semibold text-[#261732] mb-3" style={AR}>المصممون</p>
                  <div className="space-y-3">
                    {filteredDesigners.map((d, i) => (
                      <button key={i} onClick={() => onDesigner(d)}
                        className="w-full bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-2xl shadow-[0px_4px_8px_rgba(0,0,0,0.08)] flex items-center gap-3 p-3 flex-row-reverse text-right hover:bg-[rgba(217,217,217,0.35)] transition-all">
                        <img src={d.avatar} alt={d.name} className="w-12 h-12 rounded-full object-cover border-2 border-white/50 flex-shrink-0" />
                        <div className="flex-1">
                          <p className="font-semibold text-[#261732] text-sm" style={AR}>{d.name}</p>
                          <p className="text-xs text-[#5a4a5e]" style={AR}>{d.specialty} · ★ {d.rating}</p>
                        </div>
                        <span onClick={(e) => { e.stopPropagation(); onRequest(undefined, "fashion"); }} className="bg-[#261732] text-[#f0e8df] text-[10px] px-3 py-1.5 rounded-full" style={AR}>طلب</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {filteredCats.length === 0 && filteredDesigners.length === 0 && (
                <div className="flex flex-col items-center py-12 gap-3">
                  <Search size={32} className="text-[#261732]/20" />
                  <p className="text-sm text-[#5a4a5e]" style={AR}>لا توجد نتائج</p>
                </div>
              )}
            </div>
          ) : (
            <>
              {/* Dress categories scroll */}
              <div className="px-5 pt-4">
                <div className="flex items-center justify-between mb-3">
                  <button className="text-xs text-[#5a4a5e]" style={AR}>عرض الكل</button>
                  <p className="text-sm font-semibold text-[#261732]" style={AR}>أنواع الفساتين</p>
                </div>
                <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none">
                  {DRESS_CATS.map((c, i) => (
                    <button key={i} onClick={() => onRequest(`فستان ${c.label}`, "fashion")} className="flex-shrink-0 flex flex-col items-center gap-1.5">
                      <div className="w-[68px] h-[88px] rounded-2xl overflow-hidden shadow-md border border-white/30">
                        <img src={c.img} alt={c.label} className="w-full h-full object-cover object-top" />
                      </div>
                      <span className="text-[10px] text-[#261732] font-medium" style={AR}>{c.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* أبرز مصممات الأزياء — full cards */}
              <div className="px-5 pt-4">
                <div className="flex items-center justify-between mb-3">
                  <button className="text-xs text-[#5a4a5e]" style={AR}>عرض الكل</button>
                  <p className="text-sm font-semibold text-[#261732]" style={AR}>أبرز المصممين</p>
                </div>
                <div className="space-y-3">
                  {FEATURED.slice(0, 3).map((d, i) => (
                    <div key={i} className="rounded-2xl overflow-hidden shadow-[0px_4px_12px_rgba(0,0,0,0.12)] relative cursor-pointer" onClick={() => onDesigner(d)}>
                      <img src={d.img} alt={d.name} className="w-full h-48 object-cover object-top" />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#261732]/70 via-[#261732]/10 to-transparent" />
                      <div className="absolute bottom-0 left-0 right-0 px-4 py-3 flex items-center justify-between">
                        <button onClick={(e) => { e.stopPropagation(); onRequest(undefined, "fashion"); }}
                          className="bg-[rgba(217,217,217,0.25)] backdrop-blur-sm text-white text-[10px] font-medium px-3 py-1.5 rounded-full" style={AR}>طلب تصميم</button>
                        <div className="flex items-center gap-2">
                          <div className="text-right">
                            <p className="text-white text-sm font-semibold" style={AR}>{d.name}</p>
                            <p className="text-yellow-300 text-[10px]">★ {d.rating} · {d.specialty}</p>
                          </div>
                          <img src={d.avatar} alt={d.name} className="w-9 h-9 rounded-full object-cover border-2 border-white/60" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Decor types + best decor designers */}
              <div className="px-5 pt-5 pb-4">
                {/* Decor section header */}
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex-1 h-px bg-gradient-to-r from-transparent via-[#a8896c]/40 to-transparent" />
                  <span className="text-[#a8896c] text-xs">✦</span>
                  <p className="text-base font-bold text-[#261732]" style={AR}>تصميم ديكور</p>
                  <span className="text-[#a8896c] text-xs">✦</span>
                  <div className="flex-1 h-px bg-gradient-to-l from-transparent via-[#a8896c]/40 to-transparent" />
                </div>
                {/* Best decor designers */}
                <div className="flex items-center justify-between mb-3 mt-0">
                  <button className="text-xs text-[#5a4a5e]" style={AR}>عرض الكل</button>
                  <p className="text-sm font-semibold text-[#261732]" style={AR}>أبرز مصممي الديكور</p>
                </div>
                <div className="space-y-3">
                  {[
                    { name:"ليلى الزهراني", spec:"تصميم داخلي فاخر",   rating:"٤.٩", img:ID.luxury,  avatar:CA.b },
                    { name:"سارة المنصور",  spec:"ديكور غرف النوم",    rating:"٤.٨", img:ID.bedroom, avatar:CA.d },
                    { name:"رنا العتيبي",   spec:"تصميم المطابخ",       rating:"٤.٧", img:ID.kitchen, avatar:CA.b },
                    { name:"دانة الحربي",   spec:"الديكور الخارجي",     rating:"٤.٧", img:ID.exterior,avatar:CA.d },
                  ].map((d,i) => (
                    <div key={i} className="rounded-2xl overflow-hidden shadow-[0px_4px_12px_rgba(0,0,0,0.12)] relative cursor-pointer" onClick={() => onRequest(undefined, "decor")}>
                      <img src={d.img} alt={d.name} className="w-full h-48 object-cover object-center" />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#261732]/70 via-[#261732]/10 to-transparent" />
                      <div className="absolute bottom-0 left-0 right-0 px-4 py-3 flex items-center justify-between">
                        <button onClick={(e)=>{e.stopPropagation();onRequest(undefined,"decor");}}
                          className="bg-[rgba(217,217,217,0.25)] backdrop-blur-sm text-white text-[10px] font-medium px-3 py-1.5 rounded-full"
                          style={AR}>طلب تصميم</button>
                        <div className="flex items-center gap-2">
                          <div className="text-right">
                            <p className="text-white text-sm font-semibold" style={AR}>{d.name}</p>
                            <p className="text-yellow-300 text-[10px]">★ {d.rating} · {d.spec}</p>
                          </div>
                          <img src={d.avatar} alt={d.name} className="w-9 h-9 rounded-full object-cover border-2 border-white/60" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Bottom tab bar */}
        <div className="flex-shrink-0 bg-white/65 backdrop-blur-[14px] border-t border-white/30 flex items-center"
          style={{ boxShadow: "0px -4px 4px rgba(0,0,0,0.02)" }}>
          {[
            { id: "home",    icon: Home,          label: "الرئيسية",   action: () => setActiveTab("home") },
            { id: "search",  icon: Search,         label: "البحث",      action: () => { setActiveTab("search"); setSearchFocused(true); (document.querySelector("input[placeholder]") as HTMLInputElement)?.focus(); } },
            { id: "request", icon: ClipboardList,  label: "طلب تصميم", action: onRequest },
            { id: "orders",  icon: Briefcase,      label: "طلباتي",    action: onOrders },
            { id: "profile", icon: User,           label: "حسابي",     action: onProfile },
          ].map((tab) => (
            <button key={tab.id} onClick={tab.action}
              className={`flex-1 flex flex-col items-center py-3 gap-1 transition-colors ${activeTab === tab.id ? "text-[#261732]" : "text-[#261732]/35"}`}>
              <tab.icon size={19} />
              <span className="text-[8px] font-medium" style={AR}>{tr(tab.label, lang)}</span>
            </button>
          ))}
        </div>
      </ScreenBg>

      {/* Sidebar drawer */}
      {sidebarOpen && (
        <>
          <div className="absolute inset-0 bg-[#261732]/30 z-40 backdrop-blur-[2px]" onClick={() => setSidebarOpen(false)} />
          <div className="absolute top-0 left-0 bottom-0 w-64 bg-[#f0e8df]/95 backdrop-blur-md z-50 flex flex-col shadow-2xl" dir="rtl">
            <div className="p-5 pt-8 border-b border-[#261732]/10">
              <Logo size="sm" />
              <p className="text-[#261732] font-bold mt-2" style={{ fontFamily: "'Abel', sans-serif", fontSize: "1.1rem" }}>Amber design</p>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-1">
              {[
                { label: "الرئيسية",     icon: Home,          action: () => setSidebarOpen(false) },
                { label: "طلب تصميم",    icon: ClipboardList, action: () => { setSidebarOpen(false); onRequest(); } },
                { label: "طلباتي",       icon: Briefcase,     action: () => { setSidebarOpen(false); onOrders(); } },
                { label: "المحادثات",    icon: MessageSquare, action: () => { setSidebarOpen(false); onChats(); } },
                { label: "الإشعارات",    icon: Bell,          action: () => { setSidebarOpen(false); setNotifOpen(true); } },
                { label: "ملفي الشخصي", icon: User,          action: () => { setSidebarOpen(false); onProfile(); } },
                { label: "الإعدادات",    icon: Settings,      action: () => { setSidebarOpen(false); onSettings(); } },
              ].map((item, i) => (
                <button key={i} onClick={item.action}
                  dir={lang === "en" ? "ltr" : "rtl"}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-2xl hover:bg-[rgba(217,217,217,0.4)] transition-colors">
                  <item.icon size={16} className="text-[#5a4a5e] flex-shrink-0" />
                  <span className="text-sm text-[#261732]" style={AR}>{tr(item.label, lang)}</span>
                </button>
              ))}
            </div>
            <div className="p-4 border-t border-[#261732]/10">
              <button onClick={() => { setSidebarOpen(false); onLogout(); }}
                className="w-full flex items-center gap-3 px-3 py-3 rounded-2xl hover:bg-red-50/40">
                <LogOut size={16} className="text-red-400" />
                <span className="text-sm text-red-400" style={AR}>تسجيل الخروج</span>
              </button>
            </div>
          </div>
        </>
      )}

      {/* Notification panel */}
      {notifOpen && (
        <>
          <div className="absolute inset-0 bg-[#261732]/30 z-40 backdrop-blur-[2px]" onClick={() => setNotifOpen(false)} />
          <div className="absolute top-0 right-0 bottom-0 w-[85%] bg-[#f7f2ee]/97 backdrop-blur-xl z-50 flex flex-col shadow-2xl rounded-l-3xl">
            <div className="flex items-center justify-between px-5 pt-5 pb-3 border-b border-[#261732]/8" dir="rtl">
              <button onClick={() => setNotifOpen(false)} className="p-1.5 rounded-full hover:bg-[rgba(217,217,217,0.4)]">
                <X size={18} className="text-[#261732]" />
              </button>
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 bg-[#8b5a6b] rounded-full flex items-center justify-center">
                  <span className="text-[9px] text-white font-bold">{NOTIFS.length}</span>
                </span>
                <h2 className="font-bold text-[#261732] text-base" style={AR}>الإشعارات</h2>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto py-2" dir="rtl">
              {NOTIFS.map((n, i) => (
                <button key={i} className={`w-full flex items-start gap-3 px-5 py-3.5 ${n.color}/40 hover:opacity-90 transition-opacity border-b border-[#261732]/5 last:border-0 flex-row-reverse text-right`}>
                  <div className="w-9 h-9 rounded-full bg-white/70 flex items-center justify-center text-base flex-shrink-0 shadow-sm">{n.icon}</div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-[#261732] leading-tight" style={AR}>{n.text}</p>
                    <p className="text-[10px] text-[#5a4a5e] mt-0.5" style={AR}>{n.sub}</p>
                    <p className="text-[9px] text-[#5a4a5e]/55 mt-1">{n.time}</p>
                  </div>
                </button>
              ))}
            </div>
            <div className="px-5 pb-5 pt-3 border-t border-[#261732]/6">
              <button className="w-full text-center text-xs text-[#5a4a5e]" style={AR}>تحديد الكل كمقروء</button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ── 6. Design Request ─────────────────────────────────────────────────────────

function DesignRequestScreen({ role, mode, designType, setDesignType, description, setDescription, specs, toggleSpec, onBack, onNext }: {
  role: Role;
  mode: "choose"|"fashion"|"decor";
  designType: string; setDesignType: (v: string) => void;
  description: string; setDescription: (v: string) => void;
  specs: Record<string, string>; toggleSpec: (cat: string, val: string) => void;
  onBack: () => void; onNext: () => void;
}) {
  const DECOR_KEYWORDS   = ["غرفة نوم","غرفة معيشة","مطبخ","مكتب","فيلا","شقة","حمام","خارجي"];
  const FASHION_KEYWORDS = ["فستان","عباءة","بدلة","تنورة","بلوزة","سواريه"];

  const dt = String(designType ?? "");
  // If mode forces a category, use it; otherwise detect from typed text
  const isDecor   = mode === "decor"   || (mode !== "fashion" && DECOR_KEYWORDS.some(k => dt.includes(k)));
  const isFashion = mode === "fashion" || (mode !== "decor"   && FASHION_KEYWORDS.some(k => dt.includes(k)));
  const activeSpecs = isDecor ? INTERIOR_SPEC_OPTIONS : isFashion ? SPEC_OPTIONS : null;

  const canNext = !!dt;

  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex items-center justify-between px-5 py-3 border-b border-[#261732]/8" dir="rtl">
        <h2 className="text-[#261732] font-semibold" style={AR}>طلب تصميم</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>

      <div className="flex-1 px-5 py-4 space-y-5 overflow-y-auto" dir="rtl">

        {/* Category toggle — only when opened from the icon (choose mode) */}
        {mode === "choose" && (
          <div className="flex gap-2">
            {[
              { label: "أزياء", keywords: ["فستان سهرة","فستان زواج","فستان حفل","عباءة","بدلة"] },
              { label: "ديكور", keywords: ["غرفة نوم","غرفة معيشة","مطبخ","مكتب","فيلا"] },
            ].map(({ label, keywords }) => {
              const active = label === "أزياء" ? isFashion : isDecor;
              return (
                <button key={label} onClick={() => setDesignType(keywords[0])}
                  className={`flex-1 py-2.5 rounded-[50px] text-sm font-semibold transition-all border ${
                    active
                      ? "bg-[#261732] text-[#f0e8df] border-[#261732]"
                      : "bg-[rgba(217,217,217,0.3)] text-[#261732] border-[#261732]/15"
                  }`} style={AR}>{label}</button>
              );
            })}
          </div>
        )}

        {/* Fashion chips */}
        {isFashion && (
          <div>
            <label className="text-xs text-[#5a4a5e] mb-2 block" style={AR}>نوع الفستان</label>
            <div className="flex flex-wrap gap-2 justify-end">
              {["فستان سهرة","فستان زواج","فستان حفل","فستان كاجوال","عباءة","بدلة رسمية","تنورة","سواريه"].map((d) => (
                <button key={d} onClick={() => setDesignType(d)}
                  className={`text-[11px] px-3.5 py-1.5 rounded-full border transition-all ${
                    designType === d
                      ? "bg-[#261732] text-[#f0e8df] border-[#261732]"
                      : "bg-[rgba(217,217,217,0.3)] text-[#261732] border-[#261732]/15"
                  }`} style={AR}>{d}</button>
              ))}
            </div>
          </div>
        )}

        {/* Decor chips */}
        {isDecor && (
          <div>
            <label className="text-xs text-[#5a4a5e] mb-2 block" style={AR}>نوع المشروع</label>
            <div className="flex flex-wrap gap-2 justify-end">
              {["غرفة نوم","غرفة معيشة","مطبخ","مكتب","حمام","فيلا كاملة","شقة كاملة","تصميم خارجي"].map((d) => (
                <button key={d} onClick={() => setDesignType(d)}
                  className={`text-[11px] px-3.5 py-1.5 rounded-full border transition-all ${
                    designType === d
                      ? "bg-[#261732] text-[#f0e8df] border-[#261732]"
                      : "bg-[rgba(217,217,217,0.3)] text-[#261732] border-[#261732]/15"
                  }`} style={AR}>{d}</button>
              ))}
            </div>
          </div>
        )}

        {/* Dynamic spec options */}
        {activeSpecs && (
          <div className="space-y-3">
            <label className="text-xs text-[#5a4a5e] block font-medium" style={AR}>
              {isDecor ? "تفاصيل المشروع" : "المحددات"}
            </label>
            {Object.entries(activeSpecs).map(([cat, opts]) => (
              <div key={cat}>
                <p className="text-[10px] text-[#5a4a5e] mb-1.5 font-semibold" style={AR}>{cat}</p>
                <div className="flex flex-wrap gap-1.5 justify-end">
                  {opts.map((opt) => (
                    <button key={opt} onClick={() => toggleSpec(cat, opt)}
                      className={`text-[10px] px-3 py-1.5 rounded-full border transition-all ${
                        specs[cat] === opt
                          ? "bg-[#261732] text-[#f0e8df] border-[#261732]"
                          : "bg-[rgba(217,217,217,0.25)] text-[#261732] border-[#261732]/12"
                      }`} style={AR}>{opt}</button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Description */}
        {(isFashion || isDecor) && (
          <div>
            <label className="text-xs text-[#5a4a5e] mb-2 block" style={AR}>تفاصيل إضافية</label>
            <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[24px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)]">
              <textarea value={description} onChange={(e) => setDescription(e.target.value)}
                placeholder={isDecor ? "صفي المساحة والأسلوب المطلوب وأي تفاصيل مهمة..." : "صفي طلبك — المناسبة، اللون المفضل، أي تفاصيل خاصة..."}
                rows={4}
                className="w-full bg-transparent px-5 py-4 text-sm text-[#261732] placeholder-[#5a4a5e]/50 resize-none focus:outline-none text-right"
                style={AR} />
            </div>
          </div>
        )}

        {/* Upload */}
        {(isFashion || isDecor) && (
          <div>
            <label className="text-xs text-[#5a4a5e] mb-2 block" style={AR}>رفع ملفات مرجعية</label>
            <button className="w-full bg-[rgba(217,217,217,0.15)] border border-dashed border-[#261732]/20 rounded-[24px] py-7 flex flex-col items-center gap-2 hover:bg-[rgba(217,217,217,0.3)] transition-colors">
              <div className="w-10 h-10 rounded-full bg-[rgba(217,217,217,0.4)] flex items-center justify-center">
                <Upload size={18} className="text-[#261732]" />
              </div>
              <span className="text-sm text-[#5a4a5e]" style={AR}>اضغطي لرفع الملفات</span>
              <span className="text-xs text-[#5a4a5e]/50">PDF, PNG, JPG</span>
            </button>
          </div>
        )}
      </div>

      <div className="px-5 pb-8 pt-3">
        <Pill dark onClick={canNext ? onNext : undefined}
          className={`w-full py-4 flex items-center justify-center ${!canNext ? "opacity-40" : ""}`}>
          <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>التالي</span>
        </Pill>
      </div>
    </ScreenBg>
  );
}

// ── 7. Review Order ───────────────────────────────────────────────────────────

function ReviewOrderScreen({ service, specs, description, mode, onBack, onContinue }: {
  service: string; specs: Record<string,string>; description: string;
  mode: "choose"|"fashion"|"decor"; onBack: () => void; onContinue: () => void;
}) {
  const isDecor = mode === "decor" || ["غرفة","مطبخ","مكتب","فيلا","شقة","حمام","خارجي"].some(k => service.includes(k));

  // Pick a representative image
  const img = isDecor
    ? (service.includes("نوم") ? ID.bedroom : service.includes("معيشة") ? ID.living : service.includes("مطبخ") ? ID.kitchen : service.includes("مكتب") ? ID.office : service.includes("فيلا") ? ID.villa : service.includes("خارجي") ? ID.exterior : ID.luxury)
    : (service.includes("زواج") ? D.bridal : service.includes("حفل") ? D.party : service.includes("غريب") ? D.unique : D.evening);

  // Delivery time based on category
  const delivery = isDecor ? "٧–١٤ يوم عمل" : "٣–٥ أيام عمل";

  // Filled specs (non-empty)
  const filledSpecs = Object.entries(specs).filter(([, v]) => !!v);

  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex items-center justify-between px-5 py-3 border-b border-[#261732]/8" dir="rtl">
        <h2 className="text-[#261732] font-semibold" style={AR}>مراجعة الطلب</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 px-5 py-5 space-y-4 overflow-y-auto" dir="rtl">

        {/* صورة */}
        <div className="rounded-2xl overflow-hidden shadow-[0px_4px_12px_rgba(0,0,0,0.12)] h-44">
          <img src={img} alt={service} className="w-full h-full object-cover object-center" />
        </div>

        {/* تفاصيل الطلب */}
        <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[24px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] p-4 space-y-3">
          {[
            ["نوع الطلب",    service],
            ["نوع التصميم",  isDecor ? "ديكور داخلي / خارجي" : "تصميم أزياء"],
            ["مدة التسليم",  delivery],
            ["المراجعات",    "٣ جولات"],
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between text-sm border-t border-[#261732]/6 pt-2 first:border-0 first:pt-0">
              <span className="text-[#5a4a5e]" style={AR}>{v}</span>
              <span className="text-[#261732]/60 font-medium" style={AR}>{k}</span>
            </div>
          ))}

          {/* المحددات المختارة */}
          {filledSpecs.length > 0 && filledSpecs.map(([cat, val]) => (
            <div key={cat} className="flex justify-between text-sm border-t border-[#261732]/6 pt-2">
              <span className="text-[#5a4a5e]" style={AR}>{val}</span>
              <span className="text-[#261732]/60 font-medium" style={AR}>{cat}</span>
            </div>
          ))}

          {/* الملاحظات */}
          {description.trim() && (
            <div className="border-t border-[#261732]/6 pt-2">
              <p className="text-[#261732]/60 font-medium text-sm mb-1" style={AR}>ملاحظات</p>
              <p className="text-[#5a4a5e] text-xs leading-relaxed" style={AR}>{description}</p>
            </div>
          )}
        </div>

        {/* السعر */}
        <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[24px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] p-4 space-y-2">
          {[
            ["رسوم الخدمة", isDecor ? "٨٠٠ ر.س" : "٤٥٠ ر.س"],
            ["رسوم المنصة", isDecor ? "٥٠ ر.س"  : "٣٠ ر.س"],
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between text-sm border-t border-[#261732]/6 pt-2 first:border-0 first:pt-0">
              <span className="text-[#5a4a5e]">{v}</span>
              <span className="text-[#261732]/60" style={AR}>{k}</span>
            </div>
          ))}
          <div className="border-t border-[#261732]/15 pt-3 flex justify-between font-bold">
            <span className="text-[#261732] text-xl">{isDecor ? "٨٥٠ ر.س" : "٤٨٠ ر.س"}</span>
            <span className="text-[#261732]" style={AR}>الإجمالي</span>
          </div>
        </div>
      </div>
      <div className="px-5 pb-8 pt-3">
        <Pill dark onClick={onContinue} className="w-full py-4 flex items-center justify-center">
          <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>المتابعة للدفع</span>
        </Pill>
      </div>
    </ScreenBg>
  );
}

// ── 8. Payment ────────────────────────────────────────────────────────────────

function PaymentScreen({ method, setMethod, onBack, onPay }: { method: string; setMethod: (v: string) => void; onBack: () => void; onPay: () => void }) {
  const methods = [
    { id: "credit", label: "بطاقة ائتمان / مدى", icon: "💳" },
    { id: "apple",  label: "Apple Pay",            icon: "" },
    { id: "stc",    label: "STC Pay",              icon: "🟣" },
    { id: "mada",   label: "مدى",                  icon: "🔵" },
  ];
  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex items-center justify-between px-5 py-3 border-b border-[#261732]/8" dir="rtl">
        <h2 className="text-[#261732] font-semibold" style={AR}>الدفع</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 px-5 py-5 space-y-4 overflow-y-auto" dir="rtl">
        <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[24px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] p-4 flex justify-between items-center">
          <span className="text-[#261732] text-xl font-bold">٤٨٠ ر.س</span>
          <span className="text-sm text-[#5a4a5e]" style={AR}>المبلغ الإجمالي</span>
        </div>
        <p className="text-xs text-[#5a4a5e]" style={AR}>اختر طريقة الدفع</p>
        <div className="space-y-3">
          {methods.map((m) => (
            <button key={m.id} onClick={() => setMethod(m.id)}
              className={`w-full flex items-center gap-3 p-4 rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] transition-all backdrop-blur-sm ${
                method === m.id ? "bg-[rgba(38,23,50,0.12)] border border-[#261732]/20" : "bg-[rgba(217,217,217,0.22)]"}`}>
              <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${method === m.id ? "border-[#261732]" : "border-[#261732]/25"}`}>
                {method === m.id && <div className="w-2.5 h-2.5 rounded-full bg-[#261732]" />}
              </div>
              <span className="text-lg">{m.icon}</span>
              <span className={`text-sm ${method === m.id ? "text-[#261732] font-medium" : "text-[#5a4a5e]"}`} style={AR}>{m.label}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="px-5 pb-8 pt-3">
        <Pill dark onClick={onPay} className="w-full py-4 flex items-center justify-center">
          <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>ادفعي الآن — ٤٨٠ ر.س</span>
        </Pill>
      </div>
    </ScreenBg>
  );
}

// ── 9. Payment Success ────────────────────────────────────────────────────────

function PaymentSuccessScreen({ onView }: { onView: () => void }) {
  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex-1 flex flex-col items-center justify-center px-8" dir="rtl">
        <div className="w-24 h-24 rounded-full bg-[rgba(217,217,217,0.3)] backdrop-blur-sm shadow-[0px_4px_4px_1px_rgba(0,0,0,0.18)] flex items-center justify-center mb-6">
          <CheckCircle size={44} className="text-[#261732]" />
        </div>
        <h2 className="text-2xl font-bold text-[#261732] mb-2" style={AR}>تمت عملية الدفع!</h2>
        <p className="text-[#5a4a5e] text-sm text-center leading-relaxed mb-2" style={AR}>
          تم تقديم طلبك بنجاح. ستبدأ المصممة العمل قريباً.
        </p>
        <p className="text-xs text-[#5a4a5e]/50 mb-10">طلب رقم #12345</p>
        <Pill dark onClick={onView} className="w-full py-4 flex items-center justify-center">
          <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>عرض طلباتي</span>
        </Pill>
      </div>
    </ScreenBg>
  );
}

// ── 10. My Orders ─────────────────────────────────────────────────────────────

function MyOrdersScreen({ orders, selectedOrder, setSelectedOrder, onBack, onTracking }: {
  orders: Order[]; selectedOrder: Order | null;
  setSelectedOrder: (o: Order | null) => void;
  onBack: () => void; onTracking: (o: Order) => void;
}) {
  // Detail view
  if (selectedOrder) {
    return (
      <ScreenBg overlay="bg-[#f0e8df]/52">
        <div className="flex items-center justify-between px-5 py-3 border-b border-[#261732]/8" dir="rtl">
          <h2 className="text-[#261732] font-semibold" style={AR}>تفاصيل الطلب</h2>
          <button onClick={() => setSelectedOrder(null)} className="p-2"><ArrowRight size={20} className="text-[#261732]" /></button>
        </div>
        <div className="flex-1 px-5 py-5 space-y-4 overflow-y-auto" dir="rtl">
          <div className="rounded-2xl overflow-hidden shadow-[0px_4px_12px_rgba(0,0,0,0.12)] h-52">
            <img src={selectedOrder.img} alt={selectedOrder.service} className="w-full h-full object-cover object-top" />
          </div>
          <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[24px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className={`text-[10px] px-2.5 py-1 rounded-full font-medium ${STATUS_COLOR[selectedOrder.status]}`} style={AR}>
                {selectedOrder.status}
              </span>
              <p className="font-bold text-[#261732]" style={AR}>{selectedOrder.id}</p>
            </div>
            {[["الخدمة", selectedOrder.service], ["المصمم", selectedOrder.designer], ["التاريخ", selectedOrder.date], ["السعر", selectedOrder.price]].map(([k, v]) => (
              <div key={k} className="flex justify-between text-sm border-t border-[#261732]/6 pt-2">
                <span className="text-[#5a4a5e]" style={AR}>{v}</span>
                <span className="text-[#261732]/60 font-medium" style={AR}>{k}</span>
              </div>
            ))}
          </div>
          <div className="flex gap-3">
            <Pill className="flex-1 py-3.5 flex items-center justify-center gap-2" onClick={() => {}}>
              <MessageSquare size={15} className="text-[#261732]" />
              <span className="text-sm text-[#261732]" style={AR}>تواصل</span>
            </Pill>
            <Pill dark className="flex-1 py-3.5 flex items-center justify-center" onClick={() => onTracking(selectedOrder)}>
              <span className="text-[#f0e8df] text-sm" style={AR}>تتبع الطلب</span>
            </Pill>
          </div>
        </div>
      </ScreenBg>
    );
  }

  // List view
  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex items-center justify-between px-5 py-3 border-b border-[#261732]/8" dir="rtl">
        <h2 className="text-[#261732] font-semibold" style={AR}>طلباتي</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 px-5 py-4 space-y-3 overflow-y-auto" dir="rtl">
        {orders.map((o) => (
          <button key={o.id} onClick={() => setSelectedOrder(o)}
            className="w-full bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-2xl shadow-[0px_4px_8px_rgba(0,0,0,0.08)] overflow-hidden flex items-stretch text-right hover:bg-[rgba(217,217,217,0.35)] transition-all">
            <div className="w-24 flex-shrink-0 bg-[#f0e8df]">
              <img src={o.img} alt={o.service} className="w-full h-full object-cover object-top" />
            </div>
            <div className="flex-1 p-3.5 flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between gap-2 mb-1">
                  <span className={`text-[9px] px-2 py-0.5 rounded-full font-medium flex-shrink-0 ${STATUS_COLOR[o.status]}`} style={AR}>
                    {o.status}
                  </span>
                  <p className="font-bold text-[#261732] text-sm leading-tight" style={AR}>{o.service}</p>
                </div>
                <p className="text-xs text-[#5a4a5e] text-right" style={AR}>{o.designer}</p>
              </div>
              <div className="flex justify-between items-center mt-2">
                <span className="text-[#261732] font-bold text-sm">{o.price}</span>
                <span className="text-[10px] text-[#5a4a5e]/60" style={AR}>{o.date}</span>
              </div>
            </div>
          </button>
        ))}
      </div>
    </ScreenBg>
  );
}

// ── 11. Order Tracking ────────────────────────────────────────────────────────

function OrderTrackingScreen({ order, onBack }: { order: Order; onBack: () => void }) {
  const STEPS = ["تم تقديم الطلب", "قيد التنفيذ", "المراجعة", "مكتمل"];
  const activeIdx = order.status === "تم التقديم" ? 0 : order.status === "قيد التنفيذ" ? 1 : order.status === "قيد المراجعة" ? 2 : 3;

  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex items-center justify-between px-5 py-3 border-b border-[#261732]/8" dir="rtl">
        <h2 className="text-[#261732] font-semibold" style={AR}>تتبع الطلب</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 px-5 py-5 space-y-4 overflow-y-auto" dir="rtl">
        <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[24px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] p-4 flex justify-between items-center">
          <span className={`text-[9px] px-2.5 py-1 rounded-full font-medium ${STATUS_COLOR[order.status]}`} style={AR}>{order.status}</span>
          <div className="text-right">
            <p className="font-bold text-[#261732]" style={AR}>طلب {order.id}</p>
            <p className="text-xs text-[#5a4a5e]">{order.service} · {order.designer}</p>
          </div>
        </div>

        <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[24px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] p-5">
          <p className="font-semibold text-[#261732] text-sm text-right mb-5" style={AR}>التقدم</p>
          {STEPS.map((step, i) => {
            const done = i < activeIdx;
            const active = i === activeIdx;
            return (
              <div key={i} className="flex gap-4 flex-row-reverse">
                <div className="flex flex-col items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 border-2 ${
                    done ? "bg-[#261732] border-[#261732]" : active ? "border-[#261732] bg-white/40" : "border-[#261732]/20 bg-white/20"}`}>
                    {done ? <CheckCircle size={16} className="text-white" /> :
                      active ? <div className="w-3 h-3 rounded-full bg-[#261732]" /> :
                      <div className="w-3 h-3 rounded-full bg-[#261732]/20" />}
                  </div>
                  {i < STEPS.length - 1 && <div className={`w-0.5 h-10 mt-1 ${done ? "bg-[#261732]" : "bg-[#261732]/12"}`} />}
                </div>
                <div className="pb-8 pt-1 text-right">
                  <p className={`text-sm font-semibold ${done || active ? "text-[#261732]" : "text-[#261732]/30"}`} style={AR}>{step}</p>
                  {active && <p className="text-xs text-[#5a4a5e] mt-0.5" style={AR}>
                    {order.status === "مكتمل" ? "اكتمل طلبك بنجاح!" : "المصممة تعمل على تصميمك الآن"}
                  </p>}
                </div>
              </div>
            );
          })}
        </div>

        <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[24px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] p-4 flex items-center gap-3 flex-row-reverse">
          <img src={imgAvatar} alt={order.designer} className="w-12 h-12 rounded-full object-cover border-2 border-white/50 flex-shrink-0" />
          <div className="flex-1 text-right">
            <p className="font-semibold text-sm text-[#261732]" style={AR}>{order.designer}</p>
            <p className="text-xs text-[#5a4a5e]">مصممة أزياء · ★ 4.9</p>
          </div>
          <button className="p-2.5 bg-[rgba(217,217,217,0.4)] rounded-full">
            <MessageSquare size={16} className="text-[#261732]" />
          </button>
        </div>
      </div>
    </ScreenBg>
  );
}

// ── 12. Profile ───────────────────────────────────────────────────────────────

function ProfileScreen({ role, onBack, onOrders, onSettings, onEditProfile, onHelp, onLogout }: {
  role: Role; onBack: () => void; onOrders: () => void;
  onSettings: () => void; onEditProfile: () => void; onHelp: () => void; onLogout: () => void;
}) {
  const items = [
    { label: "طلباتي",              action: onOrders },
    { label: "الإعدادات",           action: onSettings },
    { label: "تعديل الملف الشخصي", action: onEditProfile },
    { label: "المساعدة والدعم",     action: onHelp },
    { label: "تسجيل الخروج",        action: onLogout, danger: true },
  ];
  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex items-center justify-between px-5 py-3 border-b border-[#261732]/8" dir="rtl">
        <h2 className="text-[#261732] font-semibold" style={AR}>حسابي</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 px-5 py-5 space-y-4 overflow-y-auto" dir="rtl">
        <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[24px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] p-4 flex items-center gap-4 flex-row-reverse">
          <div className="w-16 h-16 rounded-full bg-[rgba(38,23,50,0.1)] flex items-center justify-center flex-shrink-0">
            <User size={28} className="text-[#261732]" />
          </div>
          <div className="text-right">
            <p className="font-bold text-[#261732]" style={AR}>اسم المستخدم</p>
            <p className="text-sm text-[#5a4a5e]">user@example.com</p>
            <span className="text-[10px] bg-[rgba(217,217,217,0.5)] px-2 py-0.5 rounded-full text-[#5a4a5e] mt-1 inline-block" style={AR}>
              {role === "designer" ? "مصمم" : "مستخدم"}
            </span>
          </div>
        </div>
        <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[24px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] overflow-hidden">
          {items.map((item, i) => (
            <button key={i} onClick={item.action}
              className={`w-full flex items-center justify-between px-5 py-4 hover:bg-[rgba(217,217,217,0.3)] transition-colors ${i < items.length - 1 ? "border-b border-[#261732]/6" : ""}`}>
              <ChevronRight size={15} className={item.danger ? "text-red-400/50" : "text-[#261732]/25"} style={{ transform: "scaleX(-1)" }} />
              <span className={`text-sm font-medium ${item.danger ? "text-red-500" : "text-[#261732]"}`} style={AR}>{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </ScreenBg>
  );
}

// ── 13. Settings ──────────────────────────────────────────────────────────────

function SettingsScreen({ onBack, lang, setLang }: { onBack: () => void; lang: "ar"|"en"; setLang: (l: "ar"|"en") => void }) {
  const [notifOrders, setNotifOrders] = useState(true);

  const Toggle = ({ v, set }: { v: boolean; set: () => void }) => (
    <button onClick={set} className={`w-11 h-6 rounded-full relative transition-colors ${v ? "bg-[#261732]" : "bg-[#261732]/20"}`}>
      <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all ${v ? "right-0.5" : "left-0.5"}`} />
    </button>
  );

  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex items-center justify-between px-5 py-3 border-b border-[#261732]/8" dir="rtl">
        <h2 className="text-[#261732] font-semibold" style={AR}>الإعدادات</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 px-5 py-5 space-y-5 overflow-y-auto" dir="rtl">

        {/* الإشعارات */}
        <div>
          <p className="text-xs font-semibold text-[#5a4a5e] mb-2 px-1" style={AR}>الإشعارات</p>
          <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[24px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] overflow-hidden">
            {[
              { label: "إشعارات الطلبات", v: notifOrders, set: () => setNotifOrders(p => !p) },
            ].map((row, i, arr) => (
              <div key={row.label} className={`flex items-center justify-between px-5 py-3.5 ${i < arr.length - 1 ? "border-b border-[#261732]/6" : ""}`}>
                <Toggle v={row.v} set={row.set} />
                <span className="text-sm text-[#261732]" style={AR}>{row.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* اللغة */}
        <div>
          <p className="text-xs font-semibold text-[#5a4a5e] mb-2 px-1" style={AR}>اللغة</p>
          <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[24px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] overflow-hidden">
            {(["ar", "en"] as const).map((l, i) => (
              <button key={l} onClick={() => setLang(l)}
                className={`w-full flex items-center justify-between px-5 py-3.5 transition-colors hover:bg-[rgba(217,217,217,0.3)] ${i === 0 ? "border-b border-[#261732]/6" : ""}`}>
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${lang === l ? "border-[#261732] bg-[#261732]" : "border-[#261732]/30"}`}>
                  {lang === l && <span className="w-2 h-2 rounded-full bg-white block" />}
                </div>
                <span className="text-sm text-[#261732]" style={AR}>{l === "ar" ? "العربية" : "English"}</span>
              </button>
            ))}
          </div>
        </div>

        <p className="text-center text-[10px] text-[#5a4a5e]/40 pt-4" style={AR}>Amber design v1.0.0 · © 2025</p>
      </div>
    </ScreenBg>
  );
}

// ── 14. Edit Profile ──────────────────────────────────────────────────────────

function EditProfileScreen({ role, onBack }: { role: Role; onBack: () => void }) {
  const [name,  setName]  = useState("اسم المستخدم");
  const [email, setEmail] = useState("user@example.com");
  const [phone, setPhone] = useState("+966 5x xxx xxxx");
  const [bio,   setBio]   = useState("");
  const [saved, setSaved] = useState(false);

  const handleSave = () => { setSaved(true); setTimeout(() => setSaved(false), 2000); };

  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex items-center justify-between px-5 py-3 border-b border-[#261732]/8" dir="rtl">
        <h2 className="text-[#261732] font-semibold" style={AR}>تعديل الملف الشخصي</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 px-5 py-5 space-y-4 overflow-y-auto" dir="rtl">
        <div className="flex flex-col items-center gap-2 pb-2">
          <div className="relative">
            <div className="w-20 h-20 rounded-full bg-[rgba(38,23,50,0.1)] flex items-center justify-center border-2 border-[#261732]/20">
              <User size={32} className="text-[#261732]" />
            </div>
            <button className="absolute -bottom-1 -left-1 w-7 h-7 rounded-full bg-[#261732] flex items-center justify-center shadow-md">
              <Upload size={12} className="text-[#f0e8df]" />
            </button>
          </div>
          <p className="text-xs text-[#5a4a5e]" style={AR}>تغيير الصورة الشخصية</p>
        </div>
        {[
          { label: "الاسم الكامل",        value: name,  set: setName,  dir: "rtl" },
          { label: "البريد الإلكتروني",  value: email, set: setEmail, dir: "ltr" },
          { label: "رقم الجوال",          value: phone, set: setPhone, dir: "ltr" },
        ].map(({ label, value, set, dir: d }) => (
          <div key={label}>
            <label className="text-xs text-[#5a4a5e] mb-1.5 block" style={AR}>{label}</label>
            <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)]">
              <input value={value} onChange={(e) => set(e.target.value)} dir={d}
                className="w-full bg-transparent px-5 py-3.5 text-sm text-[#261732] focus:outline-none text-right" style={AR} />
            </div>
          </div>
        ))}
        {role === "designer" && (
          <div>
            <label className="text-xs text-[#5a4a5e] mb-1.5 block" style={AR}>نبذة عن التصميم</label>
            <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[24px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)]">
              <textarea value={bio} onChange={(e) => setBio(e.target.value)}
                placeholder="صفي أسلوبك وتخصصك وخبرتك في مجال الأزياء..." rows={4}
                className="w-full bg-transparent px-5 py-4 text-sm text-[#261732] placeholder-[#5a4a5e]/50 resize-none focus:outline-none text-right" style={AR} />
            </div>
          </div>
        )}
        <Pill dark onClick={handleSave} className="w-full py-4 flex items-center justify-center">
          <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>{saved ? "✓ تم الحفظ" : "حفظ التغييرات"}</span>
        </Pill>
      </div>
    </ScreenBg>
  );
}

// ── 15. Help & Support ────────────────────────────────────────────────────────

// ── User Chats ────────────────────────────────────────────────────────────────
const USER_CHATS = [
  { id: 0, name: "مها ديزاين",   avatar: "https://images.unsplash.com/photo-1638433429483-a188db3d3b53?w=80&h=80&fit=crop", last: "تم استلام طلبك، سأبدأ التصميم قريباً", time: "٩:٤١ ص",  unread: 2 },
  { id: 1, name: "نوف الأحمدي",  avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&h=80&fit=crop", last: "هل يناسبك اللون الذهبي؟",              time: "أمس",    unread: 0 },
  { id: 2, name: "خلود السالم",  avatar: "https://images.unsplash.com/photo-1613447895817-e617a4093f50?w=80&h=80&fit=crop", last: "الفستان سيكون جاهز يوم الخميس",       time: "٢ يوم",  unread: 0 },
  { id: 3, name: "ليلى الزهراني",avatar: "https://images.unsplash.com/photo-1718230800381-1b7ee3bfb2bd?w=80&h=80&fit=crop", last: "شكراً لاختيارك خدماتنا!",             time: "٥ يوم",  unread: 0 },
];
const USER_CHAT_MSGS: Record<number, { me: boolean; text: string; time: string }[]> = {
  0: [
    { me: false, text: "أهلاً! تم استلام طلبك بنجاح 🎉", time: "٩:٣٠ ص" },
    { me: true,  text: "شكراً جزيلاً، متى تتوقعين الانتهاء؟", time: "٩:٣٥ ص" },
    { me: false, text: "تم استلام طلبك، سأبدأ التصميم قريباً", time: "٩:٤١ ص" },
  ],
  1: [
    { me: true,  text: "مرحباً، أريد تعديل لون الفستان", time: "أمس ٤:١٠ م" },
    { me: false, text: "هل يناسبك اللون الذهبي؟", time: "أمس ٤:٢٢ م" },
  ],
  2: [
    { me: false, text: "الفستان سيكون جاهز يوم الخميس", time: "منذ يومين" },
    { me: true,  text: "ممتاز، شكراً!", time: "منذ يومين" },
  ],
  3: [
    { me: false, text: "شكراً لاختيارك خدماتنا!", time: "منذ ٥ أيام" },
  ],
};

function UserChatsScreen({ onBack, onChat }: { onBack: () => void; onChat: (id: number) => void }) {
  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex items-center justify-between px-5 py-3 border-b border-[#261732]/8" dir="rtl">
        <h2 className="text-[#261732] font-semibold" style={AR}>المحادثات</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 overflow-y-auto" dir="rtl">
        {USER_CHATS.map((c) => (
          <button key={c.id} onClick={() => onChat(c.id)}
            className="w-full flex items-center gap-3 px-5 py-4 border-b border-[#261732]/5 hover:bg-[rgba(217,217,217,0.2)] transition-colors">
            <div className="relative flex-shrink-0">
              <img src={c.avatar} alt={c.name} className="w-12 h-12 rounded-full object-cover" />
              {c.unread > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-[#8b5a6b] rounded-full flex items-center justify-center">
                  <span className="text-[9px] text-white font-bold">{c.unread}</span>
                </span>
              )}
            </div>
            <div className="flex-1 text-right min-w-0">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-[#5a4a5e]/60">{c.time}</span>
                <p className="font-semibold text-[#261732] text-sm" style={AR}>{c.name}</p>
              </div>
              <p className={`text-xs mt-0.5 truncate ${c.unread > 0 ? "text-[#261732] font-medium" : "text-[#5a4a5e]"}`} style={AR}>{c.last}</p>
            </div>
          </button>
        ))}
      </div>
    </ScreenBg>
  );
}

function UserChatDetailScreen({ chatId, onBack }: { chatId: number; onBack: () => void }) {
  const chat = USER_CHATS[chatId] ?? USER_CHATS[0];
  const msgs = USER_CHAT_MSGS[chatId] ?? [];
  const [msg, setMsg] = useState("");
  const [all, setAll] = useState(msgs);

  const send = () => {
    if (!msg.trim()) return;
    setAll(p => [...p, { me: true, text: msg.trim(), time: "الآن" }]);
    setMsg("");
  };

  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex-shrink-0 flex items-center gap-3 px-4 py-3 border-b border-[#261732]/8" dir="rtl">
        <button onClick={onBack} className="p-1.5"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
        <img src={chat.avatar} alt={chat.name} className="w-9 h-9 rounded-full object-cover flex-shrink-0" />
        <p className="font-semibold text-[#261732] flex-1 text-right" style={AR}>{chat.name}</p>
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3" dir="rtl">
        {all.map((m, i) => (
          <div key={i} className={`flex ${m.me ? "justify-start" : "justify-end"}`}>
            <div className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-sm ${m.me ? "bg-[rgba(217,217,217,0.4)] text-[#261732] rounded-tr-sm" : "bg-[#261732] text-[#f0e8df] rounded-tl-sm"}`} style={AR}>
              <p>{m.text}</p>
              <p className={`text-[9px] mt-1 ${m.me ? "text-[#5a4a5e]/60" : "text-[#f0e8df]/60"}`}>{m.time}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="flex-shrink-0 flex items-center gap-2 px-4 py-3 border-t border-[#261732]/8" dir="rtl">
        <button onClick={send} className="p-2.5 rounded-full bg-[#261732] flex-shrink-0">
          <Send size={15} className="text-[#f0e8df]" style={{transform:"scaleX(-1)"}} />
        </button>
        <input value={msg} onChange={e => setMsg(e.target.value)}
          onKeyDown={e => e.key === "Enter" && send()}
          placeholder="اكتبي رسالتك..."
          className="flex-1 bg-[rgba(217,217,217,0.28)] backdrop-blur-sm rounded-full px-4 py-2.5 text-sm text-[#261732] placeholder-[#5a4a5e]/40 focus:outline-none text-right"
          style={AR} />
      </div>
    </ScreenBg>
  );
}

function HelpSupportScreen({ onBack }: { onBack: () => void }) {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const FAQS = [
    { q: "كيف أطلب تصميم فستان؟",  a: "من الرئيسية اضغطي على 'طلب تصميم'، حددي النوع والمواصفات، ثم أرسلي الطلب." },
    { q: "كم مدة التسليم؟",          a: "عادةً بين ٣ و٧ أيام عمل حسب نوع الفستان وتفاصيله." },
    { q: "هل يمكنني إلغاء الطلب؟",  a: "يمكن إلغاء الطلب خلال ٢٤ ساعة. بعد ذلك تُطبَّق سياسة الاسترداد." },
    { q: "كيف أتواصل مع المصممة؟",  a: "بعد قبول الطلب يمكنك التواصل عبر نظام المحادثة الداخلي." },
    { q: "ما طرق الدفع المتاحة؟",   a: "نقبل بطاقات الائتمان، مدى، Apple Pay، وSTC Pay." },
  ];
  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex items-center justify-between px-5 py-3 border-b border-[#261732]/8" dir="rtl">
        <h2 className="text-[#261732] font-semibold" style={AR}>المساعدة والدعم</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 px-5 py-5 space-y-5 overflow-y-auto" dir="rtl">
        <div className="grid grid-cols-2 gap-3">
          {[
            { icon: Phone,         label: "اتصل بنا",      sub: "+966 xx xxx xxxx", cls: "text-green-700" },
            { icon: Mail,          label: "راسلنا",         sub: "support@amber.sa", cls: "text-blue-700" },
            { icon: MessageSquare, label: "واتساب",         sub: "دعم فوري",         cls: "text-emerald-700" },
            { icon: HelpCircle,    label: "مركز المساعدة", sub: "أسئلة شائعة",      cls: "text-[#261732]" },
          ].map((c, i) => (
            <button key={i} className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-2xl shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] p-4 flex flex-col items-end gap-1 hover:bg-[rgba(217,217,217,0.35)] transition-colors">
              <c.icon size={20} className={c.cls} />
              <p className="text-sm font-semibold text-[#261732]" style={AR}>{c.label}</p>
              <p className="text-[10px] text-[#5a4a5e]">{c.sub}</p>
            </button>
          ))}
        </div>
        <div>
          <p className="text-sm font-semibold text-[#261732] mb-3" style={AR}>الأسئلة الشائعة</p>
          <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[24px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] overflow-hidden">
            {FAQS.map((faq, i) => (
              <div key={i} className={i < FAQS.length - 1 ? "border-b border-[#261732]/6" : ""}>
                <button onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between px-5 py-4 text-right hover:bg-[rgba(217,217,217,0.25)] transition-colors">
                  <ChevronDown size={15} className={`text-[#261732]/40 flex-shrink-0 transition-transform ${openFaq === i ? "rotate-180" : ""}`} />
                  <span className="text-sm font-medium text-[#261732] flex-1 text-right pr-2" style={AR}>{faq.q}</span>
                </button>
                {openFaq === i && (
                  <div className="px-5 pb-4">
                    <p className="text-sm text-[#5a4a5e] leading-relaxed text-right" style={AR}>{faq.a}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
        <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[24px] p-4 text-center">
          <p className="text-xs text-[#5a4a5e]" style={AR}>وقت الدعم: الأحد – الخميس · ٩ ص – ٦ م</p>
        </div>
      </div>
    </ScreenBg>
  );
}

// ── 16. Designer Portfolio ────────────────────────────────────────────────────

function DesignerPortfolioScreen({ designer: d, onBack, onRequest }: {
  designer: Designer; onBack: () => void; onRequest: () => void;
}) {
  const [tab, setTab]           = useState<"portfolio" | "reviews" | "experience">("portfolio");
  const [portSearch, setPortSearch] = useState("");

  const filtered = portSearch.trim()
    ? d.portfolio.filter((_, i) => i % 2 === 0)
    : d.portfolio;

  const REVIEWS = [
    { name: "سارة م.",   rating: 5, text: "تصميم راقٍ جداً، التسليم كان في الوقت المحدد ومواصفاتي كلها اتحققت!", date: "يوليو ٢٠٢٥" },
    { name: "منى ع.",   rating: 5, text: "أجمل فستان طلبته في حياتي، الخامة ممتازة والتفصيل دقيق.", date: "يونيو ٢٠٢٥" },
    { name: "هدى ب.",   rating: 4, text: "المصممة محترفة والتواصل معها سهل. سأطلب مرة أخرى.", date: "مايو ٢٠٢٥" },
    { name: "لمياء ص.", rating: 5, text: "تجاوزت توقعاتي! الفستان يعكس شخصيتي بالكامل.", date: "مايو ٢٠٢٥" },
  ];

  const EXPERIENCE = [
    { year: "٢٠٢٠ – الآن",   title: "مصممة مستقلة",    desc: "تصميم وخياطة فساتين السهرة والمناسبات الخاصة لعميلات VIP." },
    { year: "٢٠١٧ – ٢٠٢٠",  title: "مصممة في دار أزياء", desc: "تطوير مجموعات الفساتين السنوية وإشراف على الخياطة الدقيقة." },
    { year: "٢٠١٥ – ٢٠١٧",  title: "بكالوريوس تصميم أزياء", desc: "تخرجت بمرتبة الشرف من كلية التصميم، متخصصة في الملبس السعودي الحديث." },
  ];

  return (
    <ScreenBg overlay="bg-[#f0e8df]/50">
      {/* Header */}
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-1.5 rounded-full hover:bg-[rgba(217,217,217,0.35)] transition-colors">
            <ArrowRight size={20} className="text-[#261732]" />
          </button>
          <button className="relative p-1.5">
            <Bell size={20} className="text-[#261732]" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-[#8b5a6b] rounded-full" />
          </button>
        </div>
        <button className="p-1.5 rounded-full hover:bg-[rgba(217,217,217,0.35)] transition-colors">
          <Settings size={20} className="text-[#261732]" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Profile hero */}
        <div className="flex flex-col items-center px-6 pt-1 pb-4 gap-2">
          <div className="w-24 h-24 rounded-full overflow-hidden border-[3px] border-white/60 shadow-[0px_4px_16px_rgba(0,0,0,0.18)]">
            <img src={d.avatar} alt={d.name} className="w-full h-full object-cover" />
          </div>
          <h2 className="text-[#261732] text-2xl font-bold mt-1" style={AR}>{d.name}</h2>
          <p className="text-[#5a4a5e] text-sm" style={AR}>{d.specialty}</p>
          <div className="flex items-center gap-1.5 text-[#5a4a5e] text-xs" style={AR}>
            <MapPin size={12} className="flex-shrink-0" />
            <span>{d.location}</span>
          </div>

          {/* 4 action tabs matching reference layout */}
          <div className="flex gap-1.5 mt-3 w-full" dir="rtl">
            <Pill dark onClick={onRequest} className="flex-1 py-2.5 flex items-center justify-center">
              <span className="text-[#f0e8df] text-[11px] font-semibold" style={AR}>طلب تصميم</span>
            </Pill>
            {(["reviews","experience"] as const).map((t, i) => (
              <Pill key={t} onClick={() => setTab(t)}
                className={`flex-1 py-2.5 flex items-center justify-center transition-all ${tab === t ? "bg-[rgba(38,23,50,0.14)]" : ""}`}>
                <span className="text-[#261732] text-[10px] font-medium" style={AR}>
                  {i === 0 ? "التقييمات" : "خبراتي"}
                </span>
              </Pill>
            ))}
          </div>

          {/* Rating row */}
          <div className="flex items-center gap-2 mt-1.5">
            <span className="text-xs text-[#5a4a5e]" style={AR}>({d.reviews})</span>
            <div className="flex gap-0.5">
              {[1,2,3,4,5].map(s => (
                <Star key={s} size={13} className={s <= Math.round(d.rating) ? "text-yellow-500 fill-yellow-500" : "text-yellow-200 fill-yellow-100"} />
              ))}
            </div>
            <span className="text-[#261732] font-bold text-sm">{d.rating}</span>
          </div>
        </div>

        {/* Portfolio grid */}
        {tab === "portfolio" && (
          <div className="px-4 pb-6">
            <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] flex items-center px-4 gap-2 mb-4">
              <Search size={14} className="text-[#5a4a5e]/60 flex-shrink-0" />
              <input
                value={portSearch}
                onChange={(e) => setPortSearch(e.target.value)}
                placeholder="ابحث عن مشاريع..."
                dir="rtl"
                className="flex-1 bg-transparent py-2.5 text-sm text-[#261732] placeholder-[#5a4a5e]/45 focus:outline-none text-right"
                style={AR}
              />
              {portSearch && <button onClick={() => setPortSearch("")}><X size={13} className="text-[#5a4a5e]/40" /></button>}
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              {filtered.map((src, i) => (
                <div key={i} className="rounded-2xl overflow-hidden shadow-[0px_4px_8px_rgba(0,0,0,0.12)] aspect-[4/3]">
                  <img src={src} alt={`عمل ${i + 1}`} className="w-full h-full object-cover object-top" />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Reviews */}
        {tab === "reviews" && (
          <div className="px-4 pb-6 space-y-3" dir="rtl">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-[#5a4a5e]" style={AR}>{d.reviews} تقييم</span>
              <div className="flex items-center gap-1.5">
                {[1,2,3,4,5].map(s => <Star key={s} size={13} className="text-yellow-500 fill-yellow-500" />)}
                <span className="font-bold text-[#261732] text-sm">{d.rating}</span>
              </div>
            </div>
            {REVIEWS.map((r, i) => (
              <div key={i} className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-2xl shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] text-[#5a4a5e]">{r.date}</span>
                  <div className="flex items-center gap-1.5">
                    <div className="flex gap-0.5">
                      {[1,2,3,4,5].map(s => <Star key={s} size={10} className={s <= r.rating ? "text-yellow-500 fill-yellow-500" : "text-yellow-200"} />)}
                    </div>
                    <span className="font-semibold text-sm text-[#261732]" style={AR}>{r.name}</span>
                  </div>
                </div>
                <p className="text-sm text-[#5a4a5e] leading-relaxed text-right" style={AR}>{r.text}</p>
              </div>
            ))}
          </div>
        )}

        {/* Experience */}
        {tab === "experience" && (
          <div className="px-4 pb-6 space-y-4" dir="rtl">
            <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-2xl shadow-[0px_4px_4px_1px_rgba(0,0,0,0.1)] p-4 flex gap-3 flex-row-reverse items-center">
              <Award size={28} className="text-[#261732] flex-shrink-0" />
              <div className="text-right">
                <p className="font-bold text-[#261732]" style={AR}>{d.orders} طلب مكتمل</p>
                <p className="text-xs text-[#5a4a5e]" style={AR}>منذ انضمامها للمنصة</p>
              </div>
            </div>
            {EXPERIENCE.map((e, i) => (
              <div key={i} className="flex gap-4 flex-row-reverse">
                <div className="flex flex-col items-center">
                  <div className="w-3 h-3 rounded-full bg-[#261732] flex-shrink-0 mt-1" />
                  {i < EXPERIENCE.length - 1 && <div className="w-0.5 h-14 bg-[#261732]/15 mt-1" />}
                </div>
                <div className="flex-1 pb-4 text-right">
                  <p className="text-[10px] text-[#5a4a5e] mb-0.5" style={AR}>{e.year}</p>
                  <p className="font-semibold text-[#261732] text-sm" style={AR}>{e.title}</p>
                  <p className="text-xs text-[#5a4a5e] mt-0.5 leading-relaxed" style={AR}>{e.desc}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Sticky CTA */}
      <div className="flex-shrink-0 px-5 pb-6 pt-3 bg-[#f0e8df]/60 backdrop-blur-sm border-t border-[#261732]/6">
        <Pill dark onClick={onRequest} className="w-full py-4 flex items-center justify-center">
          <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>طلب تصميم من {d.name}</span>
        </Pill>
      </div>
    </ScreenBg>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// INTERIOR / EXTERIOR DESIGNER FLOW
// ══════════════════════════════════════════════════════════════════════════════

// ── Interior design image pool ────────────────────────────────────────────────
const ID = {
  bedroom:  "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=600&h=400&fit=crop&auto=format",
  living:   "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=600&h=400&fit=crop&auto=format",
  kitchen:  "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop&auto=format",
  office:   "https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&h=400&fit=crop&auto=format",
  villa:    "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600&h=400&fit=crop&auto=format",
  luxury:   "https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=600&h=400&fit=crop&auto=format",
  lounge:   "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=600&h=400&fit=crop&auto=format",
  bath:     "https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=600&h=400&fit=crop&auto=format",
  exterior: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=600&h=400&fit=crop&auto=format",
  exterior2:"https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=600&h=400&fit=crop&auto=format",
};

// ── Customer avatar pool ───────────────────────────────────────────────────────
const CA = {
  a: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop&auto=format",
  b: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&h=80&fit=crop&auto=format",
  c: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=80&h=80&fit=crop&auto=format",
  d: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80&h=80&fit=crop&auto=format",
};

// ── Designer data interfaces ───────────────────────────────────────────────────
interface IDRequest {
  id: string;
  title: string;
  category: string;
  budget: string;
  city: string;
  date: string;
  isPrivate: boolean;
  img: string;
  customer: string;
  customerAvatar: string;
  description: string;
  status: string;
  style?: string;
  deadline?: string;
}

interface IDChat {
  id: string;
  customer: string;
  avatar: string;
  lastMsg: string;
  time: string;
  unread: number;
  relatedTo: string;
}

// ── Mock data ─────────────────────────────────────────────────────────────────
const ID_REQUESTS: IDRequest[] = [
  { id: "R001", title: "غرفة نوم رئيسية عصرية",  category: "غرفة نوم",   budget: "١٢٠٠٠–١٨٠٠٠ ر.س", city: "الرياض",   date: "١٥ يوليو ٢٠٢٥", isPrivate: false, img: ID.bedroom, customer: "أحمد الفارسي",  customerAvatar: CA.a, description: "أبحث عن تصميم غرفة نوم رئيسية بأسلوب عصري هادئ، الألوان المفضلة بيج وبني داكن، تشمل تصميم رأسية السرير والخزانة.", style: "عصري", deadline: "٣٠ أغسطس ٢٠٢٥", status: "جديد" },
  { id: "R002", title: "صالة استقبال فاخرة",      category: "غرفة معيشة", budget: "٢٥٠٠٠–٣٥٠٠٠ ر.س", city: "جدة",     date: "١٤ يوليو ٢٠٢٥", isPrivate: false, img: ID.living,  customer: "منى القحطاني", customerAvatar: CA.b, description: "أريد صالة استقبال بطابع كلاسيكي حديث، مساحة ١٢٠ م²، يشمل التصميم اختيار الأثاث والإضاءة.", style: "كلاسيكي حديث", deadline: "٣١ أكتوبر ٢٠٢٥", status: "جديد" },
  { id: "R003", title: "مكتب منزلي أنيق",         category: "مكتب",        budget: "٨٠٠٠–١٢٠٠٠ ر.س",  city: "الدمام",  date: "١٣ يوليو ٢٠٢٥", isPrivate: true,  img: ID.office,  customer: "سعود الحارثي", customerAvatar: CA.c, description: "مكتب منزلي بأسلوب مينيمال، مساحة ٢٠ م²، التركيز على الإضاءة الطبيعية وتنظيم الكابلات.", style: "مينيمال", deadline: "٥ سبتمبر ٢٠٢٥", status: "جديد" },
  { id: "R004", title: "مطبخ عملي وعصري",         category: "مطبخ",        budget: "١٥٠٠٠–٢٠٠٠٠ ر.س", city: "الرياض",  date: "١٢ يوليو ٢٠٢٥", isPrivate: false, img: ID.kitchen, customer: "لمياء العتيبي", customerAvatar: CA.d, description: "مطبخ مفتوح يتصل بغرفة المعيشة، جزيرة مطبخ في المنتصف، ألوان بيضاء وذهبية.", style: "عصري", deadline: "٢٠ سبتمبر ٢٠٢٥", status: "جديد" },
  { id: "R005", title: "فيلا خارجية كاملة",        category: "فيلا",        budget: "٥٠٠٠٠+ ر.س",      city: "جدة",     date: "١٠ يوليو ٢٠٢٥", isPrivate: true,  img: ID.exterior, customer: "أحمد الفارسي", customerAvatar: CA.a, description: "تصميم خارجي لفيلا جديدة ٤ أدوار، يشمل المسبح والحديقة والمدخل الرئيسي.", style: "معاصر", deadline: "١ نوفمبر ٢٠٢٥", status: "جديد" },
];

const ID_MANAGED: IDRequest[] = [
  { id: "M001", title: "غرفة نوم فاخرة",   category: "غرفة نوم",   budget: "١٦٠٠٠ ر.س",  city: "الرياض",  date: "٥ يوليو ٢٠٢٥", isPrivate: true,  img: ID.luxury,  customer: "هدى السبيعي",  customerAvatar: CA.d, description: "تصميم غرفة نوم ماستر بأسلوب فاخر.", status: "قيد التنفيذ" },
  { id: "M002", title: "صالة جلوس كلاسيك", category: "غرفة معيشة", budget: "٢٨٠٠٠ ر.س",  city: "مكة",     date: "٢٠ يونيو ٢٠٢٥", isPrivate: false, img: ID.lounge,  customer: "سارة العمري",  customerAvatar: CA.b, description: "صالة جلوس بتصميم كلاسيكي.", status: "بانتظار رد العميل" },
  { id: "M003", title: "حمام رئيسي عصري",   category: "حمام",       budget: "٩٠٠٠ ر.س",   city: "جدة",     date: "١ يونيو ٢٠٢٥",  isPrivate: false, img: ID.bath,    customer: "خالد المطيري", customerAvatar: CA.c, description: "حمام ماستر بتصميم فندقي.", status: "مكتمل" },
];

const ID_CHATS: IDChat[] = [
  { id: "C001", customer: "هدى السبيعي",  avatar: CA.d, lastMsg: "متى يبدأ التنفيذ؟",         time: "منذ ١٠ د",  unread: 2, relatedTo: "غرفة نوم فاخرة"   },
  { id: "C002", customer: "سارة العمري",  avatar: CA.b, lastMsg: "تم مراجعة العرض شكراً",      time: "منذ ١ س",   unread: 0, relatedTo: "صالة جلوس كلاسيك" },
  { id: "C003", customer: "أحمد الفارسي", avatar: CA.a, lastMsg: "هل يمكن التعديل على اللون؟", time: "أمس",        unread: 1, relatedTo: "مكتب منزلي أنيق"   },
];

// ── Shared bottom nav for designer app ───────────────────────────────────────
type DTab = "home"|"browse"|"manage"|"chat"|"profile";
function DNav({ active, onTab }: { active: DTab; onTab: (t: DTab) => void }) {
  const tabs: { id: DTab; label: string; icon: React.FC<{ size: number; className?: string }> }[] = [
    { id: "home",    label: "الرئيسية",   icon: Home         },
    { id: "browse",  label: "الطلبات",    icon: Search       },
    { id: "manage",  label: "الإدارة",    icon: ClipboardList },
    { id: "chat",    label: "المحادثات",  icon: MessageSquare },
    { id: "profile", label: "الملف",      icon: User         },
  ];
  return (
    <div className="flex-shrink-0 bg-white/70 backdrop-blur-[14px] border-t border-white/30 flex items-center"
      style={{ boxShadow: "0px -4px 4px rgba(0,0,0,0.02)" }}>
      {tabs.map((t) => (
        <button key={t.id} onClick={() => onTab(t.id)}
          className={`flex-1 flex flex-col items-center py-3 gap-0.5 transition-colors ${active === t.id ? "text-[#261732]" : "text-[#261732]/30"}`}>
          <t.icon size={19} className={active === t.id ? "text-[#261732]" : "text-[#261732]/30"} />
          <span className="text-[8px] font-medium mt-0.5" style={AR}>{t.label}</span>
        </button>
      ))}
    </div>
  );
}

// ── DCard helper – frosted card ───────────────────────────────────────────────
function DCard({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-[rgba(217,217,217,0.28)] backdrop-blur-sm rounded-2xl shadow-[0px_4px_4px_1px_rgba(0,0,0,0.12)] ${className}`}>
      {children}
    </div>
  );
}

// ── D-ScreenBg: cream overlay lighter for interior theme ─────────────────────
function DScreenBg({ children }: { children: React.ReactNode }) {
  return (
    <div className="h-full flex flex-col overflow-hidden relative">
      <img src={bgAbstract} alt="" aria-hidden
        className="absolute inset-0 w-full h-full object-cover pointer-events-none select-none opacity-40" />
      <div className="absolute inset-0 bg-[#f5f1ec]/75" />
      <div className="relative z-10 h-full flex flex-col">{children}</div>
    </div>
  );
}

// ── Z-A. Designer Sign Up ─────────────────────────────────────────────────────
function DesignerSignUpScreen({ onBack, onNext }: { onBack: () => void; onNext: () => void }) {
  const [form, setForm] = useState({ name: "", email: "", phone: "", pass: "", confirm: "" });
  const [showP, setShowP] = useState(false);
  const valid = form.name && form.email && form.phone && form.pass && form.confirm === form.pass;
  const Field = ({ label, field, type = "text", ph }: { label: string; field: keyof typeof form; type?: string; ph: string }) => (
    <div>
      <label className="text-[11px] text-[#5a4a5e] mb-1 block text-right" style={AR}>{label}</label>
      <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.08)] flex items-center">
        <input type={type} value={form[field]} onChange={e => setForm(p => ({ ...p, [field]: e.target.value }))} placeholder={ph} dir={field === "email" || field === "phone" ? "ltr" : "rtl"}
          className="flex-1 bg-transparent px-5 py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/40 focus:outline-none text-right" style={AR} />
        {(field === "pass" || field === "confirm") && (
          <button onClick={() => setShowP(p => !p)} className="pr-4 text-[#5a4a5e]">{showP ? <EyeOff size={15}/> : <Eye size={15}/>}</button>
        )}
      </div>
    </div>
  );
  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex-shrink-0 flex items-center px-4 pt-2 pb-1">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-[rgba(217,217,217,0.3)] transition-colors">
          <ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto px-6 pb-8" dir="rtl">
        <div className="mb-6">
          <Logo size="sm" />
          <h2 className="text-xl font-bold text-[#261732] mt-3" style={AR}>إنشاء حساب مصمم</h2>
          <p className="text-sm text-[#5a4a5e] mt-0.5" style={AR}>أدخل بياناتك للتسجيل</p>
        </div>
        <div className="space-y-3.5">
          <Field label="الاسم الكامل"       field="name"    ph="محمد العمري" />
          <Field label="البريد الإلكتروني"  field="email"   ph="example@mail.com" />
          <Field label="رقم الجوال"         field="phone"   ph="+966 5x xxx xxxx" />
          <Field label="كلمة المرور"        field="pass"    type={showP?"text":"password"} ph="••••••••" />
          <Field label="تأكيد كلمة المرور" field="confirm" type={showP?"text":"password"} ph="••••••••" />
          {form.confirm && form.confirm !== form.pass && (
            <p className="text-xs text-red-500 text-right" style={AR}>كلمتا المرور غير متطابقتين</p>
          )}
        </div>
        <div className="mt-6">
          <Pill dark onClick={valid ? onNext : undefined} className={`w-full py-4 flex items-center justify-center ${!valid ? "opacity-40" : ""}`}>
            <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>التالي</span>
          </Pill>
        </div>
      </div>
    </ScreenBg>
  );
}

// ── Z-B. Designer Profile Setup (Interior/Exterior) ───────────────────────────
function DesignerProfileSetupScreen({ field, onBack, onDone }: { field: string; onBack: () => void; onDone: () => void }) {
  const [name, setName]     = useState("");
  const [city, setCity]     = useState("");
  const [bio, setBio]       = useState("");
  const [years, setYears]   = useState("");
  const valid = name && city;
  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex-shrink-0 flex items-center px-4 pt-2 pb-1">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-[rgba(217,217,217,0.3)] transition-colors">
          <ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto px-6 pb-8" dir="rtl">
        <div className="mb-5">
          <h2 className="text-xl font-bold text-[#261732]" style={AR}>إعداد ملفك الشخصي</h2>
          <p className="text-sm text-[#5a4a5e] mt-0.5" style={AR}>{field === "exterior" ? "مصمم خارجي" : "مصمم داخلي"}</p>
        </div>
        {/* Avatar upload */}
        <div className="flex flex-col items-center mb-6">
          <div className="relative">
            <div className="w-20 h-20 rounded-full bg-[rgba(38,23,50,0.08)] flex items-center justify-center border-2 border-[#261732]/15">
              <User size={32} className="text-[#261732]/40" />
            </div>
            <button className="absolute -bottom-1 -left-1 w-7 h-7 rounded-full bg-[#261732] flex items-center justify-center shadow">
              <Upload size={12} className="text-[#f0e8df]" />
            </button>
          </div>
          <p className="text-xs text-[#5a4a5e] mt-2" style={AR}>رفع صورة شخصية</p>
        </div>
        <div className="space-y-3.5">
          {[
            { label: "اسم المصمم", val: name, set: setName, ph: "محمد العمري" },
            { label: "المدينة",    val: city, set: setCity, ph: "الرياض" },
          ].map(({ label, val, set, ph }) => (
            <div key={label}>
              <label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>{label}</label>
              <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.08)]">
                <input value={val} onChange={e => set(e.target.value)} placeholder={ph}
                  className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/40 focus:outline-none text-right" style={AR}/>
              </div>
            </div>
          ))}
          <div>
            <label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>نبذة مختصرة</label>
            <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[20px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.08)]">
              <textarea value={bio} onChange={e => setBio(e.target.value)} placeholder="أكثر من ١٠ سنوات خبرة في تصميم الفضاءات الداخلية..." rows={3}
                className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/40 focus:outline-none text-right resize-none" style={AR}/>
            </div>
          </div>
          <div>
            <label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>سنوات الخبرة</label>
            <div className="flex gap-2 flex-wrap justify-end">
              {["أقل من ٢", "٢–٥", "٥–١٠", "أكثر من ١٠"].map(y => (
                <button key={y} onClick={() => setYears(y)}
                  className={`text-xs px-3 py-1.5 rounded-full border transition-all ${years === y ? "bg-[#261732] text-[#f0e8df] border-[#261732]" : "bg-[rgba(217,217,217,0.3)] text-[#261732] border-[#261732]/15"}`} style={AR}>{y} سنة</button>
              ))}
            </div>
          </div>
        </div>
        <div className="mt-6">
          <Pill dark onClick={valid ? onDone : undefined} className={`w-full py-4 flex items-center justify-center ${!valid ? "opacity-40" : ""}`}>
            <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>إنشاء الحساب</span>
          </Pill>
        </div>
      </div>
    </ScreenBg>
  );
}

// ── 1. Designer Home ──────────────────────────────────────────────────────────
const PORTFOLIO_IMGS = [ID.bedroom, ID.living, ID.kitchen, ID.luxury, ID.lounge, ID.bath, ID.exterior, ID.villa];

function DHome({ onTab, activeTab, onPendingCard, onRating, onPortfolio }: {
  onTab: (t: DTab) => void; activeTab: DTab;
  onPendingCard: () => void; onRating: () => void; onPortfolio: () => void;
}) {
  const privateCount = ID_REQUESTS.filter(r => r.isPrivate).length;
  return (
    <DScreenBg>
      {/* Header */}
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6">
        <button className="relative p-1.5">
          <Bell size={20} className="text-[#261732]" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-[#8b5a6b] rounded-full" />
        </button>
        <h1 className="text-[#261732] text-base font-bold" style={AR}>الرئيسية</h1>
        <div className="w-9 h-9 rounded-full bg-[rgba(38,23,50,0.1)] flex items-center justify-center">
          <User size={17} className="text-[#261732]" />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4" dir="rtl">
        {/* Pending private requests card */}
        <button onClick={onPendingCard} className="w-full text-right">
          <DCard className="p-4 flex items-center justify-between hover:shadow-lg transition-shadow">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#261732]/8 flex items-center justify-center flex-shrink-0">
                <ClipboardList size={18} className="text-[#261732]" />
              </div>
              <div>
                <p className="text-2xl font-bold text-[#261732]">{privateCount}</p>
                <p className="text-[10px] text-[#5a4a5e]" style={AR}>طلب خاص جديد</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm font-semibold text-[#261732]" style={AR}>الطلبات الخاصة</p>
              <p className="text-[10px] text-[#5a4a5e]" style={AR}>غير المعالجة</p>
              <ChevronRight size={14} className="text-[#261732]/30 mt-1 mr-auto" style={{ transform: "scaleX(-1)" }} />
            </div>
          </DCard>
        </button>

        {/* Rating */}
        <button onClick={onRating} className="w-full text-right">
          <DCard className="p-4 flex items-center justify-between hover:shadow-lg transition-shadow">
            <ChevronRight size={14} className="text-[#261732]/30" style={{ transform: "scaleX(-1)" }} />
            <div className="text-right flex-1 mr-2">
              <p className="text-sm font-semibold text-[#261732]" style={AR}>تقييمي</p>
              <div className="flex items-center gap-1 justify-end mt-1">
                {[1,2,3,4,5].map(s => <span key={s} className={`text-base ${s <= 4 ? "text-yellow-400" : "text-yellow-400/40"}`}>★</span>)}
                <span className="text-base font-bold text-[#261732] mr-1">4.8</span>
              </div>
              <p className="text-[10px] text-[#5a4a5e]" style={AR}>بناءً على ٣٧ تقييم</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-yellow-50 flex items-center justify-center flex-shrink-0">
              <Star size={18} className="text-yellow-500 fill-yellow-400" />
            </div>
          </DCard>
        </button>

        {/* Designer preview card */}
        <DCard className="overflow-hidden">
          <div className="h-36 relative">
            <img src={ID.luxury} alt="portfolio" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#261732]/60 to-transparent" />
            <div className="absolute bottom-0 right-0 left-0 p-3 flex items-end gap-3 flex-row-reverse">
              <div className="w-12 h-12 rounded-full bg-[rgba(38,23,50,0.2)] backdrop-blur-sm border-2 border-white/60 flex items-center justify-center flex-shrink-0">
                <User size={22} className="text-white" />
              </div>
              <div className="text-right">
                <p className="text-white font-bold text-sm" style={AR}>محمد العمري</p>
                <p className="text-white/70 text-[10px]" style={AR}>مصمم داخلي · الرياض</p>
              </div>
            </div>
          </div>
          <div className="p-4" dir="rtl">
            <p className="text-xs text-[#5a4a5e] leading-relaxed" style={AR}>خبرة أكثر من ١٠ سنوات في تصميم الفضاءات الراقية للمنازل والمكاتب والفنادق.</p>
            <div className="mt-3">
              <div className="flex items-center justify-between mb-2">
                <button onClick={onPortfolio} className="text-[10px] text-[#261732] font-semibold underline" style={AR}>تعديل المحفظة</button>
                <p className="text-xs font-semibold text-[#261732]" style={AR}>أحدث المشاريع</p>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {PORTFOLIO_IMGS.slice(0, 4).map((img, i) => (
                  <div key={i} className="aspect-square rounded-lg overflow-hidden">
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </DCard>

        {/* Latest activity */}
        <div>
          <p className="text-sm font-semibold text-[#261732] text-right mb-2" style={AR}>آخر النشاطات</p>
          <div className="space-y-2">
            {[
              { icon: ClipboardList, text: "طلب خاص جديد من أحمد الفارسي",    sub: "غرفة نوم رئيسية عصرية", time: "منذ ١٠ د", color: "bg-blue-50" },
              { icon: MessageSquare, text: "رسالة جديدة من هدى السبيعي",       sub: "متى يبدأ التنفيذ؟",      time: "منذ ٣٠ د", color: "bg-purple-50" },
              { icon: Star,          text: "تقييم جديد من سارة العمري",        sub: "★★★★★ ممتازة جداً",      time: "منذ ٢ س",  color: "bg-yellow-50" },
            ].map((a, i) => (
              <DCard key={i} className={`p-3 flex items-center gap-3 ${a.color}`}>
                <div className="text-right flex-1">
                  <p className="text-xs font-medium text-[#261732]" style={AR}>{a.text}</p>
                  <p className="text-[10px] text-[#5a4a5e]" style={AR}>{a.sub}</p>
                </div>
                <div className="text-[10px] text-[#5a4a5e] flex-shrink-0">{a.time}</div>
                <div className="w-8 h-8 rounded-full bg-[rgba(38,23,50,0.06)] flex items-center justify-center flex-shrink-0">
                  <a.icon size={15} className="text-[#261732]" />
                </div>
              </DCard>
            ))}
          </div>
        </div>
      </div>
      <DNav active={activeTab} onTab={onTab} />
    </DScreenBg>
  );
}

// ── 2. Browse Requests ────────────────────────────────────────────────────────
const ID_FILTERS = ["الكل", "غرفة نوم", "غرفة معيشة", "مطبخ", "مكتب", "فيلا", "الأحدث", "الميزانية"];

function DBrowseRequests({ activeTab, setActiveTab, onTab, dTab, onRequest }: {
  activeTab: "public"|"private"; setActiveTab: (t: "public"|"private") => void;
  onTab: (t: DTab) => void; dTab: DTab; onRequest: (r: IDRequest) => void;
}) {
  const [filter, setFilter] = useState("الكل");
  const all = ID_REQUESTS;
  const shown = all
    .filter(r => activeTab === "private" ? r.isPrivate : !r.isPrivate)
    .filter(r => filter === "الكل" || r.category === filter);

  return (
    <DScreenBg>
      <div className="flex-shrink-0 px-5 pt-3 pb-2 border-b border-[#261732]/6">
        <h1 className="text-[#261732] text-base font-bold text-right mb-3" style={AR}>تصفح الطلبات</h1>
        {/* Tabs */}
        <div className="flex gap-2 justify-end">
          {(["public","private"] as const).map(t => (
            <button key={t} onClick={() => setActiveTab(t)}
              className={`px-4 py-1.5 rounded-full text-xs font-medium transition-all ${activeTab === t ? "bg-[#261732] text-[#f0e8df]" : "bg-[rgba(217,217,217,0.3)] text-[#261732]"}`} style={AR}>
              {t === "public" ? "الطلبات العامة" : "الطلبات الخاصة"}
            </button>
          ))}
        </div>
      </div>
      {/* Filters */}
      <div className="flex-shrink-0 px-4 py-2.5 overflow-x-auto">
        <div className="flex gap-2 justify-end">
          {ID_FILTERS.map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`flex-shrink-0 text-[10px] px-3 py-1.5 rounded-full border transition-all ${filter === f ? "bg-[#261732] text-[#f0e8df] border-[#261732]" : "bg-[rgba(217,217,217,0.25)] text-[#261732] border-[#261732]/15"}`} style={AR}>{f}</button>
          ))}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-5 pb-4 space-y-3" dir="rtl">
        {shown.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <Search size={32} className="text-[#261732]/15" />
            <p className="text-sm text-[#5a4a5e]" style={AR}>لا توجد طلبات في هذه الفئة</p>
          </div>
        )}
        {shown.map((r) => (
          <button key={r.id} onClick={() => onRequest(r)} className="w-full text-right">
            <DCard className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="h-36 relative">
                <img src={r.img} alt={r.title} className="w-full h-full object-cover" />
                <div className="absolute top-2 right-2">
                  <span className={`text-[9px] px-2 py-0.5 rounded-full font-medium ${r.isPrivate ? "bg-[#261732] text-[#f0e8df]" : "bg-white/80 text-[#261732]"}`} style={AR}>
                    {r.isPrivate ? "خاص" : "عام"}
                  </span>
                </div>
              </div>
              <div className="p-3">
                <p className="font-bold text-[#261732] text-sm" style={AR}>{r.title}</p>
                <p className="text-[10px] text-[#5a4a5e] mt-0.5 line-clamp-2" style={AR}>{r.description}</p>
                <div className="flex items-center gap-3 mt-2 text-[10px] text-[#5a4a5e] flex-wrap justify-end">
                  <span style={AR}>{r.date}</span>
                  <span style={AR}>📍 {r.city}</span>
                  <span style={AR}>💰 {r.budget}</span>
                  <span className="bg-[rgba(217,217,217,0.4)] px-2 py-0.5 rounded-full" style={AR}>{r.category}</span>
                </div>
              </div>
            </DCard>
          </button>
        ))}
      </div>
      <DNav active={dTab} onTab={onTab} />
    </DScreenBg>
  );
}

// ── 3. Request Details ────────────────────────────────────────────────────────
function DRequestDetails({ request: r, onBack, onAccept, onReject }: {
  request: IDRequest | null; onBack: () => void; onAccept: () => void; onReject: () => void;
}) {
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [reason, setReason] = useState("");
  if (!r) return null;

  const images = [r.img, ID.living, ID.bedroom].slice(0, 3);

  return (
    <DScreenBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl">
        <h2 className="font-bold text-[#261732]" style={AR}>تفاصيل الطلب</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 overflow-y-auto pb-4" dir="rtl">
        {/* Image gallery */}
        <div className="flex gap-1.5 p-4">
          <div className="flex-[2] h-44 rounded-xl overflow-hidden">
            <img src={images[0]} alt="" className="w-full h-full object-cover" />
          </div>
          <div className="flex-1 flex flex-col gap-1.5">
            {images.slice(1).map((img, i) => (
              <div key={i} className="flex-1 rounded-xl overflow-hidden">
                <img src={img} alt="" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>
        <div className="px-5 space-y-4">
          {/* Customer */}
          <div className="flex items-center gap-3 flex-row-reverse">
            <img src={r.customerAvatar} alt={r.customer} className="w-10 h-10 rounded-full object-cover border-2 border-white/60 flex-shrink-0" />
            <div className="text-right">
              <p className="font-semibold text-sm text-[#261732]" style={AR}>{r.customer}</p>
              <p className="text-[10px] text-[#5a4a5e]">{r.date}</p>
            </div>
          </div>
          <DCard className="p-4 space-y-3">
            <p className="font-bold text-[#261732]" style={AR}>{r.title}</p>
            <p className="text-sm text-[#5a4a5e] leading-relaxed" style={AR}>{r.description}</p>
            {[
              ["النوع",     r.category],
              ["الأسلوب",   r.style || "—"],
              ["الميزانية", r.budget],
              ["المدينة",   r.city],
              ["الموعد النهائي", r.deadline || "—"],
            ].map(([k,v]) => (
              <div key={k} className="flex justify-between text-sm border-t border-[#261732]/6 pt-2">
                <span className="text-[#5a4a5e]" style={AR}>{v}</span>
                <span className="font-medium text-[#261732]/70" style={AR}>{k}</span>
              </div>
            ))}
          </DCard>
        </div>
      </div>
      <div className="flex-shrink-0 px-5 pb-6 pt-3 flex gap-3">
        <button onClick={() => setShowRejectModal(true)}
          className="flex-1 py-3.5 rounded-[50px] bg-[rgba(217,217,217,0.3)] text-[#261732] text-sm font-semibold" style={AR}>رفض الطلب</button>
        <Pill dark onClick={onAccept} className="flex-1 py-3.5 flex items-center justify-center">
          <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>قبول الطلب</span>
        </Pill>
      </div>

      {/* Reject modal */}
      {showRejectModal && (
        <div className="absolute inset-0 bg-[#261732]/40 z-50 flex items-end">
          <div className="w-full bg-[#f5f1ec] rounded-t-3xl p-6" dir="rtl">
            <h3 className="font-bold text-[#261732] text-base mb-1" style={AR}>تأكيد الرفض</h3>
            <p className="text-sm text-[#5a4a5e] mb-4" style={AR}>هل أنت متأكد من رفض هذا الطلب؟</p>
            <div className="bg-[rgba(217,217,217,0.3)] rounded-2xl mb-4">
              <textarea value={reason} onChange={e => setReason(e.target.value)} placeholder="سبب الرفض (اختياري)..." rows={3}
                className="w-full bg-transparent px-4 py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/50 resize-none focus:outline-none text-right" style={AR}/>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setShowRejectModal(false)} className="flex-1 py-3 rounded-[50px] bg-[rgba(217,217,217,0.4)] text-sm font-medium text-[#261732]" style={AR}>إلغاء</button>
              <button onClick={() => { setShowRejectModal(false); onReject(); }} className="flex-1 py-3 rounded-[50px] bg-red-500 text-white text-sm font-semibold" style={AR}>تأكيد الرفض</button>
            </div>
          </div>
        </div>
      )}
    </DScreenBg>
  );
}

// ── 4. Create Offer ───────────────────────────────────────────────────────────
function DCreateOffer({ request: r, onBack, onSend }: {
  request: IDRequest | null; onBack: () => void; onSend: () => void;
}) {
  const [price, setPrice]      = useState("");
  const [time, setTime]        = useState("");
  const [delivery, setDelivery]= useState("");
  const [note, setNote]        = useState("");
  const valid = price && time;
  if (!r) return null;
  return (
    <DScreenBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl">
        <h2 className="font-bold text-[#261732]" style={AR}>إرسال عرض</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4" dir="rtl">
        <DCard className="p-3 flex items-center gap-3 flex-row-reverse">
          <div className="w-10 h-10 rounded-xl overflow-hidden flex-shrink-0">
            <img src={r.img} alt="" className="w-full h-full object-cover" />
          </div>
          <div className="text-right flex-1">
            <p className="text-sm font-semibold text-[#261732]" style={AR}>{r.title}</p>
            <p className="text-[10px] text-[#5a4a5e]" style={AR}>{r.customer} · {r.city}</p>
          </div>
        </DCard>
        {[
          { label: "السعر المقترح (ر.س)", val: price, set: setPrice, ph: "مثال: ١٥٠٠٠", type: "text" },
          { label: "مدة الإنجاز المتوقعة", val: time, set: setTime, ph: "مثال: ٣ أسابيع", type: "text" },
          { label: "تاريخ التسليم المتوقع", val: delivery, set: setDelivery, ph: "مثال: ١ سبتمبر ٢٠٢٥", type: "text" },
        ].map(({ label, val, set, ph }) => (
          <div key={label}>
            <label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>{label}</label>
            <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.08)]">
              <input value={val} onChange={e => set(e.target.value)} placeholder={ph}
                className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/40 focus:outline-none text-right" style={AR}/>
            </div>
          </div>
        ))}
        <div>
          <label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>رسالتك للعميل</label>
          <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-2xl shadow-[0px_4px_4px_1px_rgba(0,0,0,0.08)]">
            <textarea value={note} onChange={e => setNote(e.target.value)} placeholder="اكتب رسالة للعميل تشرح فيها عرضك..." rows={4}
              className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/50 resize-none focus:outline-none text-right" style={AR}/>
          </div>
        </div>
      </div>
      <div className="flex-shrink-0 px-5 pb-6 pt-3">
        <Pill dark onClick={valid ? onSend : undefined} className={`w-full py-4 flex items-center justify-center ${!valid ? "opacity-40" : ""}`}>
          <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>إرسال العرض للعميل</span>
        </Pill>
      </div>
    </DScreenBg>
  );
}

// ── 5. Manage Requests ────────────────────────────────────────────────────────
const MANAGE_TABS = [
  { id: "pending",  label: "قيد الانتظار"     },
  { id: "waiting",  label: "بانتظار العميل"    },
  { id: "active",   label: "قيد التنفيذ"      },
  { id: "done",     label: "مكتمل"             },
  { id: "rejected", label: "مرفوض"             },
  { id: "canceled", label: "ملغي"              },
];

const STATUS_BG: Record<string, string> = {
  "قيد التنفيذ":        "bg-blue-100/70 text-blue-800",
  "بانتظار رد العميل":  "bg-orange-100/70 text-orange-700",
  "مكتمل":             "bg-green-100/70 text-green-800",
  "مرفوض":             "bg-red-100/70 text-red-700",
  "ملغي":              "bg-gray-100/70 text-gray-600",
  "جديد":              "bg-purple-100/70 text-purple-700",
};

function DManageRequests({ activeTab, setActiveTab, onTab, dTab, onRequest }: {
  activeTab: string; setActiveTab: (t: string) => void;
  onTab: (t: DTab) => void; dTab: DTab; onRequest: (r: IDRequest) => void;
}) {
  const tabFilter: Record<string, string> = {
    pending: "جديد", waiting: "بانتظار رد العميل", active: "قيد التنفيذ",
    done: "مكتمل", rejected: "مرفوض", canceled: "ملغي",
  };
  const shown = ID_MANAGED.filter(r => r.status === tabFilter[activeTab] || (activeTab === "active" && r.status === "قيد التنفيذ"));

  return (
    <DScreenBg>
      <div className="flex-shrink-0 px-5 pt-3 pb-0 border-b border-[#261732]/6">
        <h1 className="text-[#261732] text-base font-bold text-right mb-2" style={AR}>إدارة الطلبات</h1>
        <div className="flex gap-1.5 overflow-x-auto pb-2">
          {MANAGE_TABS.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)}
              className={`flex-shrink-0 text-[9px] px-3 py-1.5 rounded-full transition-all font-medium ${activeTab === t.id ? "bg-[#261732] text-[#f0e8df]" : "bg-[rgba(217,217,217,0.35)] text-[#261732]"}`} style={AR}>
              {t.label}
            </button>
          ))}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3" dir="rtl">
        {shown.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <Briefcase size={32} className="text-[#261732]/15" />
            <p className="text-sm text-[#5a4a5e]" style={AR}>لا توجد طلبات هنا</p>
          </div>
        )}
        {shown.map(r => (
          <button key={r.id} onClick={() => onRequest(r)} className="w-full text-right">
            <DCard className="p-3 flex items-center gap-3 flex-row-reverse hover:shadow-lg transition-shadow">
              <div className="w-14 h-14 rounded-xl overflow-hidden flex-shrink-0">
                <img src={r.img} alt="" className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 text-right">
                <p className="font-semibold text-sm text-[#261732]" style={AR}>{r.title}</p>
                <p className="text-[10px] text-[#5a4a5e]" style={AR}>{r.customer} · {r.budget}</p>
                <div className="flex items-center gap-2 justify-end mt-1">
                  <span className={`text-[9px] px-2 py-0.5 rounded-full font-medium ${STATUS_BG[r.status] || "bg-gray-100/70 text-gray-600"}`} style={AR}>{r.status}</span>
                  <span className="text-[9px] text-[#5a4a5e]">{r.date}</span>
                </div>
              </div>
              <ChevronRight size={14} className="text-[#261732]/20 flex-shrink-0" style={{ transform: "scaleX(-1)" }} />
            </DCard>
          </button>
        ))}
      </div>
      <DNav active={dTab} onTab={onTab} />
    </DScreenBg>
  );
}

// ── 6. Manage Request Details ─────────────────────────────────────────────────
function DManageDetails({ request: r, onBack, onChat }: {
  request: IDRequest | null; onBack: () => void; onChat: () => void;
}) {
  if (!r) return null;
  const TIMELINE = [
    { label: "تم تقديم الطلب",       done: true  },
    { label: "تم إرسال العرض",       done: r.status !== "جديد" },
    { label: "قبول العميل للعرض",    done: r.status === "قيد التنفيذ" || r.status === "مكتمل" },
    { label: "قيد التنفيذ",          done: r.status === "قيد التنفيذ" || r.status === "مكتمل" },
    { label: "مكتمل",                done: r.status === "مكتمل" },
  ];
  const activeIdx = TIMELINE.findLastIndex(t => t.done);

  return (
    <DScreenBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl">
        <h2 className="font-bold text-[#261732]" style={AR}>تفاصيل الطلب</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4" dir="rtl">
        {/* Status badge */}
        <DCard className="p-4 flex items-center justify-between">
          <span className={`text-[10px] px-2.5 py-1 rounded-full font-medium ${STATUS_BG[r.status] || "bg-gray-100/70 text-gray-600"}`} style={AR}>{r.status}</span>
          <div className="text-right">
            <p className="font-bold text-[#261732]" style={AR}>{r.title}</p>
            <p className="text-xs text-[#5a4a5e]">{r.customer} · {r.city}</p>
          </div>
        </DCard>

        {/* Timeline */}
        <DCard className="p-4">
          <p className="font-semibold text-sm text-[#261732] text-right mb-4" style={AR}>مسار الطلب</p>
          {TIMELINE.map((step, i) => (
            <div key={i} className="flex gap-4 flex-row-reverse">
              <div className="flex flex-col items-center">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 border-2 ${step.done ? "bg-[#261732] border-[#261732]" : i === activeIdx + 1 ? "border-[#261732] bg-white/40" : "border-[#261732]/15 bg-white/10"}`}>
                  {step.done ? <CheckCircle size={14} className="text-white" /> : <div className={`w-2.5 h-2.5 rounded-full ${i === activeIdx + 1 ? "bg-[#261732]" : "bg-[#261732]/20"}`} />}
                </div>
                {i < TIMELINE.length - 1 && <div className={`w-0.5 h-8 mt-1 ${step.done ? "bg-[#261732]" : "bg-[#261732]/10"}`} />}
              </div>
              <div className="pb-6 pt-0.5 text-right">
                <p className={`text-sm font-medium ${step.done || i === activeIdx + 1 ? "text-[#261732]" : "text-[#261732]/30"}`} style={AR}>{step.label}</p>
              </div>
            </div>
          ))}
        </DCard>

        {/* Offer details */}
        <DCard className="p-4 space-y-2">
          <p className="font-semibold text-sm text-[#261732] text-right mb-2" style={AR}>تفاصيل العرض</p>
          {[["السعر المقترح","١٥٠٠٠ ر.س"],["مدة الإنجاز","٣ أسابيع"],["الميزانية الأصلية", r.budget]].map(([k,v]) => (
            <div key={k} className="flex justify-between text-sm border-t border-[#261732]/6 pt-2 first:border-0 first:pt-0">
              <span className="text-[#5a4a5e]" style={AR}>{v}</span>
              <span className="font-medium text-[#261732]/70" style={AR}>{k}</span>
            </div>
          ))}
        </DCard>

        {/* Actions */}
        <div className="flex gap-3">
          <Pill className="flex-1 py-3 flex items-center justify-center gap-2" onClick={onChat}>
            <MessageSquare size={14} className="text-[#261732]" />
            <span className="text-sm text-[#261732]" style={AR}>تواصل</span>
          </Pill>
          {r.status === "قيد التنفيذ" && (
            <Pill dark className="flex-1 py-3 flex items-center justify-center">
              <span className="text-[#f0e8df] text-sm" style={AR}>تحديث التقدم</span>
            </Pill>
          )}
        </div>
      </div>
    </DScreenBg>
  );
}

// ── 7. Chats ──────────────────────────────────────────────────────────────────
function DChats({ onTab, dTab, onChat }: {
  onTab: (t: DTab) => void; dTab: DTab; onChat: (c: IDChat) => void;
}) {
  return (
    <DScreenBg>
      <div className="flex-shrink-0 px-5 py-3 border-b border-[#261732]/6">
        <h1 className="text-[#261732] text-base font-bold text-right" style={AR}>المحادثات</h1>
      </div>
      <div className="flex-1 overflow-y-auto py-3" dir="rtl">
        {ID_CHATS.map(c => (
          <button key={c.id} onClick={() => onChat(c)} className="w-full px-5 py-3 flex items-center gap-3 hover:bg-[rgba(217,217,217,0.2)] transition-colors flex-row-reverse border-b border-[#261732]/4 last:border-0">
            <div className="relative flex-shrink-0">
              <img src={c.avatar} alt={c.customer} className="w-12 h-12 rounded-full object-cover border-2 border-white/60" />
              {c.unread > 0 && (
                <span className="absolute -top-0.5 -left-0.5 w-4 h-4 bg-[#261732] rounded-full flex items-center justify-center">
                  <span className="text-[8px] text-white font-bold">{c.unread}</span>
                </span>
              )}
            </div>
            <div className="flex-1 text-right">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-[#5a4a5e]">{c.time}</span>
                <p className="font-semibold text-sm text-[#261732]" style={AR}>{c.customer}</p>
              </div>
              <p className="text-xs text-[#5a4a5e] truncate" style={AR}>{c.lastMsg}</p>
              <p className="text-[9px] text-[#5a4a5e]/60 mt-0.5" style={AR}>🔗 {c.relatedTo}</p>
            </div>
          </button>
        ))}
      </div>
      <DNav active={dTab} onTab={onTab} />
    </DScreenBg>
  );
}

// ── 8. Chat Details ───────────────────────────────────────────────────────────
const DEMO_MSGS = [
  { from: "customer", text: "مرحباً، متى يمكن أن تبدأ المشروع؟", time: "١٠:٣٠" },
  { from: "designer", text: "أهلاً! يمكننا البدء الأسبوع القادم إن شاء الله.", time: "١٠:٣٢" },
  { from: "customer", text: "ممتاز، هل يمكن تغيير لون الحائط الرئيسي إلى رمادي فاتح؟", time: "١٠:٣٥" },
  { from: "designer", text: "بالتأكيد، سنأخذ ذلك في الاعتبار. سأرسل لك عينات الألوان قريباً.", time: "١٠:٣٧" },
  { from: "customer", text: "شكراً جزيلاً 🙏", time: "١٠:٣٨" },
];

function DChatDetails({ chat: c, onBack, onViewRequest }: {
  chat: IDChat | null; onBack: () => void; onViewRequest: () => void;
}) {
  const [msg, setMsg] = useState("");
  if (!c) return null;
  return (
    <DScreenBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-2.5 border-b border-[#261732]/6" dir="rtl">
        <button onClick={onViewRequest} className="text-[10px] text-[#261732] font-medium bg-[rgba(217,217,217,0.35)] px-3 py-1.5 rounded-full" style={AR}>عرض الطلب</button>
        <div className="flex items-center gap-2 flex-row-reverse">
          <img src={c.avatar} alt={c.customer} className="w-8 h-8 rounded-full object-cover" />
          <div className="text-right">
            <p className="font-semibold text-sm text-[#261732]" style={AR}>{c.customer}</p>
            <p className="text-[9px] text-[#5a4a5e]" style={AR}>{c.relatedTo}</p>
          </div>
        </div>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3" dir="rtl">
        {DEMO_MSGS.map((m, i) => {
          const isMe = m.from === "designer";
          return (
            <div key={i} className={`flex ${isMe ? "justify-start" : "justify-end"}`}>
              <div className={`max-w-[72%] px-4 py-2.5 rounded-2xl text-sm ${isMe ? "bg-[#261732] text-[#f0e8df] rounded-br-none" : "bg-white/80 text-[#261732] rounded-bl-none shadow-sm"}`} style={AR}>
                <p>{m.text}</p>
                <p className={`text-[9px] mt-1 ${isMe ? "text-[#f0e8df]/50" : "text-[#5a4a5e]/60"} text-left`}>{m.time}</p>
              </div>
            </div>
          );
        })}
      </div>
      <div className="flex-shrink-0 px-4 pb-6 pt-2 flex items-center gap-2" dir="rtl">
        <button className="p-2.5 rounded-full bg-[rgba(217,217,217,0.3)] flex-shrink-0">
          <Upload size={16} className="text-[#261732]" />
        </button>
        <div className="flex-1 bg-[rgba(217,217,217,0.25)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.08)] flex items-center px-4 gap-2">
          <input value={msg} onChange={e => setMsg(e.target.value)} placeholder="اكتب رسالة..." className="flex-1 bg-transparent py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/50 focus:outline-none text-right" style={AR}/>
        </div>
        <button className="p-2.5 rounded-full bg-[#261732] flex-shrink-0">
          <ArrowRight size={16} className="text-[#f0e8df] rotate-180" />
        </button>
      </div>
    </DScreenBg>
  );
}

// ── 9. Designer Profile ───────────────────────────────────────────────────────
function DProfile({ field, onTab, dTab, onEdit, onPassword, onReviews, onLogout }: {
  field: string; onTab: (t: DTab) => void; dTab: DTab;
  onEdit: () => void; onPassword: () => void; onReviews: () => void; onLogout: () => void;
}) {
  const [showLogout, setShowLogout] = useState(false);
  const fieldLabel = field === "exterior" ? "مصمم خارجي" : "مصمم داخلي";
  return (
    <DScreenBg>
      <div className="flex-1 overflow-y-auto" dir="rtl">
        {/* Hero */}
        <div className="relative h-40">
          <img src={ID.luxury} alt="" className="w-full h-full object-cover opacity-50" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#f5f1ec]" />
          <div className="absolute bottom-0 right-0 left-0 flex items-end gap-4 px-5 pb-3 flex-row-reverse">
            <div className="w-18 h-18 flex-shrink-0">
              <div className="w-16 h-16 rounded-2xl bg-[rgba(38,23,50,0.12)] backdrop-blur-sm border-2 border-white/60 flex items-center justify-center">
                <User size={28} className="text-[#261732]" />
              </div>
            </div>
            <div className="text-right pb-1">
              <p className="font-bold text-[#261732] text-base" style={AR}>محمد العمري</p>
              <p className="text-xs text-[#5a4a5e]" style={AR}>{fieldLabel} · الرياض</p>
              <div className="flex items-center gap-1 justify-end mt-0.5">
                <span className="text-xs font-bold text-[#261732]">4.8</span>
                {[1,2,3,4,5].map(s => <span key={s} className={`text-xs ${s <= 4 ? "text-yellow-400" : "text-yellow-400/30"}`}>★</span>)}
              </div>
            </div>
          </div>
        </div>

        <div className="px-5 pt-3 pb-4 space-y-4">
          {/* Stats */}
          <div className="grid grid-cols-2 gap-3">
            {[["٣٧","مشروع مكتمل"],["١٢","منتج"],].map(([n, l]) => (
              <DCard key={l} className="p-3 text-center">
                <p className="text-2xl font-bold text-[#261732]">{n}</p>
                <p className="text-[10px] text-[#5a4a5e]" style={AR}>{l}</p>
              </DCard>
            ))}
          </div>

          {/* Menu */}
          <DCard className="overflow-hidden">
            {[
              { label: "تعديل الملف الشخصي", action: onEdit },
              { label: "تغيير كلمة المرور",  action: onPassword },
              { label: "تقييمات العملاء",     action: onReviews },
              { label: "تسجيل الخروج",        action: () => setShowLogout(true), danger: true },
            ].map((item, i, arr) => (
              <button key={i} onClick={item.action}
                className={`w-full flex items-center justify-between px-5 py-4 hover:bg-[rgba(217,217,217,0.25)] transition-colors ${i < arr.length - 1 ? "border-b border-[#261732]/6" : ""}`}>
                <ChevronRight size={14} className={item.danger ? "text-red-400/40" : "text-[#261732]/20"} style={{ transform: "scaleX(-1)" }} />
                <span className={`text-sm font-medium ${item.danger ? "text-red-500" : "text-[#261732]"}`} style={AR}>{item.label}</span>
              </button>
            ))}
          </DCard>
        </div>
      </div>
      <DNav active={dTab} onTab={onTab} />

      {/* Logout modal */}
      {showLogout && (
        <div className="absolute inset-0 bg-[#261732]/40 z-50 flex items-end">
          <div className="w-full bg-[#f5f1ec] rounded-t-3xl p-6" dir="rtl">
            <h3 className="font-bold text-[#261732] text-base mb-1" style={AR}>تسجيل الخروج</h3>
            <p className="text-sm text-[#5a4a5e] mb-5" style={AR}>هل أنت متأكد من تسجيل الخروج؟</p>
            <div className="flex gap-3">
              <button onClick={() => setShowLogout(false)} className="flex-1 py-3 rounded-[50px] bg-[rgba(217,217,217,0.4)] text-sm font-medium text-[#261732]" style={AR}>إلغاء</button>
              <button onClick={onLogout} className="flex-1 py-3 rounded-[50px] bg-[#261732] text-white text-sm font-semibold" style={AR}>تسجيل الخروج</button>
            </div>
          </div>
        </div>
      )}
    </DScreenBg>
  );
}

// ── 10. Edit Profile ──────────────────────────────────────────────────────────
function DEditProfile({ onBack }: { onBack: () => void }) {
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({ name: "محمد العمري", email: "m.omari@design.sa", phone: "+966 5x xxx xxxx", bio: "خبرة أكثر من ١٠ سنوات في تصميم الفضاءات.", exp: "أكثر من ١٠", city: "الرياض" });
  const Field = ({ label, k, dir: d = "rtl" }: { label: string; k: keyof typeof form; dir?: string }) => (
    <div>
      <label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>{label}</label>
      <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.08)]">
        <input value={form[k]} onChange={e => setForm(p => ({ ...p, [k]: e.target.value }))} dir={d}
          className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] focus:outline-none text-right" style={AR}/>
      </div>
    </div>
  );
  return (
    <DScreenBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl">
        <h2 className="font-bold text-[#261732]" style={AR}>تعديل الملف الشخصي</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4" dir="rtl">
        <div className="flex flex-col items-center gap-2">
          <div className="relative">
            <div className="w-20 h-20 rounded-2xl bg-[rgba(38,23,50,0.08)] flex items-center justify-center border-2 border-[#261732]/15">
              <User size={32} className="text-[#261732]/40" />
            </div>
            <button className="absolute -bottom-1 -left-1 w-7 h-7 rounded-full bg-[#261732] flex items-center justify-center shadow">
              <Upload size={12} className="text-[#f0e8df]" />
            </button>
          </div>
          <p className="text-xs text-[#5a4a5e]" style={AR}>تغيير الصورة</p>
        </div>
        <Field label="الاسم"                k="name" />
        <Field label="البريد الإلكتروني"    k="email" dir="ltr" />
        <Field label="رقم الجوال"           k="phone" dir="ltr" />
        <Field label="المدينة"              k="city" />
        <div>
          <label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>النبذة</label>
          <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-2xl shadow-[0px_4px_4px_1px_rgba(0,0,0,0.08)]">
            <textarea value={form.bio} onChange={e => setForm(p => ({ ...p, bio: e.target.value }))} rows={3}
              className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] resize-none focus:outline-none text-right" style={AR}/>
          </div>
        </div>
        <Pill dark onClick={() => { setSaved(true); setTimeout(() => { setSaved(false); onBack(); }, 1200); }} className="w-full py-4 flex items-center justify-center">
          <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>{saved ? "✓ تم الحفظ" : "حفظ التغييرات"}</span>
        </Pill>
      </div>
    </DScreenBg>
  );
}

// ── 11. Change Password ───────────────────────────────────────────────────────
function DChangePassword({ onBack }: { onBack: () => void }) {
  const [form, setForm] = useState({ cur: "", next: "", confirm: "" });
  const [show, setShow] = useState(false);
  const [done, setDone] = useState(false);
  const valid = form.cur && form.next && form.confirm === form.next;
  return (
    <DScreenBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl">
        <h2 className="font-bold text-[#261732]" style={AR}>تغيير كلمة المرور</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 px-5 py-6 space-y-4" dir="rtl">
        {[
          { label: "كلمة المرور الحالية",   k: "cur"     as keyof typeof form },
          { label: "كلمة المرور الجديدة",   k: "next"    as keyof typeof form },
          { label: "تأكيد كلمة المرور",    k: "confirm" as keyof typeof form },
        ].map(({ label, k }) => (
          <div key={k}>
            <label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>{label}</label>
            <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.08)] flex items-center">
              <input type={show ? "text" : "password"} value={form[k]} onChange={e => setForm(p => ({ ...p, [k]: e.target.value }))}
                className="flex-1 bg-transparent px-5 py-3 text-sm text-[#261732] focus:outline-none" placeholder="••••••••"/>
              <button onClick={() => setShow(p => !p)} className="pr-4 text-[#5a4a5e]">{show ? <EyeOff size={15}/> : <Eye size={15}/>}</button>
            </div>
          </div>
        ))}
        {form.confirm && form.confirm !== form.next && (
          <p className="text-xs text-red-500 text-right" style={AR}>كلمتا المرور غير متطابقتين</p>
        )}
        <Pill dark onClick={valid ? () => { setDone(true); setTimeout(() => { setDone(false); onBack(); }, 1200); } : undefined}
          className={`w-full py-4 flex items-center justify-center ${!valid ? "opacity-40" : ""}`}>
          <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>{done ? "✓ تم التحديث" : "تحديث كلمة المرور"}</span>
        </Pill>
      </div>
    </DScreenBg>
  );
}

// ── 12. Reviews ───────────────────────────────────────────────────────────────
const REVIEWS_DATA = [
  { name: "هدى السبيعي",  avatar: CA.d, rating: 5, text: "تصميم احترافي جداً، التفاصيل دقيقة والتواصل ممتاز طوال المشروع.", project: "غرفة نوم فاخرة", date: "يوليو ٢٠٢٥" },
  { name: "سارة العمري",  avatar: CA.b, rating: 5, text: "المصمم فاهم الذوق بالضبط، الصالة طلعت أجمل من توقعاتي!", project: "صالة جلوس كلاسيك", date: "يونيو ٢٠٢٥" },
  { name: "خالد المطيري", avatar: CA.c, rating: 4, text: "عمل جيد جداً، الحمام أصبح مثل الفندق. التأخير البسيط اثّر على التقييم.", project: "حمام رئيسي عصري", date: "يونيو ٢٠٢٥" },
  { name: "لمياء الشمري", avatar: CA.d, rating: 5, text: "من أفضل تجاربي مع المصممين، دقة في التنفيذ واهتمام بالتفاصيل.", project: "مكتب منزلي أنيق", date: "مايو ٢٠٢٥" },
];

function DReviews({ onBack }: { onBack: () => void }) {
  const avg = (REVIEWS_DATA.reduce((s, r) => s + r.rating, 0) / REVIEWS_DATA.length).toFixed(1);
  const dist = [5,4,3,2,1].map(s => ({ s, count: REVIEWS_DATA.filter(r => r.rating === s).length }));
  return (
    <DScreenBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl">
        <h2 className="font-bold text-[#261732]" style={AR}>تقييمات العملاء</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4" dir="rtl">
        {/* Summary */}
        <DCard className="p-4 flex items-center gap-4 flex-row-reverse">
          <div className="text-center flex-shrink-0">
            <p className="text-4xl font-bold text-[#261732]">{avg}</p>
            <div className="flex gap-0.5 justify-center mt-1">
              {[1,2,3,4,5].map(s => <span key={s} className={`text-sm ${parseFloat(avg) >= s ? "text-yellow-400" : "text-yellow-400/25"}`}>★</span>)}
            </div>
            <p className="text-[10px] text-[#5a4a5e] mt-0.5" style={AR}>{REVIEWS_DATA.length} تقييم</p>
          </div>
          <div className="flex-1 space-y-1">
            {dist.map(({ s, count }) => (
              <div key={s} className="flex items-center gap-2 flex-row-reverse">
                <span className="text-[10px] text-[#261732] w-4 text-right">{s}★</span>
                <div className="flex-1 h-1.5 rounded-full bg-[#261732]/10">
                  <div className="h-full rounded-full bg-yellow-400 transition-all" style={{ width: `${(count / REVIEWS_DATA.length) * 100}%` }} />
                </div>
                <span className="text-[9px] text-[#5a4a5e] w-3 text-left">{count}</span>
              </div>
            ))}
          </div>
        </DCard>
        {/* Reviews */}
        {REVIEWS_DATA.map((r, i) => (
          <DCard key={i} className="p-4">
            <div className="flex items-center gap-3 mb-2 flex-row-reverse">
              <img src={r.avatar} alt={r.name} className="w-9 h-9 rounded-full object-cover border-2 border-white/60 flex-shrink-0" />
              <div className="flex-1 text-right">
                <p className="font-semibold text-sm text-[#261732]" style={AR}>{r.name}</p>
                <div className="flex gap-0.5 justify-end">
                  {[1,2,3,4,5].map(s => <span key={s} className={`text-[10px] ${r.rating >= s ? "text-yellow-400" : "text-yellow-400/25"}`}>★</span>)}
                </div>
              </div>
            </div>
            <p className="text-sm text-[#5a4a5e] leading-relaxed" style={AR}>{r.text}</p>
            <div className="flex items-center justify-between mt-2">
              <span className="text-[9px] text-[#5a4a5e]">{r.date}</span>
              <span className="text-[9px] text-[#5a4a5e]" style={AR}>🔗 {r.project}</span>
            </div>
          </DCard>
        ))}
      </div>
    </DScreenBg>
  );
}

// ── 13. Portfolio Editor ──────────────────────────────────────────────────────
function DPortfolioEditor({ onBack }: { onBack: () => void }) {
  const [images, setImages] = useState(PORTFOLIO_IMGS.slice(0, 6));
  const [bio, setBio]       = useState("خبرة أكثر من ١٠ سنوات في تصميم الفضاءات الراقية.");
  const [exp, setExp]       = useState("أكثر من ١٠ سنوات");
  const [saved, setSaved]   = useState(false);

  return (
    <DScreenBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl">
        <h2 className="font-bold text-[#261732]" style={AR}>تعديل المحفظة</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5" dir="rtl">
        {/* Project images */}
        <div>
          <p className="text-sm font-semibold text-[#261732] mb-3" style={AR}>صور المشاريع</p>
          <div className="grid grid-cols-3 gap-2">
            {images.map((img, i) => (
              <div key={i} className="relative aspect-square rounded-xl overflow-hidden group">
                <img src={img} alt="" className="w-full h-full object-cover" />
                <button onClick={() => setImages(p => p.filter((_, j) => j !== i))}
                  className="absolute top-1 left-1 w-5 h-5 rounded-full bg-red-500/90 flex items-center justify-center">
                  <X size={10} className="text-white" />
                </button>
              </div>
            ))}
            <button onClick={() => setImages(p => [...p, PORTFOLIO_IMGS[p.length % PORTFOLIO_IMGS.length]])}
              className="aspect-square rounded-xl border-2 border-dashed border-[#261732]/20 flex flex-col items-center justify-center gap-1 bg-[rgba(217,217,217,0.15)] hover:bg-[rgba(217,217,217,0.3)] transition-colors">
              <Upload size={18} className="text-[#261732]/40" />
              <span className="text-[9px] text-[#5a4a5e]" style={AR}>إضافة</span>
            </button>
          </div>
        </div>

        {/* Bio */}
        <div>
          <label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>النبذة الشخصية</label>
          <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-2xl shadow-[0px_4px_4px_1px_rgba(0,0,0,0.08)]">
            <textarea value={bio} onChange={e => setBio(e.target.value)} rows={3}
              className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] resize-none focus:outline-none text-right" style={AR}/>
          </div>
        </div>

        {/* Experience */}
        <div>
          <label className="text-[11px] text-[#5a4a5e] mb-2 block" style={AR}>سنوات الخبرة</label>
          <div className="flex gap-2 flex-wrap justify-end">
            {["أقل من ٢ سنوات", "٢–٥ سنوات", "٥–١٠ سنوات", "أكثر من ١٠ سنوات"].map(y => (
              <button key={y} onClick={() => setExp(y)}
                className={`text-[10px] px-3 py-1.5 rounded-full border transition-all ${exp === y ? "bg-[#261732] text-[#f0e8df] border-[#261732]" : "bg-[rgba(217,217,217,0.3)] text-[#261732] border-[#261732]/15"}`} style={AR}>{y}</button>
            ))}
          </div>
        </div>

        <Pill dark onClick={() => { setSaved(true); setTimeout(() => { setSaved(false); onBack(); }, 1200); }} className="w-full py-4 flex items-center justify-center">
          <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>{saved ? "✓ تم الحفظ" : "حفظ المحفظة"}</span>
        </Pill>
      </div>
    </DScreenBg>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// FASHION DESIGNER APP
// ══════════════════════════════════════════════════════════════════════════════

interface FProduct { id:string; name:string; price:string; img:string; category:string; status:"متاح"|"نفد"; description:string; sizes?:string[]; colors?:string[]; }
interface FOrder { id:string; productName:string; productImg:string; customer:string; customerAvatar:string; qty:number; price:string; date:string; status:"قيد الانتظار"|"قيد التجهيز"|"تم الشحن"|"مكتمل"|"ملغي"; size?:string; color?:string; }
interface FRequest { id:string; title:string; category:string; budget:string; city:string; date:string; isPrivate:boolean; img:string; customer:string; customerAvatar:string; description:string; status:string; colors?:string; fabric?:string; deadline?:string; notes?:string; }
interface FChat { id:string; customer:string; avatar:string; lastMsg:string; time:string; unread:number; relatedTo:string; relatedType:"request"|"order"; }
type FTab = "home"|"products"|"browse"|"manage"|"chats"|"profile";

const FASHION_PRODUCTS: FProduct[] = [
  { id:"FP1", name:"فستان سهرة ذهبي",   price:"٢٤٠٠ ر.س", img:D.evening, category:"سهرة",  status:"متاح", description:"فستان سهرة أنيق بقماش الساتان الذهبي مع تطريز يدوي.", sizes:["S","M","L"], colors:["ذهبي","فضي"] },
  { id:"FP2", name:"فستان زفاف ملكي",   price:"٧٥٠٠ ر.س", img:D.bridal,  category:"زواج",  status:"متاح", description:"فستان زفاف من الدانتيل الفرنسي مع ذيل طويل.", sizes:["XS","S","M","L"], colors:["أبيض","عاجي"] },
  { id:"FP3", name:"فستان حفل أزرق",    price:"١٨٠٠ ر.س", img:D.blue,    category:"حفلات", status:"متاح", description:"فستان حفل بلون أزرق ملكي مع حزام كريستال.", sizes:["S","M","XL"] },
  { id:"FP4", name:"فستان كاجوال بيج",  price:"٩٥٠ ر.س",  img:D.white,   category:"كاجوال",status:"نفد",  description:"فستان يومي بقماش الكريب الناعم.", colors:["بيج","أبيض"] },
];
const FASHION_ORDERS: FOrder[] = [
  { id:"FO1", productName:"فستان سهرة ذهبي", productImg:D.evening, customer:"ليلى الخالدي", customerAvatar:CA.b, qty:1, price:"٢٤٠٠ ر.س", date:"١٤ يوليو ٢٠٢٥", status:"قيد الانتظار", size:"M", color:"ذهبي" },
  { id:"FO2", productName:"فستان زفاف ملكي", productImg:D.bridal,  customer:"رنا السعيد",   customerAvatar:CA.d, qty:1, price:"٧٥٠٠ ر.س", date:"١٠ يوليو ٢٠٢٥", status:"قيد التجهيز", size:"S" },
  { id:"FO3", productName:"فستان حفل أزرق",  productImg:D.blue,    customer:"نور العمري",   customerAvatar:CA.b, qty:1, price:"١٨٠٠ ر.س", date:"٥ يوليو ٢٠٢٥",  status:"مكتمل",     size:"M" },
];
const FASHION_REQUESTS: FRequest[] = [
  { id:"FR1", title:"فستان زفاف مميز",    category:"زواج",  budget:"٨٠٠٠–١٢٠٠٠ ر.س", city:"الرياض", date:"١٥ يوليو ٢٠٢٥", isPrivate:false, img:D.bridal,  customer:"سارة الحربي",  customerAvatar:CA.b, description:"أبحث عن فستان زفاف بتفاصيل دانتيل فرنسي وذيل طويل، اللون أبيض مع لمسات فضية.", colors:"أبيض، فضي", fabric:"دانتيل، ساتان", deadline:"١ سبتمبر ٢٠٢٥", status:"جديد" },
  { id:"FR2", title:"فستان سهرة احترافي", category:"سهرة",  budget:"٣٠٠٠–٥٠٠٠ ر.س",  city:"جدة",    date:"١٣ يوليو ٢٠٢٥", isPrivate:true,  img:D.evening, customer:"منى القحطاني", customerAvatar:CA.d, description:"فستان سهرة لحفل زفاف عائلي، أسلوب راقٍ بألوان داكنة.", colors:"أسود، ذهبي", fabric:"ساتان، شيفون", deadline:"٢٠ أغسطس ٢٠٢٥", status:"جديد" },
  { id:"FR3", title:"فستان حفل عصري",     category:"حفلات", budget:"٢٠٠٠–٣٠٠٠ ر.س",  city:"الدمام", date:"١٢ يوليو ٢٠٢٥", isPrivate:true,  img:D.party,   customer:"لمياء العتيبي",customerAvatar:CA.d, description:"فستان حفل بتصميم عصري مع تفاصيل مضيئة.", colors:"أحمر، وردي", fabric:"شيفون", deadline:"١ سبتمبر ٢٠٢٥", status:"جديد" },
  { id:"FR4", title:"فستان فريد وجريء",   category:"غريب",  budget:"٤٠٠٠–٦٠٠٠ ر.س",  city:"الرياض", date:"١١ يوليو ٢٠٢٥", isPrivate:false, img:D.unique,  customer:"هدى السبيعي",  customerAvatar:CA.d, description:"تصميم إبداعي بطابع فني يعكس شخصيتي القوية.", colors:"أسود، بنفسجي", fabric:"حرير، دانتيل", deadline:"١٥ سبتمبر ٢٠٢٥", status:"جديد" },
  { id:"FR5", title:"فستان كاجوال راقٍ",  category:"كاجوال",budget:"١٢٠٠–١٨٠٠ ر.س",  city:"مكة",    date:"١٠ يوليو ٢٠٢٥", isPrivate:false, img:D.white,   customer:"ريم الشمري",   customerAvatar:CA.b, description:"فستان يومي أنيق مناسب للمناسبات غير الرسمية.", colors:"بيج، كريمي", fabric:"قطن، كريب", deadline:"٣٠ أغسطس ٢٠٢٥", status:"جديد" },
];
const FASHION_MANAGED: FRequest[] = [
  { id:"FM1", title:"فستان سهرة احترافي", category:"سهرة",  budget:"٤٠٠٠ ر.س",  city:"جدة",    date:"٥ يوليو ٢٠٢٥",   isPrivate:true,  img:D.evening, customer:"منى القحطاني", customerAvatar:CA.d, description:"فستان سهرة لحفل زفاف.", status:"قيد التنفيذ" },
  { id:"FM2", title:"فستان حفل عصري",     category:"حفلات", budget:"٢٥٠٠ ر.س",  city:"الدمام", date:"١٥ يونيو ٢٠٢٥",  isPrivate:true,  img:D.party,   customer:"لمياء العتيبي",customerAvatar:CA.d, description:"فستان حفل عصري.", status:"بانتظار رد العميل" },
  { id:"FM3", title:"فستان زفاف مميز",    category:"زواج",  budget:"١٠٠٠٠ ر.س", city:"الرياض", date:"١٠ مايو ٢٠٢٥",   isPrivate:false, img:D.bridal,  customer:"سارة الحربي",  customerAvatar:CA.b, description:"فستان زفاف كامل.", status:"مكتمل" },
];
const FASHION_CHATS: FChat[] = [
  { id:"FC1", customer:"منى القحطاني", avatar:CA.d, lastMsg:"هل يمكن تغيير اللون للبوردو؟", time:"منذ ٥ د",  unread:2, relatedTo:"فستان سهرة احترافي", relatedType:"request" },
  { id:"FC2", customer:"ليلى الخالدي", avatar:CA.b, lastMsg:"شكراً، متى يصل الطلب؟",       time:"منذ ١ س",  unread:1, relatedTo:"فستان سهرة ذهبي",    relatedType:"order"   },
  { id:"FC3", customer:"سارة الحربي",  avatar:CA.b, lastMsg:"الفستان رائع جداً، شكراً!",    time:"أمس",      unread:0, relatedTo:"فستان زفاف مميز",    relatedType:"request" },
];
const F_STATUS_BG: Record<string,string> = {
  "قيد الانتظار":"bg-orange-100/80 text-orange-700","قيد التجهيز":"bg-blue-100/80 text-blue-700","تم الشحن":"bg-indigo-100/80 text-indigo-700","مكتمل":"bg-green-100/80 text-green-800","ملغي":"bg-gray-100/80 text-gray-600","قيد التنفيذ":"bg-blue-100/80 text-blue-700","بانتظار رد العميل":"bg-yellow-100/80 text-yellow-700","مقبول":"bg-emerald-100/80 text-emerald-700","مرفوض":"bg-red-100/80 text-red-700","جديد":"bg-purple-100/80 text-purple-700",
};
const F_PORTFOLIO = [D.evening,D.bridal,D.party,D.unique,D.runway,D.blue,D.red,D.black];

function FNav({ active, onTab }: { active:FTab; onTab:(t:FTab)=>void }) {
  const tabs: { id:FTab; label:string; icon:React.FC<{size:number;className?:string}> }[] = [
    { id:"home",    label:"الرئيسية",  icon:Home          },
    { id:"products",label:"منتجاتي",  icon:ShoppingBag   },
    { id:"browse",  label:"الطلبات",  icon:Search        },
    { id:"manage",  label:"الإدارة",  icon:ClipboardList },
    { id:"chats",   label:"الدردشة",  icon:MessageSquare },
    { id:"profile", label:"الملف",    icon:User          },
  ];
  return (
    <div className="flex-shrink-0 bg-white/70 backdrop-blur-[14px] border-t border-white/30 flex items-center" style={{ boxShadow:"0px -4px 4px rgba(0,0,0,0.02)" }}>
      {tabs.map(t => (
        <button key={t.id} onClick={() => onTab(t.id)} className={`flex-1 flex flex-col items-center py-2.5 gap-0.5 transition-colors ${active===t.id?"text-[#261732]":"text-[#261732]/28"}`}>
          <t.icon size={17} className={active===t.id?"text-[#261732]":"text-[#261732]/28"} />
          <span className="text-[7.5px] font-semibold mt-0.5" style={AR}>{t.label}</span>
        </button>
      ))}
    </div>
  );
}
function FCard({ children, className="" }: { children:React.ReactNode; className?:string }) {
  return <div className={`bg-[rgba(217,217,217,0.28)] backdrop-blur-sm rounded-2xl shadow-[0px_4px_4px_1px_rgba(0,0,0,0.12)] ${className}`}>{children}</div>;
}
function FBg({ children }: { children:React.ReactNode }) {
  return (
    <div className="h-full flex flex-col overflow-hidden relative">
      <img src={bgAbstract} alt="" aria-hidden className="absolute inset-0 w-full h-full object-cover pointer-events-none select-none opacity-30" />
      <div className="absolute inset-0 bg-[#f7f2ee]/78" />
      <div className="relative z-10 h-full flex flex-col">{children}</div>
    </div>
  );
}

function FProfileSetup({ onBack, onDone }: { onBack:()=>void; onDone:()=>void }) {
  const [name, setName] = useState(""); const [city, setCity] = useState(""); const [bio, setBio] = useState(""); const [exp, setExp] = useState("");
  const valid = name && city;
  return (
    <ScreenBg overlay="bg-[#f0e8df]/52">
      <div className="flex-shrink-0 flex items-center px-4 pt-2 pb-1">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-[rgba(217,217,217,0.3)]"><ArrowRight size={20} className="text-[#261732]" /></button>
      </div>
      <div className="flex-1 overflow-y-auto px-6 pb-8" dir="rtl">
        <div className="mb-6 text-right"><Logo size="sm" /><h2 className="text-xl font-bold text-[#261732] mt-3" style={AR}>إعداد ملفك الشخصي</h2><p className="text-sm text-[#5a4a5e] mt-0.5" style={AR}>مصممة أزياء</p></div>
        <div className="flex flex-col items-center mb-6">
          <div className="relative">
            <div className="w-20 h-20 rounded-full bg-[rgba(38,23,50,0.08)] flex items-center justify-center border-2 border-[#261732]/15"><User size={30} className="text-[#261732]/40" /></div>
            <button className="absolute -bottom-1 -left-1 w-7 h-7 rounded-full bg-[#261732] flex items-center justify-center shadow"><Upload size={12} className="text-[#f0e8df]" /></button>
          </div>
          <p className="text-xs text-[#5a4a5e] mt-2" style={AR}>رفع صورة شخصية</p>
        </div>
        <div className="space-y-4">
          {[{label:"اسم المصممة",val:name,set:setName,ph:"مثال: نوف الأحمدي"},{label:"المدينة",val:city,set:setCity,ph:"مثال: الرياض"}].map(({label,val,set,ph}) => (
            <div key={label}><label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>{label}</label>
              <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.08)]">
                <input value={val} onChange={e=>set(e.target.value)} placeholder={ph} className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/40 focus:outline-none text-right" style={AR} />
              </div>
            </div>
          ))}
          <div><label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>نبذة مختصرة</label>
            <div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-2xl shadow-[0px_4px_4px_1px_rgba(0,0,0,0.08)]">
              <textarea value={bio} onChange={e=>setBio(e.target.value)} placeholder="تخصصي في فساتين السهرة..." rows={3} className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/40 focus:outline-none text-right resize-none" style={AR} />
            </div>
          </div>
          <div><label className="text-[11px] text-[#5a4a5e] mb-2 block" style={AR}>سنوات الخبرة</label>
            <div className="flex gap-2 flex-wrap justify-end">
              {["أقل من ٢","٢–٥","٥–١٠","أكثر من ١٠"].map(y => (
                <button key={y} onClick={()=>setExp(y)} className={`text-xs px-3 py-1.5 rounded-full border transition-all ${exp===y?"bg-[#261732] text-[#f0e8df] border-[#261732]":"bg-[rgba(217,217,217,0.3)] text-[#261732] border-[#261732]/15"}`} style={AR}>{y} سنة</button>
              ))}
            </div>
          </div>
        </div>
        <div className="mt-6">
          <Pill dark onClick={valid?onDone:undefined} className={`w-full py-4 flex items-center justify-center ${!valid?"opacity-40":""}`}>
            <span className="text-[#f0e8df] font-semibold text-sm" style={AR}>إنشاء الحساب</span>
          </Pill>
        </div>
      </div>
    </ScreenBg>
  );
}

function FHome({ fTab,onTab,onPending,onOrders,onRating,onPortfolio }: { fTab:FTab;onTab:(t:FTab)=>void;onPending:()=>void;onOrders:()=>void;onRating:()=>void;onPortfolio:()=>void; }) {
  const privateCount = FASHION_REQUESTS.filter(r=>r.isPrivate).length;
  const pendingOrders = FASHION_ORDERS.filter(o=>o.status==="قيد الانتظار").length;
  return (
    <FBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6">
        <div className="w-9 h-9 rounded-full bg-[rgba(38,23,50,0.08)] flex items-center justify-center"><User size={17} className="text-[#261732]" /></div>
        <h1 className="text-base font-bold text-[#261732]" style={AR}>الرئيسية</h1>
        <button className="relative p-1.5"><Bell size={20} className="text-[#261732]" /><span className="absolute top-1 right-1 w-2 h-2 bg-[#8b5a6b] rounded-full" /></button>
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4" dir="rtl">
        <div className="grid grid-cols-2 gap-3">
          <button onClick={onPending} className="text-right"><FCard className="p-3.5 hover:shadow-lg transition-shadow"><div className="w-9 h-9 rounded-full bg-purple-50 flex items-center justify-center mb-2"><ClipboardList size={17} className="text-purple-600" /></div><p className="text-2xl font-bold text-[#261732]">{privateCount}</p><p className="text-[10px] text-[#5a4a5e] leading-tight mt-0.5" style={AR}>طلب خاص غير معالج</p></FCard></button>
          <button onClick={onOrders} className="text-right"><FCard className="p-3.5 hover:shadow-lg transition-shadow"><div className="w-9 h-9 rounded-full bg-orange-50 flex items-center justify-center mb-2"><Package size={17} className="text-orange-500" /></div><p className="text-2xl font-bold text-[#261732]">{pendingOrders}</p><p className="text-[10px] text-[#5a4a5e] leading-tight mt-0.5" style={AR}>طلب شراء قيد الانتظار</p></FCard></button>
        </div>
        <button onClick={onRating} className="w-full text-right">
          <FCard className="p-4 flex items-center justify-between hover:shadow-lg transition-shadow">
            <ChevronRight size={14} className="text-[#261732]/25" style={{transform:"scaleX(-1)"}} />
            <div className="flex-1 text-right mr-2"><p className="text-sm font-semibold text-[#261732]" style={AR}>تقييمي</p><div className="flex items-center gap-0.5 justify-end mt-1">{[1,2,3,4,5].map(s=><span key={s} className={`text-base ${s<=4?"text-yellow-400":"text-yellow-400/35"}`}>★</span>)}<span className="text-base font-bold text-[#261732] mr-1">4.8</span></div><p className="text-[10px] text-[#5a4a5e]" style={AR}>٤٢ تقييم</p></div>
            <div className="w-10 h-10 rounded-full bg-yellow-50 flex items-center justify-center flex-shrink-0"><Star size={18} className="text-yellow-500 fill-yellow-400" /></div>
          </FCard>
        </button>
        <FCard className="overflow-hidden">
          <div className="relative h-40"><img src={D.evening} alt="" className="w-full h-full object-cover object-top" /><div className="absolute inset-0 bg-gradient-to-t from-[#261732]/65 to-transparent" />
            <div className="absolute bottom-0 right-0 left-0 p-3 flex items-end gap-3 flex-row-reverse">
              <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur-sm border-2 border-white/60 flex items-center justify-center flex-shrink-0"><User size={24} className="text-white" /></div>
              <div className="text-right"><p className="text-white font-bold text-sm" style={AR}>نوف الأحمدي</p><p className="text-white/70 text-[10px]" style={AR}>مصممة أزياء · الرياض</p></div>
            </div>
          </div>
          <div className="p-4" dir="rtl"><p className="text-xs text-[#5a4a5e] leading-relaxed" style={AR}>تخصصي في فساتين السهرة والمناسبات الراقية.</p>
            <div className="mt-3"><div className="flex items-center justify-between mb-2"><button onClick={onPortfolio} className="text-[10px] text-[#261732] font-bold underline underline-offset-2" style={AR}>تعديل المحفظة ←</button><p className="text-xs font-semibold text-[#261732]" style={AR}>معرض الأعمال</p></div>
              <div className="grid grid-cols-4 gap-1.5">{F_PORTFOLIO.slice(0,4).map((img,i)=><div key={i} className="aspect-square rounded-xl overflow-hidden"><img src={img} alt="" className="w-full h-full object-cover object-top" /></div>)}</div>
            </div>
          </div>
        </FCard>
        <div><p className="text-sm font-semibold text-[#261732] mb-2" style={AR}>آخر النشاطات</p>
          <div className="space-y-2">
            {[{icon:ClipboardList,text:"طلب خاص جديد من منى القحطاني",sub:"فستان سهرة احترافي",time:"منذ ٥ د",bg:"bg-purple-50/60"},{icon:Package,text:"طلب شراء من ليلى الخالدي",sub:"فستان سهرة ذهبي",time:"منذ ٢٠ د",bg:"bg-orange-50/60"},{icon:MessageSquare,text:"رسالة من ليلى الخالدي",sub:"متى يصل الطلب؟",time:"منذ ١ س",bg:"bg-blue-50/60"},{icon:Star,text:"تقييم من سارة الحربي",sub:"★★★★★ ممتازة",time:"أمس",bg:"bg-yellow-50/60"}].map((a,i)=>(
              <FCard key={i} className={`p-3 flex items-center gap-3 flex-row-reverse ${a.bg}`}><div className="w-8 h-8 rounded-full bg-white/60 flex items-center justify-center flex-shrink-0"><a.icon size={14} className="text-[#261732]" /></div><div className="flex-1 text-right"><p className="text-xs font-medium text-[#261732]" style={AR}>{a.text}</p><p className="text-[10px] text-[#5a4a5e]" style={AR}>{a.sub}</p></div><span className="text-[9px] text-[#5a4a5e] flex-shrink-0">{a.time}</span></FCard>
            ))}
          </div>
        </div>
      </div>
      <FNav active={fTab} onTab={onTab} />
    </FBg>
  );
}

function FProducts({ fTab,onTab,onProduct,onAdd }: { fTab:FTab;onTab:(t:FTab)=>void;onProduct:(p:FProduct)=>void;onAdd:()=>void; }) {
  return (
    <FBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl">
        <button onClick={onAdd} className="flex items-center gap-1.5 bg-[#261732] text-[#f0e8df] px-3.5 py-2 rounded-full text-xs font-semibold"><Plus size={13}/><span style={AR}>إضافة</span></button>
        <h1 className="text-base font-bold text-[#261732]" style={AR}>منتجاتي</h1>
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3" dir="rtl">
        {FASHION_PRODUCTS.map(p=>(
          <button key={p.id} onClick={()=>onProduct(p)} className="w-full text-right">
            <FCard className="flex items-stretch overflow-hidden hover:shadow-lg transition-shadow">
              <div className="w-24 flex-shrink-0"><img src={p.img} alt={p.name} className="w-full h-full object-cover object-top" /></div>
              <div className="flex-1 p-3.5 flex flex-col justify-between">
                <div><div className="flex items-start justify-between gap-2"><span className={`text-[9px] px-2 py-0.5 rounded-full font-medium flex-shrink-0 ${p.status==="متاح"?"bg-green-100/80 text-green-700":"bg-red-100/80 text-red-600"}`} style={AR}>{p.status}</span><p className="font-bold text-[#261732] text-sm leading-tight" style={AR}>{p.name}</p></div><span className="text-[10px] text-[#5a4a5e] mt-0.5 block" style={AR}>{p.category}</span></div>
                <div className="flex items-center justify-between mt-2"><ChevronRight size={14} className="text-[#261732]/20" style={{transform:"scaleX(-1)"}}/><p className="text-base font-bold text-[#261732]">{p.price}</p></div>
              </div>
            </FCard>
          </button>
        ))}
      </div>
      <FNav active={fTab} onTab={onTab} />
    </FBg>
  );
}

function FAddProduct({ onBack, onSave }: { onBack:()=>void; onSave:()=>void }) {
  const [name,setName]=useState(""); const [price,setPrice]=useState(""); const [desc,setDesc]=useState(""); const [qty,setQty]=useState(""); const [category,setCategory]=useState(""); const [toggles,setToggles]=useState<Record<string,boolean>>({}); const [sizes,setSizes]=useState<string[]>([]); const [colors,setColors]=useState(""); const [fabric,setFabric]=useState(""); const [imgCount,setImgCount]=useState(1);
  const toggle=(key:string)=>setToggles(p=>({...p,[key]:!p[key]}));
  const toggleSize=(s:string)=>setSizes(p=>p.includes(s)?p.filter(x=>x!==s):[...p,s]);
  const valid=name&&price&&category;
  const OPTIONAL=[{key:"sizes",label:"إضافة المقاسات"},{key:"colors",label:"إضافة الألوان"},{key:"fabric",label:"إضافة نوع القماش"},{key:"lengths",label:"إضافة الأطوال"},{key:"measure",label:"مقاسات مخصصة"},{key:"stock",label:"إضافة الكمية"}];
  return (
    <FBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl">
        <h2 className="font-bold text-[#261732]" style={AR}>إضافة منتج</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]" style={{transform:"scaleX(-1)"}} /></button>
      </div>
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4" dir="rtl">
        <div><label className="text-[11px] text-[#5a4a5e] mb-2 block" style={AR}>صور المنتج</label>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {Array.from({length:imgCount}).map((_,i)=><div key={i} className="flex-shrink-0 w-20 h-20 rounded-xl bg-[rgba(217,217,217,0.25)] border border-dashed border-[#261732]/20 flex items-center justify-center"><Upload size={16} className="text-[#261732]/30"/></div>)}
            <button onClick={()=>setImgCount(p=>p+1)} className="flex-shrink-0 w-20 h-20 rounded-xl bg-[rgba(217,217,217,0.15)] border border-dashed border-[#261732]/15 flex flex-col items-center justify-center gap-1"><Plus size={16} className="text-[#261732]/35"/><span className="text-[8px] text-[#5a4a5e]" style={AR}>إضافة</span></button>
          </div>
        </div>
        {[{label:"اسم المنتج",val:name,set:setName,ph:"مثال: فستان سهرة ذهبي"},{label:"السعر (ر.س)",val:price,set:setPrice,ph:"مثال: ٢٤٠٠"},{label:"الكمية",val:qty,set:setQty,ph:"مثال: ٥"}].map(({label,val,set,ph})=>(
          <div key={label}><label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>{label}</label><div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.07)]"><input value={val} onChange={e=>set(e.target.value)} placeholder={ph} className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/40 focus:outline-none text-right" style={AR}/></div></div>
        ))}
        <div><label className="text-[11px] text-[#5a4a5e] mb-2 block" style={AR}>الفئة</label><div className="flex flex-wrap gap-2 justify-end">{["سهرة","زواج","حفلات","كاجوال","غريب","سواريه"].map(c=><button key={c} onClick={()=>setCategory(c)} className={`text-xs px-3 py-1.5 rounded-full border transition-all ${category===c?"bg-[#261732] text-[#f0e8df] border-[#261732]":"bg-[rgba(217,217,217,0.3)] text-[#261732] border-[#261732]/15"}`} style={AR}>{c}</button>)}</div></div>
        <div><label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>الوصف</label><div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-2xl shadow-[0px_4px_4px_1px_rgba(0,0,0,0.07)]"><textarea value={desc} onChange={e=>setDesc(e.target.value)} placeholder="وصف المنتج..." rows={3} className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/40 focus:outline-none text-right resize-none" style={AR}/></div></div>
        <div><label className="text-[11px] text-[#5a4a5e] mb-2 block font-semibold" style={AR}>خصائص اختيارية</label>
          <div className="space-y-2">{OPTIONAL.map(opt=>(
            <div key={opt.key}>
              <button onClick={()=>toggle(opt.key)} className="w-full flex items-center justify-between px-4 py-2.5 bg-[rgba(217,217,217,0.18)] rounded-2xl">
                <div className={`w-9 h-5 rounded-full transition-colors relative ${toggles[opt.key]?"bg-[#261732]":"bg-[#261732]/15"}`}><span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all ${toggles[opt.key]?"right-0.5":"left-0.5"}`}/></div>
                <span className="text-sm text-[#261732]" style={AR}>{opt.label}</span>
              </button>
              {toggles[opt.key]&&opt.key==="sizes"&&<div className="flex flex-wrap gap-1.5 justify-end mt-2 px-2">{["XS","S","M","L","XL","XXL"].map(s=><button key={s} onClick={()=>toggleSize(s)} className={`text-[10px] px-2.5 py-1 rounded-full border transition-all ${sizes.includes(s)?"bg-[#261732] text-[#f0e8df] border-[#261732]":"bg-[rgba(217,217,217,0.35)] text-[#261732] border-[#261732]/15"}`}>{s}</button>)}</div>}
              {toggles[opt.key]&&opt.key==="colors"&&<div className="mt-2 px-2"><div className="bg-[rgba(217,217,217,0.22)] rounded-[50px]"><input value={colors} onChange={e=>setColors(e.target.value)} placeholder="أسود، ذهبي..." className="w-full bg-transparent px-4 py-2.5 text-sm text-[#261732] placeholder-[#5a4a5e]/40 focus:outline-none text-right" style={AR}/></div></div>}
              {toggles[opt.key]&&opt.key==="fabric"&&<div className="flex flex-wrap gap-1.5 justify-end mt-2 px-2">{["حرير","ساتان","دانتيل","شيفون","كريب"].map(f=><button key={f} onClick={()=>setFabric(fabric===f?"":f)} className={`text-[10px] px-2.5 py-1 rounded-full border transition-all ${fabric===f?"bg-[#261732] text-[#f0e8df] border-[#261732]":"bg-[rgba(217,217,217,0.35)] text-[#261732] border-[#261732]/15"}`} style={AR}>{f}</button>)}</div>}
            </div>
          ))}</div>
        </div>
        <Pill dark onClick={valid?onSave:undefined} className={`w-full py-4 flex items-center justify-center ${!valid?"opacity-40":""}`}><span className="text-[#f0e8df] font-semibold text-sm" style={AR}>حفظ المنتج</span></Pill>
      </div>
    </FBg>
  );
}

function FProductDetails({ product:p, onBack }: { product:FProduct|null; onBack:()=>void }) {
  const [showDelete,setShowDelete]=useState(false);
  if(!p) return null;
  const imgs=[p.img,D.runway,D.blue].slice(0,3);
  return (
    <FBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl">
        <h2 className="font-bold text-[#261732]" style={AR}>تفاصيل المنتج</h2>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]"/></button>
      </div>
      <div className="flex-1 overflow-y-auto pb-4">
        <div className="flex gap-1.5 p-4">
          <div className="flex-[2] h-52 rounded-xl overflow-hidden"><img src={imgs[0]} alt="" className="w-full h-full object-cover object-top"/></div>
          <div className="flex-1 flex flex-col gap-1.5">{imgs.slice(1).map((img,i)=><div key={i} className="flex-1 rounded-xl overflow-hidden"><img src={img} alt="" className="w-full h-full object-cover object-top"/></div>)}</div>
        </div>
        <div className="px-5 space-y-4" dir="rtl">
          <div className="flex items-center justify-between"><span className={`text-[10px] px-2.5 py-1 rounded-full font-medium ${p.status==="متاح"?"bg-green-100/80 text-green-700":"bg-red-100/80 text-red-600"}`} style={AR}>{p.status}</span><div className="text-right"><p className="font-bold text-[#261732] text-lg" style={AR}>{p.name}</p><p className="text-xl font-bold text-[#261732]">{p.price}</p></div></div>
          <FCard className="p-4 space-y-2"><p className="text-sm text-[#5a4a5e] leading-relaxed" style={AR}>{p.description}</p>{[["الفئة",p.category],p.sizes?.length?["المقاسات",p.sizes.join("، ")]:null,p.colors?.length?["الألوان",p.colors.join("، ")]:null].filter(Boolean).map((row)=>row&&<div key={row[0]} className="flex justify-between text-sm border-t border-[#261732]/6 pt-2"><span className="text-[#5a4a5e]" style={AR}>{row[1]}</span><span className="font-medium text-[#261732]/70" style={AR}>{row[0]}</span></div>)}</FCard>
          <div className="flex gap-3"><button onClick={()=>setShowDelete(true)} className="flex-1 py-3.5 rounded-[50px] bg-red-50 text-red-500 text-sm font-semibold" style={AR}>حذف</button><Pill dark className="flex-1 py-3.5 flex items-center justify-center"><span className="text-[#f0e8df] text-sm font-semibold" style={AR}>تعديل</span></Pill></div>
        </div>
      </div>
      {showDelete&&<div className="absolute inset-0 bg-[#261732]/40 z-50 flex items-end"><div className="w-full bg-[#f7f2ee] rounded-t-3xl p-6" dir="rtl"><h3 className="font-bold text-[#261732] mb-1" style={AR}>حذف المنتج؟</h3><p className="text-sm text-[#5a4a5e] mb-5" style={AR}>لا يمكن التراجع عن هذا الإجراء.</p><div className="flex gap-3"><button onClick={()=>setShowDelete(false)} className="flex-1 py-3 rounded-[50px] bg-[rgba(217,217,217,0.4)] text-sm font-medium text-[#261732]" style={AR}>إلغاء</button><button onClick={onBack} className="flex-1 py-3 rounded-[50px] bg-red-500 text-white text-sm font-semibold" style={AR}>حذف</button></div></div></div>}
    </FBg>
  );
}

function FBrowseRequests({ fTab,onTab,activeTab,setActiveTab,onRequest }: { fTab:FTab;onTab:(t:FTab)=>void;activeTab:"public"|"private";setActiveTab:(t:"public"|"private")=>void;onRequest:(r:FRequest)=>void; }) {
  const [filter,setFilter]=useState("الكل");
  const shown=FASHION_REQUESTS.filter(r=>activeTab==="private"?r.isPrivate:!r.isPrivate).filter(r=>filter==="الكل"||r.category===filter.replace("فساتين ",""));
  return (
    <FBg>
      <div className="flex-shrink-0 px-5 pt-3 pb-0 border-b border-[#261732]/6">
        <h1 className="text-base font-bold text-[#261732] text-right mb-2.5" style={AR}>تصفح الطلبات</h1>
        <div className="flex gap-2 justify-end mb-2">{(["public","private"] as const).map(t=><button key={t} onClick={()=>setActiveTab(t)} className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${activeTab===t?"bg-[#261732] text-[#f0e8df]":"bg-[rgba(217,217,217,0.35)] text-[#261732]"}`} style={AR}>{t==="public"?"الطلبات العامة":"الطلبات الخاصة"}</button>)}</div>
      </div>
      <div className="flex-shrink-0 px-4 py-2.5 overflow-x-auto"><div className="flex gap-2 justify-end">{["الكل","زواج","سهرة","حفلات","كاجوال","غريب"].map(f=><button key={f} onClick={()=>setFilter(f)} className={`flex-shrink-0 text-[10px] px-3 py-1.5 rounded-full border transition-all ${filter===f?"bg-[#261732] text-[#f0e8df] border-[#261732]":"bg-[rgba(217,217,217,0.25)] text-[#261732] border-[#261732]/15"}`} style={AR}>{f}</button>)}</div></div>
      <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-3" dir="rtl">
        {shown.map(r=>(
          <button key={r.id} onClick={()=>onRequest(r)} className="w-full text-right">
            <FCard className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative h-40"><img src={r.img} alt={r.title} className="w-full h-full object-cover object-top"/><div className="absolute inset-0 bg-gradient-to-t from-[#261732]/50 to-transparent"/><div className="absolute top-2 right-2"><span className={`text-[9px] px-2 py-0.5 rounded-full font-medium ${r.isPrivate?"bg-[#261732] text-[#f0e8df]":"bg-white/85 text-[#261732]"}`} style={AR}>{r.isPrivate?"خاص":"عام"}</span></div></div>
              <div className="p-3.5"><p className="font-bold text-[#261732] text-sm" style={AR}>{r.title}</p><p className="text-[10px] text-[#5a4a5e] mt-0.5 line-clamp-2" style={AR}>{r.description}</p><div className="flex items-center gap-3 mt-2 flex-wrap justify-end"><span className="text-[10px] text-[#5a4a5e]">{r.date}</span><span className="text-[10px] text-[#5a4a5e]">📍 {r.city}</span><span className="text-[10px] font-semibold text-[#261732]">💰 {r.budget}</span></div></div>
            </FCard>
          </button>
        ))}
      </div>
      <FNav active={fTab} onTab={onTab}/>
    </FBg>
  );
}

function FRequestDetails({ request:r, onBack, onAccept, onReject }: { request:FRequest|null;onBack:()=>void;onAccept:()=>void;onReject:()=>void; }) {
  const [showReject,setShowReject]=useState(false); const [reason,setReason]=useState("");
  if(!r) return null;
  return (
    <FBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl"><h2 className="font-bold text-[#261732]" style={AR}>تفاصيل الطلب</h2><button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]"/></button></div>
      <div className="flex-1 overflow-y-auto pb-4">
        <div className="flex gap-1.5 p-4"><div className="flex-[2] h-48 rounded-xl overflow-hidden"><img src={r.img} alt="" className="w-full h-full object-cover object-top"/></div><div className="flex-1 flex flex-col gap-1.5">{[D.runway,D.party].map((img,i)=><div key={i} className="flex-1 rounded-xl overflow-hidden"><img src={img} alt="" className="w-full h-full object-cover object-top"/></div>)}</div></div>
        <div className="px-5 space-y-4" dir="rtl">
          <div className="flex items-center gap-3 flex-row-reverse"><img src={r.customerAvatar} alt={r.customer} className="w-10 h-10 rounded-full object-cover border-2 border-white/60 flex-shrink-0"/><div className="text-right"><p className="font-semibold text-sm text-[#261732]" style={AR}>{r.customer}</p><p className="text-[10px] text-[#5a4a5e]">{r.date}</p></div></div>
          <FCard className="p-4 space-y-3"><p className="font-bold text-[#261732] text-base" style={AR}>{r.title}</p><p className="text-sm text-[#5a4a5e] leading-relaxed" style={AR}>{r.description}</p>{[["الفئة",r.category],["الألوان",r.colors||"—"],["القماش",r.fabric||"—"],["الميزانية",r.budget],["المدينة",r.city],["الموعد",r.deadline||"—"]].map(([k,v])=><div key={k} className="flex justify-between text-sm border-t border-[#261732]/6 pt-2"><span className="text-[#5a4a5e]" style={AR}>{v}</span><span className="font-medium text-[#261732]/65" style={AR}>{k}</span></div>)}</FCard>
        </div>
      </div>
      <div className="flex-shrink-0 px-5 pb-6 pt-3 flex gap-3"><button onClick={()=>setShowReject(true)} className="flex-1 py-3.5 rounded-[50px] bg-[rgba(217,217,217,0.35)] text-[#261732] text-sm font-semibold" style={AR}>رفض</button><Pill dark onClick={onAccept} className="flex-1 py-3.5 flex items-center justify-center"><span className="text-[#f0e8df] font-semibold text-sm" style={AR}>قبول وإرسال عرض</span></Pill></div>
      {showReject&&<div className="absolute inset-0 bg-[#261732]/40 z-50 flex items-end"><div className="w-full bg-[#f7f2ee] rounded-t-3xl p-6" dir="rtl"><h3 className="font-bold text-[#261732] mb-1" style={AR}>تأكيد الرفض</h3><p className="text-sm text-[#5a4a5e] mb-4" style={AR}>هل أنت متأكدة؟</p><div className="bg-[rgba(217,217,217,0.3)] rounded-2xl mb-4"><textarea value={reason} onChange={e=>setReason(e.target.value)} placeholder="سبب الرفض..." rows={3} className="w-full bg-transparent px-4 py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/50 resize-none focus:outline-none text-right" style={AR}/></div><div className="flex gap-3"><button onClick={()=>setShowReject(false)} className="flex-1 py-3 rounded-[50px] bg-[rgba(217,217,217,0.4)] text-sm font-medium text-[#261732]" style={AR}>إلغاء</button><button onClick={()=>{setShowReject(false);onReject();}} className="flex-1 py-3 rounded-[50px] bg-red-500 text-white text-sm font-semibold" style={AR}>تأكيد</button></div></div></div>}
    </FBg>
  );
}

function FCreateOffer({ request:r, onBack, onSend }: { request:FRequest|null;onBack:()=>void;onSend:()=>void; }) {
  const [price,setPrice]=useState(""); const [time,setTime]=useState(""); const [delivery,setDelivery]=useState(""); const [msg,setMsg]=useState(""); const valid=price&&time;
  if(!r) return null;
  return (
    <FBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl"><h2 className="font-bold text-[#261732]" style={AR}>إرسال عرض</h2><button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]"/></button></div>
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4" dir="rtl">
        <FCard className="p-3 flex items-center gap-3 flex-row-reverse"><div className="w-12 h-12 rounded-xl overflow-hidden flex-shrink-0"><img src={r.img} alt="" className="w-full h-full object-cover object-top"/></div><div className="text-right flex-1"><p className="text-sm font-bold text-[#261732]" style={AR}>{r.title}</p><p className="text-[10px] text-[#5a4a5e]" style={AR}>{r.customer} · {r.city}</p></div></FCard>
        {[{label:"السعر المقترح (ر.س)",val:price,set:setPrice,ph:"مثال: ٤٥٠٠"},{label:"مدة الإنجاز",val:time,set:setTime,ph:"مثال: ٣ أسابيع"},{label:"تاريخ التسليم",val:delivery,set:setDelivery,ph:"مثال: ١ سبتمبر"}].map(({label,val,set,ph})=>(
          <div key={label}><label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>{label}</label><div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.07)]"><input value={val} onChange={e=>set(e.target.value)} placeholder={ph} className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/40 focus:outline-none text-right" style={AR}/></div></div>
        ))}
        <div><label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>رسالتك</label><div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-2xl shadow-[0px_4px_4px_1px_rgba(0,0,0,0.07)]"><textarea value={msg} onChange={e=>setMsg(e.target.value)} placeholder="اشرحي رؤيتك..." rows={4} className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/50 resize-none focus:outline-none text-right" style={AR}/></div></div>
        <Pill dark onClick={valid?onSend:undefined} className={`w-full py-4 flex items-center justify-center ${!valid?"opacity-40":""}`}><span className="text-[#f0e8df] font-semibold text-sm" style={AR}>إرسال العرض</span></Pill>
      </div>
    </FBg>
  );
}

function FManageRequests({ fTab,onTab,mainTab,setMainTab,statusTab,setStatusTab,onOrder,onRequest }: { fTab:FTab;onTab:(t:FTab)=>void;mainTab:"orders"|"requests";setMainTab:(t:"orders"|"requests")=>void;statusTab:string;setStatusTab:(t:string)=>void;onOrder:(o:FOrder)=>void;onRequest:(r:FRequest)=>void; }) {
  const ordersShown=statusTab==="الكل"?FASHION_ORDERS:FASHION_ORDERS.filter(o=>o.status===statusTab);
  const reqShown=statusTab==="الكل"?FASHION_MANAGED:FASHION_MANAGED.filter(r=>r.status.includes(statusTab.replace("بانتظار رد","بانتظار")));
  return (
    <FBg>
      <div className="flex-shrink-0 px-5 pt-3 pb-0 border-b border-[#261732]/6">
        <h1 className="text-base font-bold text-[#261732] text-right mb-2" style={AR}>إدارة الطلبات</h1>
        <div className="flex gap-2 justify-end mb-2">{(["orders","requests"] as const).map(t=><button key={t} onClick={()=>{setMainTab(t);setStatusTab("الكل");}} className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${mainTab===t?"bg-[#261732] text-[#f0e8df]":"bg-[rgba(217,217,217,0.35)] text-[#261732]"}`} style={AR}>{t==="orders"?"طلبات الشراء":"طلبات التصميم"}</button>)}</div>
        <div className="flex gap-1.5 overflow-x-auto pb-2">{(mainTab==="orders"?["الكل","قيد الانتظار","قيد التجهيز","تم الشحن","مكتمل","ملغي"]:["الكل","بانتظار رد","مقبول","قيد التنفيذ","مكتمل","مرفوض"]).map(s=><button key={s} onClick={()=>setStatusTab(s)} className={`flex-shrink-0 text-[9px] px-2.5 py-1 rounded-full font-medium transition-all ${statusTab===s?"bg-[#261732]/80 text-[#f0e8df]":"bg-[rgba(217,217,217,0.35)] text-[#261732]"}`} style={AR}>{s}</button>)}</div>
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3" dir="rtl">
        {mainTab==="orders"?ordersShown.map(o=>(
          <button key={o.id} onClick={()=>onOrder(o)} className="w-full text-right"><FCard className="flex items-stretch overflow-hidden hover:shadow-lg transition-shadow"><div className="w-20 flex-shrink-0"><img src={o.productImg} alt="" className="w-full h-full object-cover object-top"/></div><div className="flex-1 p-3 flex flex-col justify-between"><div><div className="flex items-center justify-between gap-1"><span className={`text-[8px] px-1.5 py-0.5 rounded-full font-medium ${F_STATUS_BG[o.status]||"bg-gray-100 text-gray-600"}`} style={AR}>{o.status}</span><p className="font-bold text-sm text-[#261732]" style={AR}>{o.productName}</p></div><p className="text-[10px] text-[#5a4a5e] mt-0.5" style={AR}>{o.customer}</p></div><p className="font-bold text-sm text-[#261732] mt-1">{o.price}</p></div></FCard></button>
        )):reqShown.map(r=>(
          <button key={r.id} onClick={()=>onRequest(r)} className="w-full text-right"><FCard className="flex items-stretch overflow-hidden hover:shadow-lg transition-shadow"><div className="w-20 flex-shrink-0"><img src={r.img} alt="" className="w-full h-full object-cover object-top"/></div><div className="flex-1 p-3 flex flex-col justify-between"><div><div className="flex items-center justify-between gap-1"><span className={`text-[8px] px-1.5 py-0.5 rounded-full font-medium ${F_STATUS_BG[r.status]||"bg-gray-100 text-gray-600"}`} style={AR}>{r.status}</span><p className="font-bold text-sm text-[#261732]" style={AR}>{r.title}</p></div><p className="text-[10px] text-[#5a4a5e] mt-0.5" style={AR}>{r.customer}</p></div><p className="text-[10px] font-semibold text-[#261732]">{r.budget}</p></div></FCard></button>
        ))}
      </div>
      <FNav active={fTab} onTab={onTab}/>
    </FBg>
  );
}

function FManageDetails({ order, request:req, onBack, onChat }: { order:FOrder|null;request:FRequest|null;onBack:()=>void;onChat:()=>void; }) {
  const isOrder=!!order;
  const status=isOrder?order!.status:req?.status||"";
  const title=isOrder?order!.productName:req?.title||"";
  const customer=isOrder?order!.customer:req?.customer||"";
  const cAvatar=isOrder?order!.customerAvatar:req?.customerAvatar||CA.b;
  const price=isOrder?order!.price:req?.budget||"";
  const img=isOrder?order!.productImg:req?.img||D.evening;
  const date=isOrder?order!.date:req?.date||"";
  const timeline=isOrder?["تم الطلب","قيد التجهيز","تم الشحن","مكتمل"]:["تم الطلب","أُرسل العرض","قُبل العرض","قيد التنفيذ","مكتمل"];
  const activeIdx=isOrder?(status==="قيد الانتظار"?0:status==="قيد التجهيز"?1:status==="تم الشحن"?2:3):(status==="بانتظار رد العميل"?1:status==="قيد التنفيذ"?3:status==="مكتمل"?4:0);
  return (
    <FBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl"><h2 className="font-bold text-[#261732]" style={AR}>{isOrder?"تفاصيل طلب الشراء":"تفاصيل طلب التصميم"}</h2><button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]"/></button></div>
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4" dir="rtl">
        <FCard className="p-4 flex items-center gap-3 flex-row-reverse"><div className="w-14 h-14 rounded-xl overflow-hidden flex-shrink-0"><img src={img} alt="" className="w-full h-full object-cover object-top"/></div><div className="flex-1 text-right"><p className="font-bold text-[#261732]" style={AR}>{title}</p><div className="flex items-center gap-2 mt-1 justify-end"><span className={`text-[9px] px-2 py-0.5 rounded-full font-medium ${F_STATUS_BG[status]||"bg-gray-100 text-gray-600"}`} style={AR}>{status}</span><img src={cAvatar} alt="" className="w-5 h-5 rounded-full object-cover"/><span className="text-[10px] text-[#5a4a5e]" style={AR}>{customer}</span></div><p className="text-sm font-bold text-[#261732] mt-1">{price}</p></div></FCard>
        <FCard className="p-4"><p className="font-semibold text-sm text-[#261732] text-right mb-4" style={AR}>مسار الطلب</p>
          {timeline.map((step,i)=>(
            <div key={i} className="flex gap-4 flex-row-reverse"><div className="flex flex-col items-center"><div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 border-2 ${i<activeIdx?"bg-[#261732] border-[#261732]":i===activeIdx?"border-[#261732] bg-white/50":"border-[#261732]/15 bg-white/15"}`}>{i<activeIdx?<CheckCircle size={13} className="text-white"/>:i===activeIdx?<div className="w-2.5 h-2.5 rounded-full bg-[#261732]"/>:<div className="w-2.5 h-2.5 rounded-full bg-[#261732]/20"/>}</div>{i<timeline.length-1&&<div className={`w-0.5 h-8 mt-1 ${i<activeIdx?"bg-[#261732]":"bg-[#261732]/10"}`}/>}</div><div className="pb-6 pt-0.5 text-right"><p className={`text-sm font-medium ${i<=activeIdx?"text-[#261732]":"text-[#261732]/28"}`} style={AR}>{step}</p>{i===activeIdx&&<p className="text-[10px] text-[#5a4a5e] mt-0.5" style={AR}>{date}</p>}</div></div>
          ))}
        </FCard>
        <div className="grid grid-cols-2 gap-3"><Pill className="py-3 flex items-center justify-center gap-1.5" onClick={onChat}><MessageSquare size={14} className="text-[#261732]"/><span className="text-sm text-[#261732]" style={AR}>تواصل</span></Pill><Pill dark className="py-3 flex items-center justify-center"><span className="text-[#f0e8df] text-sm" style={AR}>تحديث الحالة</span></Pill></div>
      </div>
    </FBg>
  );
}

function FChats({ fTab,onTab,onChat }: { fTab:FTab;onTab:(t:FTab)=>void;onChat:(c:FChat)=>void; }) {
  return (
    <FBg>
      <div className="flex-shrink-0 px-5 py-3 border-b border-[#261732]/6"><h1 className="text-base font-bold text-[#261732] text-right" style={AR}>المحادثات</h1></div>
      <div className="flex-1 overflow-y-auto" dir="rtl">
        {FASHION_CHATS.map(c=>(
          <button key={c.id} onClick={()=>onChat(c)} className="w-full px-5 py-3.5 flex items-center gap-3 flex-row-reverse hover:bg-[rgba(217,217,217,0.2)] transition-colors border-b border-[#261732]/4 last:border-0">
            <div className="relative flex-shrink-0"><img src={c.avatar} alt={c.customer} className="w-12 h-12 rounded-full object-cover border-2 border-white/70"/>{c.unread>0&&<span className="absolute -top-0.5 -left-0.5 w-5 h-5 bg-[#261732] rounded-full flex items-center justify-center"><span className="text-[9px] text-white font-bold">{c.unread}</span></span>}</div>
            <div className="flex-1 text-right"><div className="flex items-center justify-between"><span className="text-[10px] text-[#5a4a5e]">{c.time}</span><p className="font-bold text-sm text-[#261732]" style={AR}>{c.customer}</p></div><p className={`text-xs mt-0.5 truncate ${c.unread>0?"text-[#261732] font-medium":"text-[#5a4a5e]"}`} style={AR}>{c.lastMsg}</p><p className="text-[9px] text-[#5a4a5e]/60 mt-0.5" style={AR}>{c.relatedType==="order"?"🛍️":"📋"} {c.relatedTo}</p></div>
          </button>
        ))}
      </div>
      <FNav active={fTab} onTab={onTab}/>
    </FBg>
  );
}

const F_DEMO_MSGS=[{from:"customer",text:"هل يمكن تغيير اللون للبوردو؟",time:"٢:١٠ م"},{from:"designer",text:"أهلاً! بالتأكيد، هذا ممكن.",time:"٢:١٢ م"},{from:"customer",text:"ممتاز! وهل يمكن إضافة تطريز على الأكمام؟",time:"٢:١٤ م"},{from:"designer",text:"نعم يمكن، سيضاف ٢٠٠ ر.س إضافية.",time:"٢:١٥ م"},{from:"customer",text:"موافقة، تفضلي بالمتابعة 🙏",time:"٢:١٦ م"}];

function FChatDetails({ chat:c, onBack, onViewRequest }: { chat:FChat|null;onBack:()=>void;onViewRequest:()=>void; }) {
  const [msg,setMsg]=useState("");
  if(!c) return null;
  return (
    <FBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-2.5 border-b border-[#261732]/6" dir="rtl">
        <button onClick={onViewRequest} className="text-[10px] text-[#261732] font-semibold bg-[rgba(217,217,217,0.35)] px-3 py-1.5 rounded-full" style={AR}>{c.relatedType==="order"?"عرض الطلبية":"عرض الطلب"}</button>
        <div className="flex items-center gap-2 flex-row-reverse"><img src={c.avatar} alt={c.customer} className="w-8 h-8 rounded-full object-cover border-2 border-white/70"/><div className="text-right"><p className="font-bold text-sm text-[#261732]" style={AR}>{c.customer}</p><p className="text-[9px] text-[#5a4a5e]" style={AR}>{c.relatedTo}</p></div></div>
        <button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]"/></button>
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3" dir="rtl">
        {F_DEMO_MSGS.map((m,i)=>{const isMe=m.from==="designer";return(<div key={i} className={`flex ${isMe?"justify-start":"justify-end"}`}><div className={`max-w-[72%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${isMe?"bg-[#261732] text-[#f0e8df] rounded-br-none":"bg-white/80 text-[#261732] rounded-bl-none shadow-sm"}`} style={AR}><p>{m.text}</p><p className={`text-[9px] mt-1 text-left ${isMe?"text-[#f0e8df]/45":"text-[#5a4a5e]/55"}`}>{m.time}</p></div></div>);})}
      </div>
      <div className="flex-shrink-0 px-4 pb-6 pt-2 flex items-center gap-2" dir="rtl">
        <button className="p-2.5 rounded-full bg-[rgba(217,217,217,0.3)] flex-shrink-0"><Upload size={16} className="text-[#261732]"/></button>
        <div className="flex-1 bg-white/55 backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.07)] flex items-center px-4"><input value={msg} onChange={e=>setMsg(e.target.value)} placeholder="اكتبي رسالة..." className="flex-1 bg-transparent py-3 text-sm text-[#261732] placeholder-[#5a4a5e]/50 focus:outline-none text-right" style={AR}/></div>
        <button onClick={()=>setMsg("")} className="p-2.5 rounded-full bg-[#261732] flex-shrink-0"><Send size={15} className="text-[#f0e8df]" style={{transform:"scaleX(-1)"}}/></button>
      </div>
    </FBg>
  );
}

function FProfile({ fTab,onTab,onEdit,onPassword,onReviews,onLogout }: { fTab:FTab;onTab:(t:FTab)=>void;onEdit:()=>void;onPassword:()=>void;onReviews:()=>void;onLogout:()=>void; }) {
  const [showLogout,setShowLogout]=useState(false);
  return (
    <FBg>
      <div className="flex-1 overflow-y-auto" dir="rtl">
        <div className="flex flex-col items-center pt-8 pb-4 px-5 gap-2">
          <div className="w-20 h-20 rounded-full bg-white/25 backdrop-blur-sm border-2 border-white/60 shadow-[0px_4px_16px_rgba(0,0,0,0.15)] flex items-center justify-center flex-shrink-0">
            <User size={32} className="text-[#261732]"/>
          </div>
          <p className="font-bold text-[#261732] text-lg mt-1" style={AR}>نوف الأحمدي</p>
          <p className="text-xs text-[#5a4a5e]" style={AR}>مصممة أزياء · الرياض</p>
          <div className="flex items-center gap-0.5 mt-0.5">
            {[1,2,3,4,5].map(s=><span key={s} className={`text-xs ${s<=4?"text-yellow-400":"text-yellow-400/30"}`}>★</span>)}
            <span className="text-xs font-bold text-[#261732] mr-1">4.8</span>
          </div>
        </div>
        <div className="px-5 pt-3 pb-5 space-y-4">
          <div className="grid grid-cols-3 gap-2.5">{[["4.8★","التقييم"],["١٢","منتج"],["٤٢","مكتمل"]].map(([n,l])=><FCard key={l} className="p-3 text-center"><p className="text-lg font-bold text-[#261732]">{n}</p><p className="text-[9px] text-[#5a4a5e] mt-0.5" style={AR}>{l}</p></FCard>)}</div>
          <FCard className="overflow-hidden">{[{label:"تعديل الملف الشخصي",action:onEdit},{label:"تغيير كلمة المرور",action:onPassword},{label:"تقييمات العميلات",action:onReviews},{label:"تسجيل الخروج",action:()=>setShowLogout(true),danger:true}].map((item,i,arr)=><button key={i} onClick={item.action} className={`w-full flex items-center justify-between px-5 py-4 hover:bg-[rgba(217,217,217,0.2)] transition-colors ${i<arr.length-1?"border-b border-[#261732]/6":""}`}><ChevronRight size={14} className={item.danger?"text-red-400/40":"text-[#261732]/20"} style={{transform:"scaleX(-1)"}}/><span className={`text-sm font-medium ${item.danger?"text-red-500":"text-[#261732]"}`} style={AR}>{item.label}</span></button>)}</FCard>
        </div>
      </div>
      <FNav active={fTab} onTab={onTab}/>
      {showLogout&&<div className="absolute inset-0 bg-[#261732]/40 z-50 flex items-end"><div className="w-full bg-[#f7f2ee] rounded-t-3xl p-6" dir="rtl"><h3 className="font-bold text-[#261732] mb-1" style={AR}>تسجيل الخروج</h3><p className="text-sm text-[#5a4a5e] mb-5" style={AR}>هل أنت متأكدة؟</p><div className="flex gap-3"><button onClick={()=>setShowLogout(false)} className="flex-1 py-3 rounded-[50px] bg-[rgba(217,217,217,0.4)] text-sm font-medium text-[#261732]" style={AR}>إلغاء</button><button onClick={onLogout} className="flex-1 py-3 rounded-[50px] bg-[#261732] text-white text-sm font-semibold" style={AR}>تسجيل الخروج</button></div></div></div>}
    </FBg>
  );
}

function FEditProfile({ onBack }: { onBack:()=>void }) {
  const [saved,setSaved]=useState(false); const [form,setForm]=useState({name:"نوف الأحمدي",email:"nouf@design.sa",phone:"+966 5x xxx xxxx",city:"الرياض",bio:"تخصصي في فساتين السهرة."});
  return (
    <FBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl"><h2 className="font-bold text-[#261732]" style={AR}>تعديل الملف الشخصي</h2><button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]"/></button></div>
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4" dir="rtl">
        <div className="flex flex-col items-center gap-2"><div className="relative"><div className="w-20 h-20 rounded-2xl bg-[rgba(38,23,50,0.08)] flex items-center justify-center border-2 border-[#261732]/15"><User size={30} className="text-[#261732]/40"/></div><button className="absolute -bottom-1 -left-1 w-7 h-7 rounded-full bg-[#261732] flex items-center justify-center shadow"><Upload size={12} className="text-[#f0e8df]"/></button></div></div>
        {[{label:"الاسم",k:"name" as keyof typeof form},{label:"البريد الإلكتروني",k:"email" as keyof typeof form},{label:"رقم الجوال",k:"phone" as keyof typeof form},{label:"المدينة",k:"city" as keyof typeof form}].map(({label,k})=>(
          <div key={k}><label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>{label}</label><div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.07)]"><input value={form[k]} onChange={e=>setForm(p=>({...p,[k]:e.target.value}))} className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] focus:outline-none text-right" style={AR}/></div></div>
        ))}
        <div><label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>النبذة</label><div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-2xl shadow-[0px_4px_4px_1px_rgba(0,0,0,0.07)]"><textarea value={form.bio} onChange={e=>setForm(p=>({...p,bio:e.target.value}))} rows={3} className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] resize-none focus:outline-none text-right" style={AR}/></div></div>
        <Pill dark onClick={()=>{setSaved(true);setTimeout(()=>{setSaved(false);onBack();},1200);}} className="w-full py-4 flex items-center justify-center"><span className="text-[#f0e8df] font-semibold text-sm" style={AR}>{saved?"✓ تم الحفظ":"حفظ التغييرات"}</span></Pill>
      </div>
    </FBg>
  );
}

function FChangePassword({ onBack }: { onBack:()=>void }) {
  const [form,setForm]=useState({cur:"",next:"",confirm:""}); const [show,setShow]=useState(false); const [done,setDone]=useState(false);
  const valid=form.cur&&form.next&&form.confirm===form.next;
  return (
    <FBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl"><h2 className="font-bold text-[#261732]" style={AR}>تغيير كلمة المرور</h2><button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]"/></button></div>
      <div className="flex-1 px-5 py-6 space-y-4" dir="rtl">
        {[{label:"كلمة المرور الحالية",k:"cur"},{label:"كلمة المرور الجديدة",k:"next"},{label:"تأكيد كلمة المرور",k:"confirm"}].map(({label,k})=>(
          <div key={k}><label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>{label}</label><div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-[50px] shadow-[0px_4px_4px_1px_rgba(0,0,0,0.07)] flex items-center"><input type={show?"text":"password"} value={form[k as keyof typeof form]} onChange={e=>setForm(p=>({...p,[k]:e.target.value}))} placeholder="••••••••" className="flex-1 bg-transparent px-5 py-3 text-sm text-[#261732] focus:outline-none"/><button onClick={()=>setShow(s=>!s)} className="pr-4 text-[#5a4a5e]">{show?<EyeOff size={15}/>:<Eye size={15}/>}</button></div></div>
        ))}
        {form.confirm&&form.confirm!==form.next&&<p className="text-xs text-red-500 text-right" style={AR}>كلمتا المرور غير متطابقتين</p>}
        <Pill dark onClick={valid?()=>{setDone(true);setTimeout(()=>{setDone(false);onBack();},1200);}:undefined} className={`w-full py-4 flex items-center justify-center ${!valid?"opacity-40":""}`}><span className="text-[#f0e8df] font-semibold text-sm" style={AR}>{done?"✓ تم التحديث":"تحديث كلمة المرور"}</span></Pill>
      </div>
    </FBg>
  );
}

const F_REVIEWS_DATA=[{name:"منى القحطاني",avatar:CA.d,rating:5,text:"فستان السهرة كان أجمل من توقعاتي، التفاصيل رائعة.",project:"فستان سهرة احترافي",date:"يوليو ٢٠٢٥"},{name:"ليلى الخالدي",avatar:CA.b,rating:5,text:"وصل في الوقت المحدد وبالمواصفات الدقيقة!",project:"فستان سهرة ذهبي",date:"يوليو ٢٠٢٥"},{name:"سارة الحربي",avatar:CA.b,rating:5,text:"فستان الزفاف كان حلمي، مصممة موهوبة جداً.",project:"فستان زفاف مميز",date:"يونيو ٢٠٢٥"},{name:"لمياء العتيبي",avatar:CA.d,rating:4,text:"تصميم جميل والتواصل كان ممتازاً.",project:"فستان حفل عصري",date:"مايو ٢٠٢٥"}];

function FReviews({ onBack }: { onBack:()=>void }) {
  const avg=(F_REVIEWS_DATA.reduce((s,r)=>s+r.rating,0)/F_REVIEWS_DATA.length).toFixed(1);
  const dist=[5,4,3,2,1].map(s=>({s,count:F_REVIEWS_DATA.filter(r=>r.rating===s).length}));
  return (
    <FBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl"><h2 className="font-bold text-[#261732]" style={AR}>تقييمات العميلات</h2><button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]"/></button></div>
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4" dir="rtl">
        <FCard className="p-4 flex items-center gap-4 flex-row-reverse">
          <div className="text-center flex-shrink-0"><p className="text-4xl font-bold text-[#261732]">{avg}</p><div className="flex gap-0.5 justify-center mt-1">{[1,2,3,4,5].map(s=><span key={s} className={`text-sm ${parseFloat(avg)>=s?"text-yellow-400":"text-yellow-400/25"}`}>★</span>)}</div><p className="text-[10px] text-[#5a4a5e] mt-0.5" style={AR}>{F_REVIEWS_DATA.length} تقييم</p></div>
          <div className="flex-1 space-y-1.5">{dist.map(({s,count})=><div key={s} className="flex items-center gap-2 flex-row-reverse"><span className="text-[10px] text-[#261732] w-4 text-right">{s}★</span><div className="flex-1 h-2 rounded-full bg-[#261732]/8"><div className="h-full rounded-full bg-yellow-400 transition-all" style={{width:`${(count/F_REVIEWS_DATA.length)*100}%`}}/></div><span className="text-[9px] text-[#5a4a5e] w-3 text-left">{count}</span></div>)}</div>
        </FCard>
        {F_REVIEWS_DATA.map((r,i)=><FCard key={i} className="p-4"><div className="flex items-center gap-3 mb-3 flex-row-reverse"><img src={r.avatar} alt={r.name} className="w-9 h-9 rounded-full object-cover border-2 border-white/60 flex-shrink-0"/><div className="flex-1 text-right"><p className="font-semibold text-sm text-[#261732]" style={AR}>{r.name}</p><div className="flex gap-0.5 justify-end mt-0.5">{[1,2,3,4,5].map(s=><span key={s} className={`text-[10px] ${r.rating>=s?"text-yellow-400":"text-yellow-400/25"}`}>★</span>)}</div></div></div><p className="text-sm text-[#5a4a5e] leading-relaxed" style={AR}>{r.text}</p><div className="flex justify-between items-center mt-2.5"><span className="text-[9px] text-[#5a4a5e]">{r.date}</span><span className="text-[9px] text-[#5a4a5e] bg-[rgba(217,217,217,0.35)] px-2 py-0.5 rounded-full" style={AR}>📋 {r.project}</span></div></FCard>)}
      </div>
    </FBg>
  );
}

function FPortfolioEditor({ onBack }: { onBack:()=>void }) {
  const [images,setImages]=useState(F_PORTFOLIO.slice(0,6)); const [bio,setBio]=useState("تخصصي في فساتين السهرة."); const [exp,setExp]=useState("أكثر من ١٠ سنوات"); const [saved,setSaved]=useState(false);
  return (
    <FBg>
      <div className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-[#261732]/6" dir="rtl"><h2 className="font-bold text-[#261732]" style={AR}>تعديل المحفظة</h2><button onClick={onBack} className="p-2"><ArrowRight size={20} className="text-[#261732]"/></button></div>
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5" dir="rtl">
        <div><p className="text-sm font-semibold text-[#261732] mb-3" style={AR}>صور الأعمال</p>
          <div className="grid grid-cols-3 gap-2">
            {images.map((img,i)=><div key={i} className="relative aspect-square rounded-xl overflow-hidden"><img src={img} alt="" className="w-full h-full object-cover object-top"/><button onClick={()=>setImages(p=>p.filter((_,j)=>j!==i))} className="absolute top-1 left-1 w-5 h-5 rounded-full bg-red-500/90 flex items-center justify-center shadow"><X size={10} className="text-white"/></button></div>)}
            <button onClick={()=>setImages(p=>[...p,F_PORTFOLIO[p.length%F_PORTFOLIO.length]])} className="aspect-square rounded-xl border-2 border-dashed border-[#261732]/20 flex flex-col items-center justify-center gap-1 bg-[rgba(217,217,217,0.15)] hover:bg-[rgba(217,217,217,0.28)] transition-colors"><Upload size={18} className="text-[#261732]/35"/><span className="text-[9px] text-[#5a4a5e]" style={AR}>رفع</span></button>
          </div>
        </div>
        <div><label className="text-[11px] text-[#5a4a5e] mb-1 block" style={AR}>النبذة</label><div className="bg-[rgba(217,217,217,0.22)] backdrop-blur-sm rounded-2xl shadow-[0px_4px_4px_1px_rgba(0,0,0,0.07)]"><textarea value={bio} onChange={e=>setBio(e.target.value)} rows={3} className="w-full bg-transparent px-5 py-3 text-sm text-[#261732] resize-none focus:outline-none text-right" style={AR}/></div></div>
        <div><label className="text-[11px] text-[#5a4a5e] mb-2 block" style={AR}>سنوات الخبرة</label><div className="flex gap-2 flex-wrap justify-end">{["أقل من ٢ سنوات","٢–٥ سنوات","٥–١٠ سنوات","أكثر من ١٠ سنوات"].map(y=><button key={y} onClick={()=>setExp(y)} className={`text-[10px] px-3 py-1.5 rounded-full border transition-all ${exp===y?"bg-[#261732] text-[#f0e8df] border-[#261732]":"bg-[rgba(217,217,217,0.3)] text-[#261732] border-[#261732]/15"}`} style={AR}>{y}</button>)}</div></div>
        <Pill dark onClick={()=>{setSaved(true);setTimeout(()=>{setSaved(false);onBack();},1200);}} className="w-full py-4 flex items-center justify-center"><span className="text-[#f0e8df] font-semibold text-sm" style={AR}>{saved?"✓ تم الحفظ":"حفظ المحفظة"}</span></Pill>
      </div>
    </FBg>
  );
}
