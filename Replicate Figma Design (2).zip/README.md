
  # Replicate Figma Design

  This is a code bundle for Replicate Figma Design. The original project is available at https://www.figma.com/design/IZfuWjelBs14ashqjTDgrj/Replicate-Figma-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  